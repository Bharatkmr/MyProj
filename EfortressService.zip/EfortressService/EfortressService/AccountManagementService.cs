﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using EfortressService.EmailNotification;
using EfortressService.AccountManager;
using System.Threading;
using System.IO;
using EfortressService.AssessmentDeadlineProcess;
using EfortressService.ImportDataProcessor;
using System.Timers;

namespace EfortressService
{
    partial class AccountManagementService : ServiceBase
    {
        public AccountManagementService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            AccountManagement account = new AccountManagement();
            account.ProcessAccount();

            NotificationAlert notify = new NotificationAlert();
            notify.NotifyUser();

            AssessmentDeadline assesment = new AssessmentDeadline();
            assesment.ProcessAccount();

            ImportDataHandler importData = new ImportDataHandler();
            importData.ImportDataCall();
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
        }
    }
}
