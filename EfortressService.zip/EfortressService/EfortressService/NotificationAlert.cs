﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using EfortressService.NotificationServiceReference;
//using eFortresses.CloudeAssurance.WorkerProcess.ExceptionServiceReference;
//using eFortresses.CloudeAssurance.WorkerProcess.AccountManagementServiceReference;
using System.Configuration;
using System.Net.Mail;
using ProcessContext = EfortressService.NotificationServiceReference.ProcessContext;
using NotificationGroup = EfortressService.NotificationServiceReference.NotificationGroup;
using Notification = EfortressService.NotificationServiceReference.Notification;
using NotificationFrequency = EfortressService.NotificationServiceReference.NotificationFrequency;
using StatusCode = EfortressService.NotificationServiceReference.StatusCode;
using NotificationEmailStatusHistory = EfortressService.NotificationServiceReference.NotificationEmailStatusHistory;
using System.Net;
using System.ServiceModel;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Data;
using System.Web;
using System.IO;
using EfortressService.ExceptionServiceReference;
using EfortressService.AccountManagementServiceReference;
using eFortresses.AssessmentDeadlineProcess;
using System.Timers;
//using EfortressService.AssessmentDeadlineProcess;


namespace EfortressService.EmailNotification
{
    public class NotificationAlert
    {
        private readonly Object ObjLock = new Object();
        private readonly Object UpdateLock = new Object();
        private readonly Object StatusLock = new Object();

        // the thread that will do Notification processing
        private Thread _workerThread;
        // the thread that will update Notification receipient list
        private Thread _updateThread;
        // the thread that will update Notification status
        private Thread _statusThread;

        /// <summary>
        /// A reference to Notification service
        /// </summary>
        private EfortressService.NotificationServiceReference.NotificationServiceClient _notificationService = new NotificationServiceClient();

        /// <summary>
        /// A reference to Exception service
        /// </summary>
        private ExceptionServiceReference.ExceptionServiceClient _exceptionServiceClient = new ExceptionServiceClient();

        /// <summary>
        /// A reference to Account Management service
        /// </summary>
        private AccountManagementServiceReference.AccountManagementServiceClient _accountManagementServiceClient = new AccountManagementServiceClient();

        private Guid _applicationId;
        private Guid _userAccountId;

        internal Guid ApplicationId
        {
            get
            {
                if (_applicationId == Guid.Empty)
                {
                    var searchQuery = String.Format("app => app.applicationName == \"{0}\"", ConfigurationManager.AppSettings[NotificationResource.ApplicationName]);

                    _applicationId =
                        _accountManagementServiceClient.GetApplicationId(searchQuery);
                    return _applicationId;
                }
                return _applicationId;
            }
        }

        internal Guid UserAccountId
        {
            get
            {
                if (_userAccountId == Guid.Empty)
                {
                    _userAccountId = new Guid(ConfigurationManager.AppSettings[NotificationResource.DefaultUserId]);

                    return _userAccountId;
                }
                return _userAccountId;
            }
        }
        public Guid customizationAccountId { get; set; }

        ExceptionServiceReference.ProcessContext ExceptionProcessContext
        {
            get { return new ExceptionServiceReference.ProcessContext { UserId = UserAccountId, AppId = ApplicationId }; }
        }
        AccountManagementServiceReference.ProcessContext AccountProcessContext
        {
            get { return new AccountManagementServiceReference.ProcessContext { UserId = UserAccountId, AppId = ApplicationId }; }
        }
        EfortressService.NotificationServiceReference.ProcessContext NotificationProcessContext
        {
            get { return new EfortressService.NotificationServiceReference.ProcessContext { UserId = UserAccountId, AppId = ApplicationId }; }
        }

        /// <summary>
        /// SMTP Client for Sending Emails
        /// </summary>
        private SmtpClient _emailClient = null;

        /// <summary>
        /// SMTP Client for Sending Emails
        /// </summary>
        internal SmtpClient EmailClient
        {
            get
            {
                if (_emailClient == null)
                {
                    var processContext = new ProcessContext
                    {
                        AppId = new Guid(ConfigurationManager.AppSettings[NotificationResource.DefaultApplicationId]),
                        UserId = new Guid(ConfigurationManager.AppSettings[NotificationResource.DefaultUserId])
                    };
                    var smtpClientSetting = _notificationService.GetSmtpClient(customizationAccountId,processContext);

                    var smtpUserInfo = new NetworkCredential(smtpClientSetting.UserId, smtpClientSetting.Password);

                    var emailClient = new SmtpClient
                    {
                        Host = smtpClientSetting.HostId,
                        Port = smtpClientSetting.Port,
                        EnableSsl = true,
                        Credentials = smtpUserInfo,
                        DeliveryMethod = SmtpDeliveryMethod.Network
                    };

                    _emailClient = emailClient;
                    return _emailClient;
                }
                return _emailClient;
            }
        }

        #region Public Methods
        /// <summary>
        /// Gets invoked at regular interval for processing notifications
        /// </summary>
        /// <param name="state"></param>
        //public void ScheduledProcessNotification(Object state)
        public void ScheduledProcessNotification()
        {
            var threadStart = new ThreadStart(NotifyUser);
            _workerThread = new Thread(threadStart);
            _workerThread.Start();
        }

        public void ScheduledUpdateNotificationReceipientList(Object state)
        {
            //var threadStart = new ThreadStart(UpdateNotificationUserList);
            //_updateThread = new Thread(threadStart);
            //_updateThread.Start();
        }

        public void ScheduledUpdateNotificationStatus(Object state)
        {
            UpdateNotificationStatus();
            //var threadStart = new ThreadStart(UpdateNotificationStatus);
            //_statusThread = new Thread(threadStart);
            //_statusThread.Start();
        }

        #endregion

        #region Private Methods
        /// <summary>
        /// this method used to get notification infrmation from MDR and send a email to user
        /// </summary>
        public void NotifyUser()
        {
            System.Timers.Timer notificationTimer = new System.Timers.Timer();

            //int waitTime = 10;
            LoggerService("Email NotifyUser method started...");
            Trace.WriteLine("EmailAlert Notify user called", "Information");
            lock (ObjLock)
            {
                try
                {
                    notificationTimer.Stop();
                    //Thread.Sleep(waitTime);
                    ProcessAllEmailNotifications(NotificationProcessContext);
                    //waitTime = 180000;
                    //waitTime = 60000; //Changed as 1 minute
                    notificationTimer.Elapsed += new ElapsedEventHandler(notificationTimer_Elapsed);
                    notificationTimer.Interval = 180000;  //3 minutes
                    notificationTimer.Start();
                }
                catch (Exception exception)
                {
                    _exceptionServiceClient.AddException("Email Notification Worker Role", "NotifyUser",
                                      exception.Message,
                                      exception.InnerException == null
                                          ? exception.Message
                                          : exception.InnerException.Message, exception.StackTrace,
                                      ExceptionProcessContext);
                }
                finally
                {
                    //waitTime = 180000;
                    //waitTime = 60000;//Changed as 1 minute
                }

            }
            // end the thread
            //if (_workerThread != null)
            //{
            //    _workerThread.Abort();
            //}
        }

        private void notificationTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            NotifyUser();
        }

        /*        /// <summary>
                /// Update all active notifications user list
                /// </summary>
                 private void UpdateNotificationUserList()
                {
                    lock (UpdateLock)
                    {
                        try
                        {
                            var processContext = new ProcessContext
                            {
                                AppId =
                                    new Guid(
                                    ConfigurationManager.AppSettings[
                                        NotificationResource.DefaultApplicationId]),
                            };

                            UpdateNotificationRecipients(processContext);

                        }
                        catch (Exception exception)
                        {
                            EventLog.WriteEntry(NotificationResource.NotificationAlert, exception.Message);
                        }
                    }
                    // end the thread
                    if (_updateThread != null)
                    {
                        _updateThread.Abort();
                    }  
                }
        */
        /// <summary>
        /// Update the notification and user list status based on expiration time
        /// </summary>
        public void UpdateNotificationStatus()
        {
            LoggerService("Inside UpdateNotificationStatus...");

            lock (StatusLock)
            {
                try
                {
                    var processContext = new ProcessContext
                    {
                        AppId =
                            new Guid(
                            ConfigurationManager.AppSettings[
                                NotificationResource.DefaultApplicationId]),
                    };

                    UpdateNotificationStatus(processContext);
                }
                catch (Exception exception)
                {
                    EventLog.WriteEntry(NotificationResource.NotificationAlert, exception.Message);
                }
            }
            // end the thread
            if (_statusThread != null)
            {
                _statusThread.Abort();
            }
        }

        /// <summary>
        /// Send email alerts for the active notifications, based on the frequency settings
        /// </summary>
        /// <param name="processContext">process context of the application</param>
        private void ProcessAllEmailNotifications(ProcessContext processContext)
        {
            try
            {
                LoggerService("ProcessAllEmailNotifications method started...");

                string statusQuery =
                    "status => status.statusCodeName == \"EmailStatus\"  && status.codeValue == \"UnSent\"";
                Guid notificationEmailUnsent = _notificationService.GetStatusCode(statusQuery, processContext).FirstOrDefault().statusCodeID;

                //
                LoggerService("guid :" + notificationEmailUnsent.ToString());

                statusQuery =
                    "status => status.statusCodeName == \"NotificationStatus\"  && status.codeValue == \"Active\"";
                Guid notificationExpired = _notificationService.GetStatusCode(statusQuery, processContext).FirstOrDefault().statusCodeID;

                LoggerService("guid expired :" + notificationExpired.ToString());

                var currentTime = DateTime.Now;
                
                //var notificationCriteria = String.Format("notification => notification.notificationStatusID != new Guid(\"{0}\") && notification.isEmailRequired == true", notificationExpired);
                var notificationCriteria = String.Format("notification => notification.notificationStatusID == new Guid(\"{0}\") && notification.isEmailRequired == true", notificationExpired);

                LoggerService("notificationCriteria: " + notificationCriteria.ToString());

                var notifications = _notificationService.GetAllNotifications(notificationCriteria, processContext);

                string blindCopy = null;
                string carbonCopy = null;
                bool isAccountExpiryGroup;
                var assessmentdeadlineRepository = new AssessmentDeadlineRepository();
                foreach (var notification in notifications)
                {
                    LoggerService("Inside foreach notif..."+"====count"+notifications.Count());
                    isAccountExpiryGroup = false;
                    carbonCopy = null;
                    blindCopy = null;
                    var notificationGroupCriteria = String.Format("notificationGroup => notificationGroup.notificationID == new Guid(\"{0}\") && notificationGroup.isActive == true", notification.notificationID);
                    var notificationGroup = _notificationService.GetAllNotificationGroup(notificationGroupCriteria,
                                                                                         processContext).FirstOrDefault();

                    LoggerService("groupID: " + notificationGroup.groupID.ToString());

                    //Added for task# 462
                    string accountSearch = String.Format("userdetail => userdetail.userAccountID == new Guid(\"{0}\")", notificationGroup.groupID);

                    LoggerService("accountSearch: " + accountSearch);

                    var user = _accountManagementServiceClient.GetAllCustomers(accountSearch, AccountProcessContext, null, 0, 0).FirstOrDefault();
                    Guid customizationUserAccountId = Guid.Empty;
                    if (user.roleName == "TenantAdministrator")
                        customizationUserAccountId = user.userAccountID;
                    else if (user.roleName == "ProcessOwner" || user.roleName == "TenantUser")
                        customizationUserAccountId = (Guid)user.createdUserID;
                    else
                        customizationUserAccountId = UserAccountId;

                    LoggerService("UserRole: " + user.roleName);
                    LoggerService("UserAccountId: " + customizationUserAccountId);

                    if (customizationUserAccountId != Guid.Empty)
                    {
                        var customizationSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.userAccountID == new Guid(\"{1}\")", NotificationProcessContext.AppId, customizationUserAccountId);
                        var customizations = _notificationService.GetCustomConfiguration(customizationSearch, NotificationProcessContext);
                        if (customizations == null || customizations.Count() <= 0)
                            customizationUserAccountId = UserAccountId;
                        //customizationUserAccountId = (customizations != null && customizations.Count() > 0) ? customizationUserAccountId : UserAccountId;
                    }
                    var userNameGroup = GetNotificationGroupContent("CredentialUserNameNotification", customizationUserAccountId);
                    var forgetPasswordGroup = GetNotificationGroupContent("ForgetPasswordNotification", customizationUserAccountId);
                    var accountExpiredGroup = GetNotificationGroupContent("AccountExpiredNotification", customizationUserAccountId);

                    var assessmentDeadlineGroup = GetAllNotificationGroupContent("AssessmentDeadlineGroup", customizationUserAccountId);
                    var accountExpiryGroup = GetAllNotificationGroupContent("AccountExpiryGroup", customizationUserAccountId);
                    //end

                    var accountExpirynotificationGroups = (from expiryGroupType in accountExpiryGroup
                                                           where expiryGroupType.notificationGroupTypeID == notificationGroup.notificationGroupTypeId
                                                           select expiryGroupType).FirstOrDefault();
                    if (accountExpirynotificationGroups != null)
                        isAccountExpiryGroup = true;
                    if (notificationGroup.notificationGroupTypeId.Equals(userNameGroup.notificationGroupTypeID) || notificationGroup.notificationGroupTypeId.Equals(forgetPasswordGroup.notificationGroupTypeID) || notificationGroup.notificationGroupTypeId.Equals(accountExpiredGroup.notificationGroupTypeID) || isAccountExpiryGroup == true)
                    {
                        var bccAddressCriteria = string.Empty;
                        if (notificationGroup.notificationGroupTypeId.Equals(accountExpiredGroup.notificationGroupTypeID) || isAccountExpiryGroup == true)
                            bccAddressCriteria = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.settingName == \"{1}\" && setting.isActive == true && setting.userAccountID ==new Guid(\"{2}\")", processContext.AppId, NotificationResource.AccountExpiryBCC, customizationUserAccountId);
                        else
                            bccAddressCriteria = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.settingName == \"{1}\" && setting.isActive == true && setting.userAccountID ==new Guid(\"{2}\")", processContext.AppId, NotificationResource.UserRegistrationBcc, UserAccountId);
                        var bccAddressSetting = _notificationService.GetConfigurationSetting(bccAddressCriteria, processContext).FirstOrDefault();

                        if (bccAddressSetting != null)
                        {
                            blindCopy = bccAddressSetting.settingValue;
                        }
                        else
                        {
                            blindCopy = notification.author;
                        }
                    }
                    //else
                    //{
                    //    blindCopy = null;
                    //}
                    var notificationGroupTypes = (from notificationGroupType in assessmentDeadlineGroup
                                                  where notificationGroupType.notificationGroupTypeID == notificationGroup.notificationGroupTypeId
                                                  select notificationGroupType).FirstOrDefault();

                    if (notificationGroupTypes!=null)
                    {
                        var bccReminderAddressCriteria = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.settingName == \"{1}\" && setting.isActive == true && setting.userAccountID ==new Guid(\"{2}\")", processContext.AppId, NotificationResource.AssessmentReminderBcc, customizationUserAccountId);
                        var bccReminderAddressSetting = _notificationService.GetConfigurationSetting(bccReminderAddressCriteria, processContext).FirstOrDefault();

                        var ccBccEmail = _notificationService.GetccBccEmailForProcessOwner(notificationGroup.groupID, processContext);
                        if (ccBccEmail.Count() == 0 && bccReminderAddressSetting != null)
                            blindCopy = bccReminderAddressSetting.settingValue;
                        if (ccBccEmail.Count() > 0)
                        {
                            var ccBccEmailRecipients = (from Email in ccBccEmail
                                                        select Email).FirstOrDefault();
                            blindCopy = ccBccEmailRecipients.BCCEmailAddress;
                            carbonCopy = ccBccEmailRecipients.CCEmailAddress;
                        }
                    }

                    string frequencyQuery = string.Format("frequency => frequency.notificationFrequencyID == new Guid(\"{0}\") && frequency.isActive == true", notification.notificationFrequencyID);
                    LoggerService(frequencyQuery);
                    var notificationFrequency = _notificationService.GetAllNotificationFrequency(frequencyQuery, processContext).FirstOrDefault();
                    var needEmail = IsEmailRequired(currentTime, notification, notificationFrequency, processContext);
                    LoggerService(needEmail.ToString());
                    if (needEmail)
                    {
                        var emailSent = false;
                        //string emailReceipientsCriteria = String.Format("emailReceipients => !string.IsNullOrEmpty(emailReceipients.emailAddress) && emailReceipients.notificationID == new Guid(\"{0}\") && emailReceipients.isActive == true && emailReceipients.notificationEmailStatusID == new Guid(\"{1}\")", notification.notificationID, notificationEmailUnsent.ToString());
                        var emailReceipients = _notificationService.GetAllEmailRecipients(notification.notificationID, processContext);
                        foreach (var emailReceipient in emailReceipients)
                        {
                            emailSent = SendEmail(notification.author, emailReceipient, blindCopy, carbonCopy, notification, processContext, customizationUserAccountId);
                        }
                        if (emailSent)
                        {
                            notification.notificationStatusID = notificationExpired;
                            notification.expirationDateTime = DateTime.Now;
                            UpdateNotification(notification, processContext);
                        }
                    }
                }
                LoggerService("Outside foreach notif...");
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("Email Notification Worker Role", "NotifyUser",
                                  exception.Message,
                                  exception.InnerException == null
                                      ? exception.Message
                                      : exception.InnerException.Message, exception.StackTrace,
                                  ExceptionProcessContext);
            }

            LoggerService("ProcessAllEmailNotifications method Complted...");
        }

        /// <summary>
        /// Get the notification group content based in useraccountid
        /// </summary>
        /// <param name="frequency">frequency</param>
        /// <param name="customizationUserAccountId">customization User AccountId</param>
        /// <returns>Notification group type</returns>
        private EfortressService.NotificationServiceReference.NotificationGroupType GetNotificationGroupContent(string frequencyOrGroupName, Guid customizationUserAccountId)
        {
            string notificationQuery = string.Empty;
            switch (frequencyOrGroupName)
            {
                case "CredentialUserNameNotification":
                    notificationQuery = String.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"CredentialUserNameNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
                case "ForgetPasswordNotification":
                    notificationQuery = String.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"ForgetPasswordNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
                case "AccountExpiredNotification":
                    notificationQuery = String.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"AccountExpiredNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
            }
            var expiryNotificationGroup = _notificationService.GetAllNotificationGroupType(
                    notificationQuery, NotificationProcessContext).FirstOrDefault();
            return expiryNotificationGroup;
        }

        /// <summary>
        /// Get the notification group content based in useraccountid
        /// </summary>
        /// <param name="frequency">frequency</param>
        /// <param name="customizationUserAccountId">customization User AccountId</param>
        /// <returns>Notification group type</returns>
        public IList<EfortressService.NotificationServiceReference.NotificationGroupType> GetAllNotificationGroupContent(string frequencyOrGroupName, Guid customizationUserAccountId)
        {
            string notificationQuery = string.Empty;
            switch (frequencyOrGroupName)
            {
                case "AssessmentDeadlineGroup":
                    notificationQuery = String.Format("notificationGroupTypes => (notificationGroupTypes.groupName == \"FirstAssessmentDeadlineNotification\" || notificationGroupTypes.groupName == \"SecondAssessmentDeadlineNotification\" || notificationGroupTypes.groupName == \"ThirdAssessmentDeadlineNotification\" || notificationGroupTypes.groupName == \"FourthAssessmentDeadlineNotification\" || notificationGroupTypes.groupName == \"AssessmentCompletedNotification\")  && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
                case "AccountExpiryGroup":
                    notificationQuery = String.Format("notificationGroupTypes => (notificationGroupTypes.groupName == \"FirstAccountExpiryNotification\" || notificationGroupTypes.groupName == \"SecondAccountExpiryNotification\" || notificationGroupTypes.groupName == \"ThirdAccountExpiryNotification\" || notificationGroupTypes.groupName == \"FourthAccountExpiryNotification\")  && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
            }
            var expiryNotificationGroup = _notificationService.GetAllNotificationGroupType(
                    notificationQuery, NotificationProcessContext);
            return expiryNotificationGroup;
        }

        /// <summary>
        /// Update the status of each notification
        /// </summary>
        /// <param name="processContext">process context</param>
        private void UpdateNotificationStatus(ProcessContext processContext)
        {
            try
            {
                //LoggerService("Inside UpdateNotificationStatus...");
                _notificationService.UpdateNotificationStatus(processContext);
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("Email Notification Worker Role", "NotifyUser",
                                  exception.Message,
                                  exception.InnerException == null
                                      ? exception.Message
                                      : exception.InnerException.Message, exception.StackTrace,
                                  ExceptionProcessContext);
            }
        }

        /// <summary>
        /// The business logic to decide whether an email alert is required for the given notification based on the frequency setting
        /// </summary>
        /// <param name="currentTime">current system time</param>
        /// <param name="notification">notification entry</param>
        /// <param name="frequencyInfo">notification frequency details</param>
        /// <param name="processContext">process context</param>
        /// <returns>a boolean value indicating, whether email is required</returns>
        private bool IsEmailRequired(DateTime currentTime, Notification notification, NotificationFrequency frequencyInfo, ProcessContext processContext)
        {
            try
            {
                // Get the frequency duration type: DAY, MONTH, or YEAR
                var frequencyDurationType = GetCodeList(frequencyInfo.frequencyDurationTypeID, processContext);
                var monthsApart = 12 * (currentTime.Year - notification.startDateTime.Year) + currentTime.Month - notification.startDateTime.Month;
                var daysApart = (int)(currentTime - notification.startDateTime).TotalDays;

                string statusQuery = string.Format("status => status.notificationID == new Guid(\"{0}\") && status.isActive == true", notification.notificationID);
                var notificationEmailStatus = _notificationService.GetNotificationEmailStatus(statusQuery, processContext).FirstOrDefault();
                var emailUnSentStatus = GetCodeList(ConfigurationManager.AppSettings[NotificationResource.EMAIL_STATUSCODE], ConfigurationManager.AppSettings[NotificationResource.EMAIL_ERROR], processContext);
                // One time email alert
                if (frequencyDurationType.codeValue == "DAY" && frequencyInfo.frequencyDuration == 0)
                {

                    if (notificationEmailStatus == null || notificationEmailStatus.notificationEmailStatusID == emailUnSentStatus)
                    {
                        //if (currentTime.Subtract(notification.startDateTime.AddDays(daysApart)).Hours == 0 && currentTime.Subtract(notification.startDateTime.AddDays(daysApart)).Minutes < 15)
                        {
                            notification.expirationDateTime = currentTime;
                            return true;
                        }
                        //return false;
                    }
                    return false;
                }
                // any other day interval like weekly, every two weeks etc
                if (frequencyDurationType.codeValue == "DAY" && frequencyInfo.frequencyDuration != 0)
                {
                    bool flag = (currentTime.Subtract(notification.startDateTime).Days % frequencyInfo.frequencyDuration) == 0 &&
                           (currentTime.Subtract(notification.startDateTime.AddDays(daysApart)).Hours == 0 &&
                            currentTime.Subtract(notification.startDateTime.AddDays(daysApart)).Minutes < 15);
                    return flag;
                }
                // frequency duration like monthly, bimonthly, once in 6 months etc
                if (frequencyDurationType.codeValue == "MONTH" && frequencyInfo.frequencyDuration != 0)
                {
                    return (monthsApart > 0 || (monthsApart == 0 && daysApart == 0)) && monthsApart % frequencyInfo.frequencyDuration == 0 &&
                           (currentTime.Subtract(notification.startDateTime.AddMonths(monthsApart)).Days == 0 &&
                            currentTime.Subtract(notification.startDateTime.AddMonths(monthsApart)).Hours == 0 &&
                            currentTime.Subtract(notification.startDateTime.AddMonths(monthsApart)).Minutes < 15);
                }
                // frequency duration like annually, once in 2 years etc
                if (frequencyDurationType.codeValue == "YEAR" && frequencyInfo.frequencyDuration != 0)
                {
                    return (monthsApart == 0 || monthsApart >= 12) && monthsApart % (frequencyInfo.frequencyDuration * 12) == 0 &&
                           (currentTime.Subtract(notification.startDateTime.AddMonths(monthsApart)).Days == 0 &&
                            currentTime.Subtract(notification.startDateTime.AddMonths(monthsApart)).Hours == 0 &&
                            currentTime.Subtract(notification.startDateTime.AddMonths(monthsApart)).Minutes < 15);
                }
                return false;

            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("Email Notification Worker Role", "NotifyUser",
                                  exception.Message,
                                  exception.InnerException == null
                                      ? exception.Message
                                      : exception.InnerException.Message, exception.StackTrace,
                                  ExceptionProcessContext);
            }
            return false;
        }

        /// <summary>
        /// Add email delivery status history
        /// </summary>
        /// <param name="emailSentStatus">email Sent Status</param>
        /// <param name="processContext">process context</param>
        private void AddEmailStatusHistory(Guid emailSentStatus, NotificationUserList emailReceipient, Notification notification, string emailStatusMessage, ProcessContext processContext)
        {
            try
            {
                var notificationEmailStatusHistory = new NotificationEmailStatusHistory
                {
                    notificationEmailStatusHistoryID = Guid.NewGuid(),
                    notificationID = notification.notificationID,
                    userAccountID = emailReceipient.UserAccountId,
                    notificationStateID = notification.notificationStatusID,
                    emailAddress = emailReceipient.EmailAddress,
                    notificationEmailStatusID = emailSentStatus,
                    emailStatusMessage = emailStatusMessage,
                    isActive = true,
                    createdDatetime = DateTime.Now,
                    createdUserID = new Guid(ConfigurationManager.AppSettings[NotificationResource.DefaultUserId]),
                    lastModifiedDateTime = DateTime.Now,
                    lastModifiedUserID = new Guid(ConfigurationManager.AppSettings[NotificationResource.DefaultUserId]),
                    changeReason = null,
                    changeCount = 0,
                    applicationID = processContext.AppId
                };
                var notificationEmailStatusHistoryList = new List<NotificationEmailStatusHistory> { notificationEmailStatusHistory };
                _notificationService.AddNotificationEmailStatusHistory(notificationEmailStatusHistoryList.ToArray(), processContext);
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("Email Notification Worker Role", "NotifyUser",
                                  exception.Message,
                                  exception.InnerException == null
                                      ? exception.Message
                                      : exception.InnerException.Message, exception.StackTrace,
                                  ExceptionProcessContext);
            }
        }

        /// <summary>
        /// Update the notification status
        /// </summary>
        /// <param name="notificationMessage">notification to be updated</param>
        /// <param name="processContext">process context</param>
        private void UpdateNotification(Notification notificationMessage, ProcessContext processContext)
        {
            try
            {
                notificationMessage.lastModifiedDateTime = DateTime.Now;
                notificationMessage.lastModifiedUserID = new Guid(ConfigurationManager.AppSettings[NotificationResource.DefaultUserId]);

                SqlConnection connection = new SqlConnection();
                DataSet notificationDataSet = new DataSet();
                SqlDataAdapter dataAdapter;
                SqlCommandBuilder cmdBuilder;

                connection.ConnectionString = ConfigurationManager.AppSettings[NotificationResource.SQLConnectionString];
                connection.Open();
                string sqlQuery = string.Format("select * from [SaaS].Notification where notificationID = '{0}'",
                                                notificationMessage.notificationID);
                dataAdapter = new SqlDataAdapter(sqlQuery, connection);
                cmdBuilder = new SqlCommandBuilder(dataAdapter);
                dataAdapter.Fill(notificationDataSet, "Notifications");
                notificationDataSet.Tables["Notifications"].Rows[0]["notificationStatusID"] = notificationMessage.notificationStatusID;
                notificationDataSet.Tables["Notifications"].Rows[0]["expirationDateTime"] = notificationMessage.expirationDateTime;
                dataAdapter.Update(notificationDataSet, "Notifications");
                connection.Close();

                // _notificationService.UpdateNotification(notificationMessage, null, processContext);
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("Email Notification Worker Role", "NotifyUser",
                                  exception.Message,
                                  exception.InnerException == null
                                      ? exception.Message
                                      : exception.InnerException.Message, exception.StackTrace,
                                  ExceptionProcessContext);
            }
        }

        /// <summary>
        /// Get Code List entries based on code set name and value
        /// </summary>
        /// <param name="codeSetName">code set name</param>
        /// <param name="codeValue">code set value</param>
        /// <param name="processContext">process context</param>
        /// <returns>code list id of the selected code list</returns>
        private Guid GetCodeList(string codeSetName, string codeValue, ProcessContext processContext)
        {
            try
            {
                var codeListCriteria =
                    String.Format("codeList => codeList.statusCodeName == \"{0}\" && codeList.codeValue == \"{1}\" && codeList.isActive == true", codeSetName, codeValue);
                var codeListRow = _notificationService.GetStatusCode(codeListCriteria, processContext);
                return codeListRow[0].statusCodeID;
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("Email Notification Worker Role", "NotifyUser",
                                  exception.Message,
                                  exception.InnerException == null
                                      ? exception.Message
                                      : exception.InnerException.Message, exception.StackTrace,
                                  ExceptionProcessContext);
            }
            return default(Guid);
        }

        /// <summary>
        /// Gets the code list row for a given code list id
        /// </summary>
        /// <param name="codeListId">code list id</param>
        /// <param name="processContext">process context</param>
        /// <returns>matching code list row</returns>
        private StatusCode GetCodeList(Guid codeListId, ProcessContext processContext)
        {
            try
            {
                var codeListCriteria =
                    String.Format("codeList => codeList.statusCodeID == new Guid(\"{0}\") && codeList.isActive == true", codeListId);
                if (_notificationService != null)
                {
                    return _notificationService.GetStatusCode(codeListCriteria, processContext).FirstOrDefault();
                }
                return default(StatusCode);
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("Email Notification Worker Role", "NotifyUser",
                                  exception.Message,
                                  exception.InnerException == null
                                      ? exception.Message
                                      : exception.InnerException.Message, exception.StackTrace,
                                  ExceptionProcessContext);
            }
            return default(StatusCode);
        }

        /// <summary>
        /// Send email alert using SMTP server
        /// </summary>
        /// <param name="mailFrom">email from address</param>
        /// <param name="emailReceipient">email To address</param>
        /// <param name="notificationMessage">email message</param>
        /// <param name="processContext">process context</param>
        private bool SendEmail(string mailFrom, NotificationUserList emailReceipient, string blindCopy, string carbonCopy, Notification notificationMessage, ProcessContext processContext,Guid customizationUserAccountId)
        {
            try
            {
                //LoggerService("SendEmail method started...");
                if (!string.IsNullOrEmpty(emailReceipient.EmailAddress))
                {
                    var decodedMessage = HttpUtility.HtmlDecode(notificationMessage.message);
                    var message = new MailMessage(mailFrom, emailReceipient.EmailAddress,
                                                  notificationMessage.subjectLine, decodedMessage) { IsBodyHtml = true };
                    if (blindCopy != null)
                    {
                        MailAddress bcc = new MailAddress(blindCopy);
                        message.Bcc.Add(bcc);
                    }
                    if (carbonCopy != null)
                    {
                        MailAddress cc = new MailAddress(carbonCopy);
                        message.CC.Add(cc);
                    }
                    // Process Attachment if any
                    if (notificationMessage.attachment != null)
                    {
                        Stream stream = new MemoryStream(notificationMessage.attachment);
                        var attachment = new Attachment(stream, "Feedback.pdf");

                        message.Attachments.Add(attachment);
                    }
                    customizationAccountId = customizationUserAccountId;
                    if (EmailClient != null)
                    {
                        EmailClient.Send(message);
                    }
                    var emailSentStatus =
                        GetCodeList(ConfigurationManager.AppSettings[NotificationResource.EMAIL_STATUSCODE],
                                    ConfigurationManager.AppSettings[NotificationResource.EMAIL_SENT], processContext);
                    AddEmailStatusHistory(emailSentStatus, emailReceipient, notificationMessage, "Successful", processContext);
                    return true;
                }
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("Email Notification Worker Role", "NotifyUser",
                                  exception.Message + "From Email=" + mailFrom + ";To=" + emailReceipient.EmailAddress + ";Host=" + EmailClient.Host + ";port=" + EmailClient.Port + ";username=" + (EmailClient.Credentials as NetworkCredential).UserName + ";Password=" + (EmailClient.Credentials as NetworkCredential).Password,
                                  exception.InnerException == null
                                      ? exception.Message
                                      : exception.InnerException.Message, exception.StackTrace,
                                  ExceptionProcessContext);
            }
            return false;
        }

        private bool UpdateNotificationUserListEmailStatus(NotificationUserList emailReceipient, Guid emailSentStatus, ProcessContext processContext)
        {
            try
            {
                //emailReceipient.notificationEmailStatusID = emailSentStatus;
                //_notificationService.UpdateNotificationUserListEmailStatus(emailReceipient, processContext);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// A method which reads the service binding configuration details
        /// </summary>
        /// <param name="binding">BasicHttpBinding variable</param>
        private void ConfigureBinding(BasicHttpBinding binding)
        {
            try
            {
                if (binding != null)
                {
                    binding.MaxBufferPoolSize = Int32.Parse(ConfigurationManager.AppSettings[NotificationResource.MaxBufferPoolSize]);
                    binding.MaxReceivedMessageSize = Int32.Parse(ConfigurationManager.AppSettings[NotificationResource.MaxReceivedMessageSize]);
                    binding.MaxBufferSize = Int32.Parse(ConfigurationManager.AppSettings[NotificationResource.MaxBufferSize]);
                    binding.MaxBufferPoolSize = Int32.Parse(ConfigurationManager.AppSettings[NotificationResource.MaxBufferPoolSize]);
                    binding.ReaderQuotas.MaxDepth = Int32.Parse(ConfigurationManager.AppSettings[NotificationResource.ReaderQuotasMaxDepth]);
                    binding.ReaderQuotas.MaxArrayLength = Int32.Parse(ConfigurationManager.AppSettings[NotificationResource.ReaderQuotasMaxArrayLength]);
                    binding.ReaderQuotas.MaxStringContentLength = Int32.Parse(ConfigurationManager.AppSettings[NotificationResource.ReaderQuotasMaxStringContentLength]);
                }
            }
            catch (Exception exception)
            {
                EventLog.WriteEntry(NotificationResource.NotificationAlert, exception.Message);
            }
        }

        /// <summary>
        /// Returns the current status of the Notification based on startDate, expiryDate and currentDate
        /// </summary>
        /// <param name="startDate">Notification start date</param>
        /// <param name="expiryDate">Notification expiry date</param>
        /// <param name="processContext">process context</param>
        /// <returns>CodeListID of the Notification status</returns>
        private Guid GetNotificationStatusByDate(DateTime startDate, DateTime expiryDate, ProcessContext processContext)
        {
            var codeSetName = ConfigurationManager.AppSettings[NotificationResource.NOTIFICATION_STATUSCODE];
            var codeValue = string.Empty;

            if (startDate > DateTime.Now)
            {
                codeValue = ConfigurationManager.AppSettings[NotificationResource.NOTIFICATION_INQUEUE];
            }
            if (startDate <= DateTime.Now && expiryDate.Date > DateTime.Now.Date)
            {
                codeValue = ConfigurationManager.AppSettings[NotificationResource.NOTIFICATION_ACTIVE];
            }
            if (expiryDate.Date <= DateTime.Now.Date)
            {
                codeValue = ConfigurationManager.AppSettings[NotificationResource.NOTIFICATION_EXPIRED];
            }
            // Get the status code for Notification
            return GetCodeList(codeSetName, codeValue, processContext);
        }

        private Guid GetCodeListId(IList<StatusCode> statusCodeLists, string codeSetName, string codeValue)
        {
            foreach (var statusCodeList in statusCodeLists)
            {
                if (statusCodeList.codeValue == codeValue && statusCodeList.statusCodeName == codeSetName)
                {
                    return statusCodeList.statusCodeID;
                }
            }
            return Guid.Empty;
        }
        #endregion

        private void LoggerService(string stringdata)
        {
            //string writeLog = ConfigurationManager.AppSettings[AccountManagementResource.WriteLog];
            //if (writeLog == "ON")
            //{
            //    string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            //    message += Environment.NewLine;
            //    message += "-----------------------------------------------------------";
            //    message += Environment.NewLine;
            //    message += string.Format("Message: {0}", stringdata);
            //    message += Environment.NewLine;
            //    message += "-----------------------------------------------------------";
            //    FileStream fs = new FileStream(ConfigurationManager.AppSettings[NotificationResource.EmailNotificationLoggerPath], FileMode.OpenOrCreate, FileAccess.Write);
            //    StreamWriter sw = new StreamWriter(fs);
            //    sw.BaseStream.Seek(0, SeekOrigin.End);
            //    sw.WriteLine(message);
            //    sw.Flush();
            //    sw.Close();
            //}
        }  
    }
}
