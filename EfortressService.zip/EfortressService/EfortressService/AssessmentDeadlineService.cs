﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using EfortressService.AssessmentDeadlineProcess;
using System.IO;

namespace EfortressService
{
    partial class AssessmentDeadlineService : ServiceBase
    {
        Thread _importWorkerThread = null;
        public AssessmentDeadlineService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                // TODO: Add code here to start your service.
                LoggerService("Assessment Service Started");
                AssessmentDeadline assesment = new AssessmentDeadline();
                ThreadStart threadstart = new ThreadStart(assesment.ProcessAccount);
                _importWorkerThread = new Thread(threadstart);
                _importWorkerThread.Start();
                LoggerService("Thread Started");
            }
            catch (Exception)
            {
                throw;
            }
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
        }

        private void LoggerService(string stringdata)
        {
            //string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            //message += Environment.NewLine;
            //message += "-----------------------------------------------------------";
            //message += Environment.NewLine;
            //message += string.Format("Message: {0}", stringdata);
            //message += Environment.NewLine;
            //message += "-----------------------------------------------------------";
            //FileStream fs = new FileStream(@"C:\EFTEST\Log.txt", FileMode.OpenOrCreate, FileAccess.Write);
            //StreamWriter sw = new StreamWriter(fs);
            //sw.BaseStream.Seek(0, SeekOrigin.End);
            //sw.WriteLine(message);
            //sw.Flush();
            //sw.Close();
        }  
    }
}
