﻿#region ©eFortresses 2011, 2012.  All Rights Reserved.

/*------------------------------------------------------------------------------*
 *                                                                              *
 * the information contained herein is proprietary to eFortresses               *
 *                                                                              *
 * and shall not be reproduced, copied in whole or in part, adapted, modified,  * 
 *                                                                              *
 * or disseminated without the express written consent of eFortresses           *
 *                                                                              *
 *------------------------------------------------------------------------------*/
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using EfortressService.NotificationServiceReference;
using EfortressService.ExceptionServiceReference;
using EfortressService.AccountManagementServiceReference;
using System.Configuration;
using NotificationGroup = EfortressService.NotificationServiceReference.NotificationGroup;
using Notification = EfortressService.NotificationServiceReference.Notification;
using ProcessContext = eFortresses.ProviderFramework.ProcessContext;
using eFortresses.AssessmentDeadlineProcess;
using eFortresses;
using System.IO;
using System.Timers;

namespace EfortressService.AssessmentDeadlineProcess
{
    public class AssessmentDeadline
    {
        private readonly Object ObjLock = new Object();
        // the thread that will do Notification processing
        private Thread _workerThread;
        /// <summary>
        /// A reference to Notification service
        /// </summary>
        private NotificationServiceReference.NotificationServiceClient _notificationService = new NotificationServiceClient();

        /// <summary>
        /// A reference to Exception service
        /// </summary>
        private ExceptionServiceReference.ExceptionServiceClient _exceptionServiceClient = new ExceptionServiceClient();

        /// <summary>
        /// A reference to Account Management service
        /// </summary>
        private AccountManagementServiceReference.AccountManagementServiceClient _accountManagementServiceClient = new AccountManagementServiceClient();

        private Guid _applicationId;
        private Guid _userAccountId;
        private ExceptionServiceReference.ProcessContext _exceptionProcessContext = null;
        private AccountManagementServiceReference.ProcessContext _accountProcessContext = null;
        private NotificationServiceReference.ProcessContext _notificationProcessContext = null;

        #region Internal Properties
        public Guid ApplicationId
        {
            get
            {
                if (_applicationId == Guid.Empty)
                {
                    var searchQuery = String.Format("app => app.applicationName == \"{0}\"", ConfigurationManager.AppSettings[AssessmentDeadlineResource.ApplicationName]);

                    _applicationId =
                        _accountManagementServiceClient.GetApplicationId(searchQuery);
                    return _applicationId;
                }
                return _applicationId;
            }
        }

        public Guid UserAccountId
        {
            get
            {
                if (_userAccountId == Guid.Empty)
                {
                    _userAccountId = new Guid(ConfigurationManager.AppSettings[AssessmentDeadlineResource.DefaultUserAccountID]);

                    return _userAccountId;
                }
                return _userAccountId;
            }
        }



        public ExceptionServiceReference.ProcessContext ExceptionProcessContext
        {
            get
            {
                if (_exceptionProcessContext == null)
                {
                    _exceptionProcessContext = new ExceptionServiceReference.ProcessContext { UserId = UserAccountId, AppId = ApplicationId };
                    return _exceptionProcessContext;
                }
                return _exceptionProcessContext;
            }
        }
        public AccountManagementServiceReference.ProcessContext AccountProcessContext
        {
            get
            {
                if (_accountProcessContext == null)
                {
                    _accountProcessContext = new AccountManagementServiceReference.ProcessContext { UserId = UserAccountId, AppId = ApplicationId };
                    return _accountProcessContext;
                }
                return _accountProcessContext;
            }
        }
        public NotificationServiceReference.ProcessContext NotificationProcessContext
        {
            get
            {
                if (_notificationProcessContext == null)
                {
                    _notificationProcessContext = new NotificationServiceReference.ProcessContext { UserId = UserAccountId, AppId = ApplicationId };
                    return _notificationProcessContext;
                }
                return _notificationProcessContext;
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Gets invoked at regular interval for processing notifications
        /// </summary>
        /// <param name="state"></param>
        public void ScheduledAccountManagement(Object state)
        {
            var threadStart = new ThreadStart(ProcessAccount);
            _workerThread = new Thread(threadStart);
            _workerThread.Start();
        }

        public void ProcessAccount()
        {
            //lock (ObjLock)
            {
                System.Timers.Timer assessmentDeadlineTimer = new System.Timers.Timer();

                try
                {
                    LoggerService("Assessment ProcessAccount Method Started");
                    assessmentDeadlineTimer.Stop();

                    NotifyAssessmentDeadline();
                    NotifyAssessmentCompletion();

                    assessmentDeadlineTimer.Elapsed += new ElapsedEventHandler(assessmentDeadlineTimer_Elapsed);
                    assessmentDeadlineTimer.Interval = 86400000;  //24 Hours
                    assessmentDeadlineTimer.Start();
                }
                catch (Exception exception)
                {
                    _exceptionServiceClient.AddException("SaaS Framework", "Assessment Deadline Worker Role",
                                                         exception.Message,
                                                         exception.InnerException == null
                                                             ? exception.Message
                                                             : exception.InnerException.Message, exception.StackTrace,
                                                         ExceptionProcessContext);
                }
            }
        }

        private void assessmentDeadlineTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            ProcessAccount();
        }

        #endregion

        #region Private Methods


        /// <summary>
        /// 
        /// </summary>
        private void NotifyAssessmentCompletion()
        {
            try
            {
                LoggerService("Inside NotifyAssessmentCompletion Method Started");
                // Get the active notification status
                const string activeStatusQuery = "statusCodes => statusCodes.statusCodeName == \"NotificationStatus\" && statusCodes.codeValue == \"Active\" && statusCodes.isActive == true";
                var activeStatus = _notificationService.GetStatusCode(activeStatusQuery, NotificationProcessContext).FirstOrDefault();

                // Get id for one time notification
                const string onetimeNotificationFrequencyQuery = "notificationFrequency => notificationFrequency.frequencyName == \"One Time\" && notificationFrequency.isActive == true";
                var onetimeNotificationFrequency =
                    _notificationService.GetAllNotificationFrequency(onetimeNotificationFrequencyQuery,
                                                                     NotificationProcessContext).FirstOrDefault();

                var completionNotificationGroup = GetNotificationGroupContent("AssessmentCompletedNotification", UserAccountId);
                var priorExpiryMessageTemplate = completionNotificationGroup.content;

                var productName = GetApplicationCustomConfigurationSetting("ProductName", UserAccountId) ?? "CloudeAssurance";
                var companyName = GetApplicationCustomConfigurationSetting("CompanyName", UserAccountId) ?? "eFortresses";
                var applicationUrl = GetApplicationConfigurationSetting("ApplicationUrl", UserAccountId) ?? "https://azure.cloudeassurance.com";
                var emailFromAddress = GetApplicationConfigurationSetting("EmailServerFrom", UserAccountId) ?? "products@eFortresses.com";

                var assessmentdeadlineRepository = new AssessmentDeadlineRepository();
                ProcessContext processContext = new ProcessContext { UserId = UserAccountId, AppId = ApplicationId };
                var deadlineAssessments = assessmentdeadlineRepository.GetCompletedAssessmentDetails(processContext);
                var notificationGroups = new List<NotificationGroup>();
                foreach (var deadlineAssessment in deadlineAssessments)
                {
                     var processOwnerUsers = assessmentdeadlineRepository.GetProcessOwnerForAssessmentCompleted(deadlineAssessment.assessmentDetailID, processContext);
                     if (processOwnerUsers.Count() > 0)
                     {
                         foreach (var processOwner in processOwnerUsers)
                         {
                             //Added for task# 462
                             Guid customizationUserAccountId = Guid.Empty;
                             if (processOwner.tenantuserId == Guid.Empty)
                                 customizationUserAccountId = processOwner.UserId;
                             else
                                 customizationUserAccountId = processOwner.tenantuserId;
                             if (customizationUserAccountId != Guid.Empty)
                             {
                                 var customizationSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.userAccountID == new Guid(\"{1}\")", NotificationProcessContext.AppId, customizationUserAccountId);
                                 var customizations = _notificationService.GetCustomConfiguration(customizationSearch, NotificationProcessContext);
                                 if (customizations != null && customizations.Count() > 0)
                                 {
                                     priorExpiryMessageTemplate = GetNotificationGroupContent("AssessmentCompletedNotification", customizationUserAccountId).content;
                                     productName = GetApplicationCustomConfigurationSetting("ProductName", customizationUserAccountId) ?? "CloudeAssurance";
                                     companyName = GetApplicationCustomConfigurationSetting("CompanyName", customizationUserAccountId) ?? "eFortresses";
                                     emailFromAddress = GetApplicationConfigurationSetting("EmailServerFrom", customizationUserAccountId) ?? "products@eFortresses.com";
                                 }
                             }
                             //end

                             var priorExpiryMessage = string.Format(priorExpiryMessageTemplate, processOwner.firstName + " " + processOwner.lastName,
                                                          processOwner.assessmentName, processOwner.companyProfileName, productName);
                             var notificationExpiry = new Notification()
                             {
                                 notificationID = Guid.NewGuid(),
                                 author = emailFromAddress,
                                 subjectLine = "Assessment completed Notification",
                                 message = priorExpiryMessage,
                                 notificationStatusID = activeStatus.statusCodeID,
                                 notificationFrequencyID =
                                     onetimeNotificationFrequency.notificationFrequencyID,
                                 displayDuration = 0,
                                 isEmailRequired = true,
                                 startDateTime = DateTime.Now,
                                 expirationDateTime = DateTime.Now.AddDays(7),
                                 createdDateTime = DateTime.Now,
                                 createdUserID = processOwner.UserId,
                                 lastModifiedDateTime = DateTime.Now,
                                 lastModifiedUserID = processOwner.UserId,
                                 isActive = true,
                                 changeReason = null,
                                 changeCount = 0,
                                 applicationID = ApplicationId
                             };

                             var notificationGroup = new NotificationGroup()
                             {
                                 notificationGroupID = Guid.NewGuid(),
                                 notificationID = notificationExpiry.notificationID,
                                 groupID = processOwner.UserId,
                                 notificationGroupTypeId = completionNotificationGroup.notificationGroupTypeID,
                                 isActive = true,
                                 createdDatetime = DateTime.Now,
                                 createdUserID = processOwner.UserId,
                                 lastModifiedDateTime = DateTime.Now,
                                 lastModifiedUserID = processOwner.UserId,
                                 changeReason = null,
                                 changeCount = 0,
                                 applicationID = ApplicationId
                             };

                             notificationGroups.Add(notificationGroup);
                             _notificationService.CreateNotification(notificationExpiry, notificationGroups.ToArray(), NotificationProcessContext);
                             notificationGroups.Clear();
                         }
                     }
                     assessmentdeadlineRepository.UpdateAssessmentCompletedEmailSent(deadlineAssessment.assessmentDetailID, processContext);
                }
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("SaaS Framework", "Assessment Deadline Worker Role",
                                                     exception.Message,
                                                     exception.InnerException == null
                                                         ? exception.Message
                                                         : exception.InnerException.Message, exception.StackTrace,
                                                     ExceptionProcessContext);
            }
        }

        private void NotifyAssessmentDeadline()
        {
            try
            {
                LoggerService("Inside NotifyAssessmentDeadline Method Started");
                //Added for task# 462
                Guid cutomizationUserAccountId = Guid.Empty;
                string accountSearch = String.Format("userdetail => userdetail.isActive == true && (userdetail.roleName==\"{0}\" || userdetail.roleName==\"{1}\")", "TenantAdministrator", "eFortressesAdministator");
                var tenantAdminUsers = _accountManagementServiceClient.GetAllCustomers(accountSearch, AccountProcessContext, null, 0, 0);
                foreach (var tenantAdmin in tenantAdminUsers)
                {
                    var customizationSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.userAccountID == new Guid(\"{1}\")", NotificationProcessContext.AppId, tenantAdmin.userAccountID);
                    var customizations = _notificationService.GetCustomConfiguration(customizationSearch, NotificationProcessContext);
                    if (customizations != null && customizations.Count() > 0)
                        cutomizationUserAccountId = tenantAdmin.userAccountID;
                    else
                        cutomizationUserAccountId = UserAccountId;
                    //Guid cutomizationUserAccountId = customizations != null && customizations.Count() > 0 ? tenantAdmin.userAccountID : UserAccountId;

                    var fourthNotificationSettingValue = GetApplicationConfigurationSetting(AssessmentDeadlineResource.NotifyFourthAssessmentDeadline, cutomizationUserAccountId);
                    // Fourth alert of assessment deadline
                    EmailNotifyAssessmentDeadlineExpiry(int.Parse(fourthNotificationSettingValue), "FOURTH", tenantAdmin.userAccountID);

                    var thirdNotificationSettingValue = GetApplicationConfigurationSetting(AssessmentDeadlineResource.NotifyThirdAssessmentDeadline, cutomizationUserAccountId);
                    // Third alert of assessment deadline
                    EmailNotifyAssessmentDeadlineExpiry(int.Parse(thirdNotificationSettingValue), "THIRD", tenantAdmin.userAccountID);

                    var secondNotificationSettingValue = GetApplicationConfigurationSetting(AssessmentDeadlineResource.NotifySecondAssessmentDeadline, cutomizationUserAccountId);
                    // Second alert of account expiry
                    EmailNotifyAssessmentDeadlineExpiry(int.Parse(secondNotificationSettingValue), "SECOND",tenantAdmin.userAccountID);

                    var firstNotificationSettingValue = GetApplicationConfigurationSetting(AssessmentDeadlineResource.NotifyFirstAssessmentDeadline, cutomizationUserAccountId);
                    // First alert of account expiry
                    EmailNotifyAssessmentDeadlineExpiry(int.Parse(firstNotificationSettingValue), "FIRST", tenantAdmin.userAccountID);
                }
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("SaaS Framework", "Assessment Deadline Worker Role",
                                                     exception.Message,
                                                     exception.InnerException == null
                                                         ? exception.Message
                                                         : exception.InnerException.Message, exception.StackTrace,
                                                     ExceptionProcessContext);
            }
        }

        private void EmailNotifyAssessmentDeadlineExpiry(int days, string frequency,Guid tenantAdminUserAccountId)
        {
            try
            {
                int NoofDays = DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month) - days;
                var expiryBeforeDays = DateTime.Now.AddDays(-NoofDays).Date;

                // Get the active notification status
                var activeStatusQuery =
                    "statusCodes => statusCodes.statusCodeName == \"NotificationStatus\" && statusCodes.codeValue == \"Active\" && statusCodes.isActive == true";
                var activeStatus = _notificationService.GetStatusCode(activeStatusQuery, NotificationProcessContext).FirstOrDefault();

                // Get id for one time notification
                var onetimeNotificationFrequencyQuery =
                    "notificationFrequency => notificationFrequency.frequencyName == \"One Time\" && notificationFrequency.isActive == true";
                var onetimeNotificationFrequency =
                    _notificationService.GetAllNotificationFrequency(onetimeNotificationFrequencyQuery,
                                                                     NotificationProcessContext).FirstOrDefault();

                var expiryNotificationGroup = GetNotificationGroupContent(frequency, UserAccountId);
                var priorExpiryMessageTemplate = expiryNotificationGroup.content;

                var productName = GetApplicationCustomConfigurationSetting("ProductName", UserAccountId) ?? "CloudeAssurance";
                var applicationUrl = GetApplicationConfigurationSetting("ApplicationUrl", UserAccountId) ?? "https://azure.cloudeassurance.com";
                var emailFromAddress = GetApplicationConfigurationSetting("EmailServerFrom", UserAccountId) ?? "products@eFortresses.com";

                var assessmentdeadlineRepository = new AssessmentDeadlineRepository();
                ProcessContext processContext = new ProcessContext { UserId = UserAccountId, AppId = ApplicationId };
                var deadlineAssessments = assessmentdeadlineRepository.GetAssessmentDetails(expiryBeforeDays,tenantAdminUserAccountId, processContext);
                var notificationGroups = new List<NotificationGroup>();
                foreach (var deadlineAssessment in deadlineAssessments)
                {
                    var processOwnerUsers = assessmentdeadlineRepository.GetProcessOwnerForAssessment(deadlineAssessment.assessmentDetailID, processContext);
                    if (processOwnerUsers.Count() > 0)
                    {
                        foreach (var processOwner in processOwnerUsers)
                        {
                            //Added for task# 462
                            Guid customizationUserAccountId = Guid.Empty;
                            if (processOwner.tenantuserId == null || processOwner.tenantuserId == Guid.Empty)
                                customizationUserAccountId = processOwner.UserId;
                            else
                                customizationUserAccountId = processOwner.tenantuserId;
                            if (customizationUserAccountId != Guid.Empty)
                            {
                                var customizationSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.userAccountID == new Guid(\"{1}\")", NotificationProcessContext.AppId, customizationUserAccountId);
                                var customizations = _notificationService.GetCustomConfiguration(customizationSearch, NotificationProcessContext);
                                if (customizations != null && customizations.Count() > 0)
                                {
                                    priorExpiryMessageTemplate = GetNotificationGroupContent(frequency, customizationUserAccountId).content;
                                    productName = GetApplicationCustomConfigurationSetting("ProductName", customizationUserAccountId) ?? "CloudeAssurance";
                                    emailFromAddress = GetApplicationConfigurationSetting("EmailServerFrom", customizationUserAccountId) ?? "products@eFortresses.com";
                                }
                            }
                            //end
                            var priorExpiryMessage = string.Format(priorExpiryMessageTemplate, processOwner.firstName + " " + processOwner.lastName,
                                                        days, days == 1 ? "Day" : "Days",processOwner.assessmentName,processOwner.companyProfileName, productName,applicationUrl);

                            var notificationExpiry = new Notification()
                            {
                                notificationID = Guid.NewGuid(),
                                author = emailFromAddress,
                                subjectLine = "Assessment Reminder Notification",
                                message = priorExpiryMessage,
                                notificationStatusID = activeStatus.statusCodeID,
                                notificationFrequencyID =
                                    onetimeNotificationFrequency.notificationFrequencyID,
                                displayDuration = 0,
                                isEmailRequired = true,
                                startDateTime = DateTime.Now,
                                expirationDateTime = DateTime.Now.AddDays(7),
                                createdDateTime = DateTime.Now,
                                createdUserID = processOwner.UserId,
                                lastModifiedDateTime = DateTime.Now,
                                lastModifiedUserID = processOwner.UserId,
                                isActive = true,
                                changeReason = null,
                                changeCount = 0,
                                applicationID = ApplicationId
                            };

                            var notificationGroup = new NotificationGroup()
                            {
                                notificationGroupID = Guid.NewGuid(),
                                notificationID = notificationExpiry.notificationID,
                                groupID = processOwner.UserId,
                                notificationGroupTypeId = expiryNotificationGroup.notificationGroupTypeID,
                                isActive = true,
                                createdDatetime = DateTime.Now,
                                createdUserID = processOwner.UserId,
                                lastModifiedDateTime = DateTime.Now,
                                lastModifiedUserID = processOwner.UserId,
                                changeReason = null,
                                changeCount = 0,
                                applicationID = ApplicationId
                            };

                            notificationGroups.Add(notificationGroup);
                            _notificationService.CreateNotification(notificationExpiry, notificationGroups.ToArray(), NotificationProcessContext);
                            notificationGroups.Clear();

                        }
                    }
                }
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("SaaS Framework", "Assessment Deadline Worker Role",
                                                     exception.Message,
                                                     exception.InnerException == null
                                                         ? exception.Message
                                                         : exception.InnerException.Message, exception.StackTrace,
                                                     ExceptionProcessContext);
            }

        }

        /// <summary>
        /// Get the notification group content based in useraccountid
        /// </summary>
        /// <param name="frequency">frequency</param>
        /// <param name="customizationUserAccountId">customization User AccountId</param>
        /// <returns>Notification group type</returns>
        private EfortressService.NotificationServiceReference.NotificationGroupType GetNotificationGroupContent(string frequencyOrGroupName, Guid customizationUserAccountId)
        {
            string notificationQuery = string.Empty;
            switch (frequencyOrGroupName)
            {
                case "FIRST":
                    notificationQuery = string.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"FirstAssessmentDeadlineNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
                case "SECOND":
                    notificationQuery = string.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"SecondAssessmentDeadlineNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
                case "THIRD":
                    notificationQuery = string.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"ThirdAssessmentDeadlineNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
                case "FOURTH":
                    notificationQuery = string.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"FourthAssessmentDeadlineNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
                case "AssessmentCompletedNotification":
                    notificationQuery = string.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"AssessmentCompletedNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
            }
            var expiryNotificationGroup = _notificationService.GetAllNotificationGroupType(
                    notificationQuery, NotificationProcessContext).FirstOrDefault();
            return expiryNotificationGroup;
        }


        /// <summary>
        /// Get the setting value based in setting name and useraccountid
        /// </summary>
        /// <param name="settingName">settingName</param>
        /// <param name="customizationUserAccountId">customization User AccountId</param>
        /// <returns>Setting Value</returns>
        private string GetApplicationConfigurationSetting(string settingName, Guid customizationUserAccountId)
        {
            var configurationSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.settingName == \"{1}\" && setting.userAccountID == new Guid(\"{2}\")", NotificationProcessContext.AppId, settingName, customizationUserAccountId);
            var configurations = _notificationService.GetConfigurationSetting(configurationSearch, NotificationProcessContext).FirstOrDefault();
            return !string.IsNullOrEmpty(Convert.ToString(configurations.settingValue)) ? configurations.settingValue : null;
        }


        /// <summary>
        /// Get the configuration value based in configuration name and useraccountid
        /// </summary>
        /// <param name="configurationName">configurationName</param>
        /// <param name="customizationUserAccountId">customization User AccountId</param>
        /// <returns>Configuration Value</returns>
        private string GetApplicationCustomConfigurationSetting(string configurationName, Guid customizationUserAccountId)
        {
            var customizationSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.configurationName == \"{1}\"  && setting.userAccountID == new Guid(\"{2}\")", NotificationProcessContext.AppId, configurationName, customizationUserAccountId);
            var customizations = _notificationService.GetCustomConfiguration(customizationSearch, NotificationProcessContext).FirstOrDefault();
            return !string.IsNullOrEmpty(Convert.ToString(customizations.configurationValue)) ? customizations.configurationValue : null;
        }

        private void LoggerService(string stringdata)
        {
            //string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            //message += Environment.NewLine;
            //message += "-----------------------------------------------------------";
            //message += Environment.NewLine;
            //message += string.Format("Message: {0}", stringdata);
            //message += Environment.NewLine;
            //message += "-----------------------------------------------------------";
            //FileStream fs = new FileStream(ConfigurationManager.AppSettings[AssessmentDeadlineResource.AssesmentDeadlineLoggerPath], FileMode.OpenOrCreate, FileAccess.Write);
            //StreamWriter sw = new StreamWriter(fs);
            //sw.BaseStream.Seek(0, SeekOrigin.End);
            //sw.WriteLine(message);
            //sw.Flush();
            //sw.Close();
        }  

        #endregion

    }
}
