﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using eFortresses.DataAccessLayer.EntityRepository.Entities;
using eFortresses.ProviderFramework;
using eFortresses.ProviderFramework.ExceptionHandling;
using eFortresses.ProviderFramework.RepositoryFramework;
using eFortresses.Utilities.Core;
using System.Data.Objects;
using System.Configuration;

namespace eFortresses.AssessmentDeadlineProcess
{
    public class AssessmentDeadlineRepository
    {
        #region Private Properties
        private IRepositoryFactory _repositoryFactory;
        private ICrudRepository _entityCrudRepository;
        private IExceptionHandler _exceptionHandler;
        private IQueryRepository _queryRepository;
        #endregion

        #region Internal Properties
        internal IRepositoryFactory RepositoryFactory
        {
            get
            {
                if (_repositoryFactory == null)
                    _repositoryFactory = Provider.GetInstance<IRepositoryFactory>(CommonFrameworkConstants.REPOSITORYFRAMEWORK);
                return _repositoryFactory;
            }
        }
        internal ICrudRepository EntityCrudRepository
        {
            get
            {
                if (_entityCrudRepository == null)
                    _entityCrudRepository = RepositoryFactory.CreateEntityRepository<ICrudRepository>();
                return _entityCrudRepository;
            }
        }
        internal IQueryRepository QueryRepository
        {
            get
            {
                if (_queryRepository == null)
                    _queryRepository = RepositoryFactory.CreateEntityRepository<IQueryRepository>();
                return _queryRepository;
            }
        }
        internal IExceptionHandler ExceptionHandler
        {
            get
            {
                if (_exceptionHandler == null)
                    _exceptionHandler = Provider.GetInstance<IExceptionHandler>(CommonFrameworkConstants.EXCEPTIONHANDLER);
                return _exceptionHandler;
            }
        }
        #endregion

        public IList<AssessmentDetail> GetAssessmentDetails(DateTime expiryBeforeDays,Guid userAccountId,
                                                ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<AssessmentDetail>(ad => EntityFunctions.TruncateTime(ad.createdDateTime) == expiryBeforeDays.Date && ad.isCompleted == false && ad.userAccountID == userAccountId, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<AssessmentDetail>);
        }

        public IList<AssessmentDetail> GetCompletedAssessmentDetails(ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<AssessmentDetail>(ad => ad.isCompleted == true && ad.isCompletedEmailSent==false, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<AssessmentDetail>);
        }


        public IList<AssessmentDeadlineView> GetProcessOwnerForAssessment(Int32 AssessmentDetailId,
                                               ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<AssessmentDeadlineView>(ad => ad.assessmentDetailID == AssessmentDetailId && ad.IsComplete=="N", processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<AssessmentDeadlineView>);
        }

        public IList<AssessmentDeadlineView> GetProcessOwnerForAssessmentCompleted(Int32 AssessmentDetailId,
                                              ProcessContext processContext)
        {
            try
            {
                //var criteria = CustomExpression.GetDynamicExpression<AssessmentDetail>(String.Format("assessmentDetail => assessmentDetail.createdDateTime == {0} && assessmentDetail.isCompleted == false", expiryBeforeDays.Year + "/" + expiryBeforeDays.Month + "/" + expiryBeforeDays.Day + " 00:00:00"));
                //var criteria = CustomExpression.GetDynamicExpression<AssessmentDetail>(String.Format("assessmentDetail => DateTime.Compare(assessmentDetail.createdDateTime.Value.Date, == {0} && assessmentDetail.isCompleted == false", expiryBeforeDays.Year + "/" + expiryBeforeDays.Month + "/" + expiryBeforeDays.Day + " 00:00:00"));
                return EntityCrudRepository.GetAllValues<AssessmentDeadlineView>(ad => ad.assessmentDetailID == AssessmentDetailId && ad.IsComplete == "Y", processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<AssessmentDeadlineView>);
        }

        /// <summary>
        /// Updates the assessment completed email sent status
        /// </summary>
        /// <param name="assessmentId">Assessment Id</param>
        /// <param name="processContext">Application details</param>
        /// <returns>Output of update process(1 = Success)</returns>
        public int UpdateAssessmentCompletedEmailSent(int assessmentId, ProcessContext processContext)
        {
            try
            {
                var assessmentDetail = EntityCrudRepository.GetValue<AssessmentDetail>(ad => ad.assessmentDetailID == assessmentId, processContext);
                assessmentDetail.isCompletedEmailSent = true;
                return EntityCrudRepository.Update<AssessmentDetail>(assessmentDetail, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return -1;
        }
    }
}
