﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using EfortressService.EmailNotification;
using System.Threading;
using System.IO;

namespace EfortressService
{
    public partial class EmailNotificationService : ServiceBase
    {
        Thread _importWorkerThread = null;
        public EmailNotificationService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                //Logger.LogAudit("Email Notif Service started...");
                LoggerService("Inside OnStart...");
                NotificationAlert notify = new NotificationAlert();
                //ThreadStart threadstart = new ThreadStart(notify.NotifyUser);
                //_importWorkerThread = new Thread(threadstart);
                //_importWorkerThread.Start();
                notify.NotifyUser();


                LoggerService("outside OnStart...");
            }
            catch (Exception)
            {

                throw;
            }
        }

        protected override void OnStop()
        {

        }

        private void LoggerService(string stringdata)
        {
            //string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            //message += Environment.NewLine;
            //message += "-----------------------------------------------------------";
            //message += Environment.NewLine;
            //message += string.Format("Message: {0}", stringdata);
            //message += Environment.NewLine;
            //message += "-----------------------------------------------------------";
            //FileStream fs = new FileStream(@"C:\EFTEST\Log.txt", FileMode.OpenOrCreate, FileAccess.Write);
            //StreamWriter sw = new StreamWriter(fs);
            //sw.BaseStream.Seek(0, SeekOrigin.End);
            //sw.WriteLine(message);
            //sw.Flush();
            //sw.Close();
        }  
    }
}
