﻿using System.Text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using eFortresses.CloudeAssurance.WorkerProcess.NotificationServiceReference;
using eFortresses.CloudeAssurance.WorkerProcess.AccountManagementServiceReference;

namespace eFortresses.CloudeAssurance.WorkerProcess.AccountManager.EmailMessages
{
    public static class NotificationMessageProvider
    {
    /// <summary>
    /// A reference to Notification service
    /// </summary>
    static private NotificationServiceReference.NotificationServiceClient _notificationService = new NotificationServiceClient();

    /// <summary>
    /// A reference to Account Management service
    /// </summary>
    static private AccountManagementServiceReference.AccountManagementServiceClient _accountManagementServiceClient = new AccountManagementServiceClient();

    private static Guid _applicationId;
    private static Guid _userAccountId;

    #region Internal Properties

    static internal Guid ApplicationId
    {
        get
        {
            if (_applicationId == Guid.Empty)
            {
                var searchQuery = String.Format("app => app.applicationName == \"{0}\"", ConfigurationManager.AppSettings[AccountManagementResource.ApplicationName]);

                _applicationId = _accountManagementServiceClient.GetApplicationId(searchQuery);
                return _applicationId;
            }
            return _applicationId;
        }
    }

    static internal Guid UserAccountId
    {
        get
        {
            if (_userAccountId == Guid.Empty)
            {
                _userAccountId = new Guid(ConfigurationManager.AppSettings[AccountManagementResource.DefaultUserAccountID]);

                return _applicationId;
            }
            return _userAccountId;
        }
    }
    static NotificationServiceReference.ProcessContext NotificationProcessContext
    {
        get { return new NotificationServiceReference.ProcessContext { UserId = UserAccountId, AppId = ApplicationId }; }
    }
    #endregion

    /// <summary>
    /// Gets the html content for the prior account message
    /// </summary>
    public static string GetPriorAccountExpiryMessage(string firstName, string lastName, int count, string timeOfExpiry)
    {
        var applicationUrlSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.settingName == \"{1}\"", NotificationProcessContext.AppId, AccountManagementResource.ApplicationUrl);
        var applicationUrl = _notificationService.GetConfigurationSetting(applicationUrlSearch, NotificationProcessContext).FirstOrDefault();
        var applicatinUrlValue = applicationUrl != null ? applicationUrl.settingValue : "https://beta.cloudeassurance.com";

        var productNameValue = "CloudeAssurance";

        StringBuilder sb = new StringBuilder();
        sb.Append("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">");
        sb.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><title>");
        sb.Append("Password Notification Message </title></head>");
        sb.Append("<body style=\"margin: 0px;\"> ");
        sb.Append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: 0px solid #346be2; margin: 0px auto\">");
        sb.Append("<tr><td></td></tr>");
        sb.Append("<tr><td>");
        sb.Append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"> ");
        sb.Append("<tr><td style=\"width: 69px;\"></td>");
        sb.Append("<td style=\"width: 460px; padding-top: 23px;\" valign=\"top\">");

        sb.Append("<p style=\"clear: both; overflow: hidden; font-size: 12px; font-family: Arial, Helvetica, sans-serif; color: #000000; line-height: 16px; margin: 0px; padding: 0px 0px 15px 0px;\" align=\"justify\">");
        sb.Append(string.Format("Hi {0},", firstName + " " + lastName));
        sb.Append("<br/></p> ");

        sb.Append("<p style=\"clear: both; overflow: hidden; font-size: 12px; font-family: Arial, Helvetica, sans-serif; color: #000000; line-height: 16px; margin: 0px; padding: 0px 0px 15px 0px;\" align=\"center\">");
        sb.Append(string.Format("Your {2} Account is getting expired in <br> <font style=\"clear: both; overflow: hidden; font-size: 14px; font-family: Arial, Helvetica, sans-serif; color: #FF0000; line-height: 16px; margin: 0px; padding: 0px 0px 15px 0px;\" align=\"center\"> {0} {1}</strong></font></p><strong>", count, timeOfExpiry, productNameValue));
        sb.Append("<br/></p>");

        sb.Append("<p style=\"clear: both; overflow: hidden; font-size: 14px; font-family: Arial, Helvetica, sans-serif; color: #000000; line-height: 16px; margin: 0px; padding: 0px 0px 15px 0px;\" align=\"center\">");
        sb.Append(string.Format("<br> <strong><font style=\"clear: both; overflow: hidden; font-size: 14px; font-family: Arial, Helvetica, sans-serif; color: #FF0000; line-height: 16px; margin: 0px; padding: 0px 0px 15px 0px;\" align=\"center\"> Please renew your {0} Account to continue </strong></font></p>", productNameValue));

        sb.Append(string.Format("Do login to your {0} account for renewal", productNameValue));
        sb.Append(string.Format("<a href=\"{0}\" title=\"{1}\"><font style=\"font-size: 13px; color: #3BB9FF\"> {0} </font></a>", applicatinUrlValue, productNameValue));
        //sb.Append("after receiving the password email.");
        sb.Append("<br/><br/>");
        sb.Append(string.Format("{0} helps an organization to assess the processes, procedures and policies against internationally accepted best practices and uncover information security weaknesses.", productNameValue));
        sb.Append("The same assessment will measure the organization's compliance with applicable regulations.");
        sb.Append("<br/><br/>");
        sb.Append("</p>");

        sb.Append("</td></tr></table>");
        sb.Append("</td></tr></table>");
        sb.Append("</body>");
        sb.Append("</html>");
        return System.Net.WebUtility.HtmlEncode(sb.ToString());
    }

    public static string GetAccountExpiryMessage(string firstName, string lastName)
    {
        var applicationUrlSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.settingName == \"{1}\"", NotificationProcessContext.AppId, AccountManagementResource.ApplicationUrl);
        var applicationUrl = _notificationService.GetConfigurationSetting(applicationUrlSearch, NotificationProcessContext).FirstOrDefault();
        var applicatinUrlValue = applicationUrl != null ? applicationUrl.settingValue : "https://beta.cloudeassurance.com";

        var productNameValue = "CloudeAssurance";
        var companyNameValue = "eFortresses";

        StringBuilder sb = new StringBuilder();
        sb.Append("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">");
        sb.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><title>");
        sb.Append("Password Notification Message </title></head>");
        sb.Append("<body style=\"margin: 0px;\"> ");
        sb.Append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: 0px solid #346be2; margin: 0px auto\">");
        sb.Append("<tr><td></td></tr>");
        sb.Append("<tr><td>");
        sb.Append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"> ");
        sb.Append("<tr><td style=\"width: 69px;\"></td>");
        sb.Append("<td style=\"width: 460px; padding-top: 23px;\" valign=\"top\">");

        sb.Append("<p style=\"clear: both; overflow: hidden; font-size: 12px; font-family: Arial, Helvetica, sans-serif; color: #000000; line-height: 16px; margin: 0px; padding: 0px 0px 15px 0px;\" align=\"justify\">");
        sb.Append(string.Format("Hi {0},", firstName + " " + lastName));
        sb.Append("<br/></p> ");

        sb.Append("<p style=\"clear: both; overflow: hidden; font-size: 12px; font-family: Arial, Helvetica, sans-serif; color: #000000; line-height: 16px; margin: 0px; padding: 0px 0px 15px 0px;\" align=\"center\">");
        sb.Append(string.Format("<br> <font style=\"clear: both; overflow: hidden; font-size: 14px; font-family: Arial, Helvetica, sans-serif; color: #FF0000; line-height: 16px; margin: 0px; padding: 0px 0px 15px 0px;\" align=\"center\"> Your {0} Account is expired</strong></font></p><strong>", productNameValue));
        sb.Append("<br/></p>");

        sb.Append("<p style=\"clear: both; overflow: hidden; font-size: 14px; font-family: Arial, Helvetica, sans-serif; color: #000000; line-height: 16px; margin: 0px; padding: 0px 0px 15px 0px;\" align=\"center\">");
        sb.Append(string.Format("<br> <strong><font style=\"clear: both; overflow: hidden; font-size: 14px; font-family: Arial, Helvetica, sans-serif; color: #FF0000; line-height: 16px; margin: 0px; padding: 0px 0px 15px 0px;\" align=\"center\"> Please renew your {0} Account to continue </strong></font></p>", productNameValue));

        sb.Append(string.Format("Do Contact {0} for renewal", companyNameValue));
        sb.Append(string.Format("<a href=\"{0}\" title=\"{1}\"><font style=\"font-size: 13px; color: #3BB9FF\"> {0} </font></a>", applicatinUrlValue, productNameValue));
        //sb.Append("after receiving the password email.");
        sb.Append("<br/><br/>");
        sb.Append(string.Format("{0} helps an organization to assess the processes, procedures and policies against internationally accepted best practices and uncover information security weaknesses.", productNameValue));
        sb.Append("The same assessment will measure the organization's compliance with applicable regulations.");
        sb.Append("<br/><br/>");
        sb.Append("</p>");

        sb.Append("</td></tr></table>");
        sb.Append("</td></tr></table>");
        sb.Append("</body>");
        sb.Append("</html>");
        return System.Net.WebUtility.HtmlEncode(sb.ToString());
    }
    }
}
