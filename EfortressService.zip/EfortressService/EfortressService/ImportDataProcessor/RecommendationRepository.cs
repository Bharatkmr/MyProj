﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using eFortresses.DataAccessLayer.EntityRepository.Entities;
using eFortresses.ProviderFramework;
using eFortresses.ProviderFramework.ExceptionHandling;
using eFortresses.ProviderFramework.RepositoryFramework;

namespace EfortressService.ImportDataProcessor
{
    public class RecommendationRepository
    {
        #region Private Properties
        private IRepositoryFactory _repositoryFactory;
        private ICrudRepository _entityCrudRepository;
        private IExceptionHandler _exceptionHandler;
        #endregion

        #region Internal Properties
        internal IRepositoryFactory RepositoryFactory
        {
            get
            {
                if (_repositoryFactory == null)
                    _repositoryFactory = Provider.GetInstance<IRepositoryFactory>(CommonFrameworkConstants.REPOSITORYFRAMEWORK);
                return _repositoryFactory;
            }
        }
        internal ICrudRepository EntityCrudRepository
        {
            get
            {
                if (_entityCrudRepository == null)
                    _entityCrudRepository = RepositoryFactory.CreateEntityRepository<ICrudRepository>();
                return _entityCrudRepository;
            }
        }
        internal IExceptionHandler ExceptionHandler
        {
            get
            {
                if (_exceptionHandler == null)
                    _exceptionHandler = Provider.GetInstance<IExceptionHandler>(CommonFrameworkConstants.EXCEPTIONHANDLER);
                return _exceptionHandler;
            }
        }
        #endregion

        #region Recommendation

        public IList<RecommendationCustom> GetRecommendation(int profileId, int assessmentId, ProcessContext processContext)
        {
            try
            {
                IList<RecommendationCustom> recommendationList = new List<RecommendationCustom>();

                var recommendationDetail = GetRecommendationInclude(profileId, assessmentId, processContext);

                recommendationList = (from recommendation in recommendationDetail
                                      select
                                          new RecommendationCustom()
                                          {
                                              ControlSectionName = recommendation.controlSectionName,
                                              QuestionObjective = recommendation.objective,
                                              ControlWeakness = (recommendation.displayNumber + ")" + " " + recommendation.reference + " " + recommendation.questionText),
                                              Recommendation = recommendation.recommendationText,
                                              CompanyProfileId = recommendation.companyProfileID,
                                              AssessmentId = recommendation.assessmentDetailID,
                                              ControlSectionId = recommendation.controlSectionID,
                                              QuestionId = recommendation.questionID,
                                              Response = recommendation.responseText
                                          }).ToList();

                return recommendationList;

            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<RecommendationCustom>);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="profileId"></param>
        /// <param name="assessmentId"></param>
        /// <param name="processContext"></param>
        /// <returns></returns>
        public IList<RecommendationView> GetRecommendationInclude(int profileId, int assessmentId, ProcessContext processContext)
        {
            try
            {
                return
                    EntityCrudRepository.GetAllValues<RecommendationView>(
                        response =>
                        (response.responseText == "NO" || response.responseText == "PARTIAL") &&
                        response.companyProfileID == profileId && response.assessmentDetailID == assessmentId, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<RecommendationView>);
        }

        public IList<RecommendationHeaderCustom> GetRecommendationHeader(int profileId, int assessmentId, ProcessContext processContext)
        {
            try
            {
                var recommendationHeaderDetail = GetRecommendationHeaderInclude(profileId, assessmentId, processContext);

                IList<RecommendationHeaderCustom> recommendationHeaderList = (from recommendation in recommendationHeaderDetail
                                                                              select
                                                                                  new RecommendationHeaderCustom()
                                                                                  {
                                                                                      ProfileName = recommendation.CompanyProfile.companyProfileName,
                                                                                      StandardVersion = recommendation.AssessmentStandard.assessmentStandard1 + ":" + recommendation.AssessmentStandard.standardVersion,
                                                                                      AssessmentStatus = recommendation.isCompleted,
                                                                                      AssessmentName = recommendation.assessmentName
                                                                                  }).ToList();

                return recommendationHeaderList;

            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<RecommendationHeaderCustom>);
        }

        public IList<AssessmentDetail> GetRecommendationHeaderInclude(int profileId, int assessmentId, ProcessContext processContext)
        {
            try
            {
                var includes = new string[1][];
                includes[0] = new string[2];
                includes[0][0] = "AssessmentStandard";
                includes[0][1] = "CompanyProfile";

                return
                    EntityCrudRepository.GetAllValues<AssessmentDetail>(
                        assessmentDetails =>
                        assessmentDetails.companyProfileID == profileId &&
                        assessmentDetails.assessmentDetailID == assessmentId, includes, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<AssessmentDetail>);
        }

        public int CreateRecommendation(int questionId, string recommendationText, ProcessContext processContext)
        {
            try
            {
                var recommendation = new Recommendation()
                {
                    questionID = questionId,
                    recommendationText = recommendationText,
                    createdDateTime = DateTime.Now,
                    lastModifiedDateTime = DateTime.Now
                };

                return EntityCrudRepository.Add<Recommendation>(recommendation, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    if (!(
                        exception.InnerException.Message.Contains("Violation of UNIQUE KEY constraint") &&
                        exception.InnerException.Message.Contains("Violation of PRIMARY KEY")
                        ))
                        throw;
            }
            return -1;
        }

        #endregion

    }
}
