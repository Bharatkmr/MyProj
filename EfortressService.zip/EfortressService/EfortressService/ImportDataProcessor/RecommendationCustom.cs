﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EfortressService.ImportDataProcessor
{
    public class RecommendationCustom
    {
        public string ControlSectionName { get; set; }
        public string QuestionObjective { get; set; }
        public string ControlWeakness { get; set; }
        public string Recommendation { get; set; }

        public int CompanyProfileId { get; set; }
        public int AssessmentId { get; set; }
        public int ControlSectionId { get; set; }
        public int QuestionId { get; set; }
        public string Response { get; set; }

    }

    public class RecommendationHeaderCustom
    {
        public string ProfileName { get; set; }
        public string StandardVersion { get; set; }
        public bool AssessmentStatus { get; set; }
        public string AssessmentName { get; set; }
    }
}
