﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EfortressService.ImportDataProcessor
{
    public class ControlsImportUserMapping
    {
        public string ImportColumnName { get; set; }
        public List<string> EntityFieldNames { get; set; }
    }
}
