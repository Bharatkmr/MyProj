﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using eFortresses.DataAccessLayer.EntityRepository.Entities;
using eFortresses.ProviderFramework;
using eFortresses.ProviderFramework.ExceptionHandling;
using eFortresses.ProviderFramework.RepositoryFramework;

namespace EfortressService.ImportDataProcessor
{
    public class AssessmentStandardRepository
    {
        #region Private Properties
        private IRepositoryFactory _repositoryFactory;
        private ICrudRepository _entityCrudRepository;
        private IExceptionHandler _exceptionHandler;
        private IQueryRepository _queryRepository;
        #endregion

        #region Internal Properties
        internal IRepositoryFactory RepositoryFactory
        {
            get
            {
                if (_repositoryFactory == null)
                    _repositoryFactory = Provider.GetInstance<IRepositoryFactory>(CommonFrameworkConstants.REPOSITORYFRAMEWORK);
                return _repositoryFactory;
            }
        }
        internal ICrudRepository EntityCrudRepository
        {
            get
            {
                if (_entityCrudRepository == null)
                    _entityCrudRepository = RepositoryFactory.CreateEntityRepository<ICrudRepository>();
                return _entityCrudRepository;
            }
        }
        internal IQueryRepository QueryRepository
        {
            get
            {
                if (_queryRepository == null)
                    _queryRepository = RepositoryFactory.CreateEntityRepository<IQueryRepository>();
                return _queryRepository;
            }
        }
        internal IExceptionHandler ExceptionHandler
        {
            get
            {
                if (_exceptionHandler == null)
                    _exceptionHandler = Provider.GetInstance<IExceptionHandler>(CommonFrameworkConstants.EXCEPTIONHANDLER);
                return _exceptionHandler;
            }
        }
        #endregion

        public int CreateAssessmentStandard(string standard, string version, ProcessContext processContext)
        {
            try
            {
                var assessmentStandard = new AssessmentStandard()
                {
                    assessmentStandard1 = standard,
                    standardVersion = version,
                    createdDateTime = DateTime.Now,
                    lastModifiedDateTime = DateTime.Now
                };

                // Added this check to identify the duplicate Triggering of Import call
                var existingStandard = EntityCrudRepository.GetValue<AssessmentStandard>(std => std.assessmentStandard1 == standard && std.standardVersion == version, processContext);

                if (existingStandard == null)
                    return EntityCrudRepository.Add<AssessmentStandard>(assessmentStandard, processContext);
                else
                    return -2;  // existingStandard.assessmentStandardID;

            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return -1;
        }

        public int DeleteAssessmentStandardDependencies(int assessmentStandardId, ProcessContext processContext)
        {
            try
            {
                const string commandText = "[Compliance].usp_DeleteAssessmentStandardDependencies";
                IDictionary<string, object> param = new Dictionary<string, object>
                                                        {
                                                            {"@assessmentStandardId", assessmentStandardId}
                                                        };

                QueryRepository.ExecuteScalar(new RepositoryContext(), commandText, CommandType.StoredProcedure, param, processContext);

                return 1;
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return -1;
        }


        public bool CheckAssessmentStandardNotInUse(int assessmentStandardId, ProcessContext processContext)
        {
            try
            {
                var assessmentDetail = EntityCrudRepository.GetValue<AssessmentDetail>(ad => ad.assessmentStandardID == assessmentStandardId, processContext);
                if (assessmentDetail != null)
                    return false;
                else
                {
                    // Check if any profile got created with this standard's industry group
                    var profile = EntityCrudRepository.GetAllValues<AssessmentStandardCompanyProfileView>(cpv => cpv.assessmentStandardID == assessmentStandardId, processContext);
                    if (profile != null)
                        return false;
                }

                return true;
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return false;
        }

        public AssessmentStandard GetAssessmentStandard(string standard, string version, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetValue<AssessmentStandard>(std => std.assessmentStandard1 == standard && std.standardVersion == version, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(AssessmentStandard);
        }


        public IList<AssessmentStandard> GetAllAssessmentStandards(ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<AssessmentStandard>(null, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<AssessmentStandard>);
        }
    }
}
