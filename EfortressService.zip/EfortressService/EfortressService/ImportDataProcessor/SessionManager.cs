﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using eFortresses.DataAccessLayer.EntityRepository.Entities;
using eFortresses.ProviderFramework;
using eFortresses.ProviderFramework.ExceptionHandling;
using eFortresses.ProviderFramework.RepositoryFramework;

namespace EfortressService.ImportDataProcessor
{
    public class SessionManager
    {
        #region Private Properties
        private IRepositoryFactory _repositoryFactory;
        private ICrudRepository _entityCrudRepository;
        private IExceptionHandler _exceptionHandler;
        private Guid _applicationId;
        private Guid _userAccountId;
        #endregion
        #region Internal
        internal Guid ApplicationId
        {
            get
            {
                if (_applicationId == Guid.Empty)
                {
                    _applicationId = new Guid(ConfigurationManager.AppSettings[ImportDataProcessorResource.ApplicationId]);
                    return _applicationId;
                }
                return _applicationId;
            }
        }

        internal Guid UserAccountId
        {
            get
            {
                if (_userAccountId == Guid.Empty)
                {
                    _userAccountId = new Guid(ConfigurationManager.AppSettings[ImportDataProcessorResource.DefaultUserId]);

                    return _userAccountId;
                }
                return _userAccountId;
            }
        }
        #endregion
        #region Internal Properties
        internal IRepositoryFactory RepositoryFactory
        {
            get
            {
                if (_repositoryFactory == null)
                    _repositoryFactory = Provider.GetInstance<IRepositoryFactory>(CommonFrameworkConstants.REPOSITORYFRAMEWORK);
                return _repositoryFactory;
            }
        }
        internal ICrudRepository EntityCrudRepository
        {
            get
            {
                if (_entityCrudRepository == null)
                    _entityCrudRepository = RepositoryFactory.CreateEntityRepository<ICrudRepository>();
                return _entityCrudRepository;
            }
        }
        internal IExceptionHandler ExceptionHandler
        {
            get
            {
                if (_exceptionHandler == null)
                    _exceptionHandler = Provider.GetInstance<IExceptionHandler>(CommonFrameworkConstants.EXCEPTIONHANDLER);
                return _exceptionHandler;
            }
        }
        #endregion

        #region Public Methods
        public SessionManager(Guid userAccountId)
        {
            _userAccountId = userAccountId;
        }

        public SessionManager()
        {
            _userAccountId = new Guid(ConfigurationManager.AppSettings[ImportDataProcessorResource.DefaultUserId]);
        }

        /// <summary>
        /// Sets a session data
        /// </summary>
        /// <param name="sessionName">name of session data</param>
        /// <param name="sessionData">stringified data to be stored in session</param>
        public Guid SetSession(string sessionName, string sessionData)
        {
            ProcessContext processContext = new ProcessContext { UserId = UserAccountId, AppId = ApplicationId };

            try
            {
                var currentSessionData =
                    EntityCrudRepository.GetValue<SessionAccount>(
                        session => session.sessionName == sessionName && session.sessionOwnerID == processContext.UserId,
                        processContext);
                if (currentSessionData != null)
                {
                    currentSessionData.sessionData = sessionData;
                    currentSessionData.createdDatetime = DateTime.Now;
                    EntityCrudRepository.Update(currentSessionData, processContext);
                }
                else
                {
                    var newSessionData = new SessionAccount()
                    {
                        sessionAccountID = Guid.NewGuid(),
                        sessionOwnerID = processContext.UserId,
                        sessionName = sessionName,
                        sessionData = sessionData,
                        createdDatetime = DateTime.Now,
                        isActive = true
                    };
                    EntityCrudRepository.Add(newSessionData, processContext);
                    return newSessionData.sessionAccountID;
                }

            }
            catch (Exception exception)
            {
                ExceptionHandler.AddException("CloudeAsssurance", "Common", exception.Message,
                                 exception.InnerException == null
                                     ? exception.Message
                                     : exception.InnerException.Message, exception.StackTrace,
                                 processContext);
                throw new Exception(exception.InnerException == null
                                    ? exception.Message
                                    : exception.InnerException.Message);
            }
            return default(Guid);
        }

        /// <summary>
        /// Gets the session data
        /// </summary>
        /// <param name="sessionName">name of session object</param>
        /// <returns>returns the data stored in session or null if no matching session</returns>
        public string GetSession(string sessionName)
        {
            ProcessContext processContext = new ProcessContext { UserId = UserAccountId, AppId = ApplicationId };

            try
            {
                var storedSession = EntityCrudRepository.GetValue<SessionAccount>(
                    session => session.sessionName == sessionName && session.sessionOwnerID == processContext.UserId,
                    processContext);
                if (storedSession == null)
                {
                    return null;
                }
                else
                {
                    return storedSession.sessionData;
                }
            }
            catch (Exception exception)
            {
                ExceptionHandler.AddException("CloudeAsssurance", "Common", exception.Message,
                                              exception.InnerException == null
                                                  ? exception.Message
                                                  : exception.InnerException.Message, exception.StackTrace,
                                              processContext);
                throw new Exception(exception.InnerException == null
                                        ? exception.Message
                                        : exception.InnerException.Message);
            }
        }

        /// <summary>
        /// Gets the Id of the specified session
        /// </summary>
        /// <param name="sessionName">name of session</param>
        /// <param name="sessionOwnerId">creater of session</param>
        /// <returns></returns>
        public Guid GetSessionId(string sessionName, Guid sessionOwnerId)
        {
            ProcessContext processContext = new ProcessContext { UserId = sessionOwnerId, AppId = ApplicationId };

            try
            {
                var storedSession = EntityCrudRepository.GetValue<SessionAccount>(
                    session => session.sessionName == sessionName && session.sessionOwnerID == sessionOwnerId,
                    processContext);
                if (storedSession == null)
                {
                    return Guid.Empty;
                }
                else
                {
                    return storedSession.sessionAccountID;
                }
            }
            catch (Exception exception)
            {
                ExceptionHandler.AddException("CloudeAsssurance", "Session Manager", exception.Message,
                                              exception.InnerException == null
                                                  ? exception.Message
                                                  : exception.InnerException.Message, exception.StackTrace,
                                              processContext);
                throw new Exception(exception.InnerException == null
                                        ? exception.Message
                                        : exception.InnerException.Message);
            }
        }
        /// <summary>
        /// Clear user's session on logout
        /// </summary>
        public void ClearSession()
        {
            ProcessContext processContext = new ProcessContext { UserId = UserAccountId, AppId = ApplicationId };

            try
            {
                var storedSession = EntityCrudRepository.GetAllValues<SessionAccount>(
                    session => session.sessionOwnerID == processContext.UserId,
                    processContext);
                if (storedSession != null)
                {
                    foreach (var sessionAccount in storedSession)
                    {
                        EntityCrudRepository.Delete(sessionAccount, processContext);
                    }
                }
            }
            catch (Exception exception)
            {
                ExceptionHandler.AddException("CloudeAsssurance", "Session Manager", exception.Message,
                                              exception.InnerException == null
                                                  ? exception.Message
                                                  : exception.InnerException.Message, exception.StackTrace,
                                              processContext);
                throw new Exception(exception.InnerException == null
                                        ? exception.Message
                                        : exception.InnerException.Message);
            }
        }
        #endregion
    }
}
