﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using eFortresses.DataAccessLayer.EntityRepository.Entities;
using eFortresses.ProviderFramework;
using eFortresses.ProviderFramework.ExceptionHandling;
using eFortresses.ProviderFramework.RepositoryFramework;

namespace EfortressService.ImportDataProcessor
{
    public class QuestionRepository
    {

        #region Private Properties
        private IRepositoryFactory _repositoryFactory;
        private ICrudRepository _entityCrudRepository;
        private IExceptionHandler _exceptionHandler;
        private IQueryRepository _queryRepository;
        #endregion

        #region Internal Properties
        internal IRepositoryFactory RepositoryFactory
        {
            get
            {
                return _repositoryFactory ??
                       (_repositoryFactory =
                        Provider.GetInstance<IRepositoryFactory>(CommonFrameworkConstants.REPOSITORYFRAMEWORK));
            }
        }
        internal ICrudRepository EntityCrudRepository
        {
            get
            {
                return _entityCrudRepository ??
                       (_entityCrudRepository = RepositoryFactory.CreateEntityRepository<ICrudRepository>());
            }
        }
        internal IQueryRepository QueryRepository
        {
            get
            {
                return _queryRepository ??
                       (_queryRepository = RepositoryFactory.CreateEntityRepository<IQueryRepository>());
            }
        }
        internal IExceptionHandler ExceptionHandler
        {
            get
            {
                return _exceptionHandler ??
                       (_exceptionHandler =
                        Provider.GetInstance<IExceptionHandler>(CommonFrameworkConstants.EXCEPTIONHANDLER));
            }
        }
        #endregion

        #region Public Methods
        public int GetControlSectionId(int questionId, ProcessContext processContext)
        {
            try
            {
                var questionDetail = EntityCrudRepository.GetValue<Question>(ques => ques.questionID == questionId, processContext);
                if (questionDetail != null)
                {
                    return questionDetail.controlSectionID;
                }
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return -1;
        }

        public Recommendation GetRecommendation(int questionId, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetValue<Recommendation>(recommendation => recommendation.questionID == questionId, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(Recommendation);
        }

        public int CreateQuestion(Question question, ProcessContext processContext)     // int controlSectionId, string questionText, string objective, string reference, string hispiModule, int weight 
        {
            try
            {
                return EntityCrudRepository.Add(question, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    if (!(
                        exception.InnerException.Message.Contains("Violation of UNIQUE KEY constraint") &&
                        exception.InnerException.Message.Contains("Violation of PRIMARY KEY")
                        ))
                        throw;
            }
            return -1;
        }

        public Question GetQuestion(int assessmentStandardId, int controlSectionId, string questionText, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetValue<Question>(q => q.assessmentStandardID == assessmentStandardId && q.controlSectionID == controlSectionId && q.questionText == questionText, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(Question);
        }

        public IList<Recommendation> GetAllRecommendations(int controlSectionId, ProcessContext processContext)
        {
            try
            {
                var includes = new string[1][];
                includes[0] = new string[1];
                includes[0][0] = "Question";

                return EntityCrudRepository.GetAllValues<Recommendation>(recommendation => recommendation.Question.controlSectionID == controlSectionId, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<Recommendation>);
        }

        public IList<Question_x_ControlMapping> GetRelatedControlMappings(int questionId, ProcessContext processContext)
        {
            try
            {
                var includes = new string[1][];
                includes[0] = new string[1];
                includes[0][0] = "ControlMapping";

                return EntityCrudRepository.GetAllValues<Question_x_ControlMapping>(qcm => qcm.questionID == questionId, includes, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<Question_x_ControlMapping>);
        }

        public IList<UnAnsweredQuestionsView> GetUnasweredQuestion(int assessmentDetailId, int controlSectionId, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<UnAnsweredQuestionsView>(uaqv => uaqv.assessmentDetailID == assessmentDetailId && uaqv.controlSectionID == controlSectionId, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<UnAnsweredQuestionsView>);
        }

        public IList<UnAnsweredQuestionsView> GetUnasweredQuestion(int assessmentDetailId, int controlSectionId, string fieldName, int page, int pageSize, ProcessContext processContext)
        {
            try
            {
                var orderField = new OrderBy { FieldName = fieldName, Order = SortOrder.Ascending };
                IList<OrderBy> orderList = new List<OrderBy> { orderField };


                return EntityCrudRepository.GetAllValues<UnAnsweredQuestionsView>(uaqv => uaqv.assessmentDetailID == assessmentDetailId && uaqv.controlSectionID == controlSectionId, processContext, orderList, page, pageSize);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<UnAnsweredQuestionsView>);
        }

        public int GetUnasweredQuestionsCount(int assessmentDetailId, ProcessContext processContext)
        {
            try
            {
                var unasweredQuestions = EntityCrudRepository.GetAllValues<UnAnsweredQuestionsView>(uaqv => uaqv.assessmentDetailID == assessmentDetailId, processContext);
                if (unasweredQuestions != null)
                {
                    return unasweredQuestions.Count;
                }
                return 0;
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return -1;
        }

        //public IList<AnsweredQuestionsView> GetAnsweredQuestions(int assessmentDetailId, int controlSectionId, ProcessContext processContext)
        //{
        //    return GetAnsweredQuestions(assessmentDetailId, controlSectionId, "questionID", 0, processContext);
        //}

        //public IList<AnsweredQuestionsView> GetAnsweredQuestions(int assessmentDetailId, int controlSectionId, string fieldName, int currentPage, ProcessContext processContext)
        //{
        //    try
        //    {
        //        var orderField = new OrderBy { FieldName = fieldName, Order = SortOrder.Ascending };
        //        IList<OrderBy> orderList = new List<OrderBy> { orderField };
        //        return EntityCrudRepository.GetAllValues<AnsweredQuestionsView>(aqv => aqv.assessmentDetailID == assessmentDetailId && aqv.controlSectionID == controlSectionId, processContext, orderList, currentPage, Common.Extensions.PageSize());
        //    }
        //    catch (Exception exception)
        //    {
        //        if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
        //            throw;
        //    }
        //    return default(IList<AnsweredQuestionsView>);
        //}

        public IList<Question> GetQuestions(int controlSectionId, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<Question>(ques => ques.controlSectionID == controlSectionId, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<Question>);

        }
        public int GetAsweredQuestionCount(int assessmentDetailId, int controlSectionId, ProcessContext processContext)
        {
            try
            {
                var result = EntityCrudRepository.GetAllValues<AnsweredQuestionsView>(aqv => aqv.assessmentDetailID == assessmentDetailId && aqv.controlSectionID == controlSectionId, processContext);
                return result.Count;
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return 0;
        }

        public int GetUnasweredQuestionCount(int assessmentDetailId, int controlSectionId, ProcessContext processContext)
        {
            try
            {
                var result = EntityCrudRepository.GetAllValues<UnAnsweredQuestionsView>(uaqv => uaqv.assessmentDetailID == assessmentDetailId && uaqv.controlSectionID == controlSectionId, processContext);
                return result.Count;
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return 0;
        }
        #endregion
    }
}
