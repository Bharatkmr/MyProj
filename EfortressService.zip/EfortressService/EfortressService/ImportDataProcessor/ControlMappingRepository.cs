﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using eFortresses.ProviderFramework.RepositoryFramework;
using eFortresses.ProviderFramework.ExceptionHandling;
using eFortresses.DataAccessLayer.EntityRepository.Entities;
using eFortresses.ProviderFramework;

namespace EfortressService.ImportDataProcessor
{
    public class ControlMappingRepository
    {
        #region Private Properties
        private IRepositoryFactory _repositoryFactory;
        private ICrudRepository _entityCrudRepository;
        private IExceptionHandler _exceptionHandler;
        private IQueryRepository _queryRepository;
        #endregion

        #region Internal Properties
        internal IRepositoryFactory RepositoryFactory
        {
            get
            {
                if (_repositoryFactory == null)
                    _repositoryFactory = Provider.GetInstance<IRepositoryFactory>(CommonFrameworkConstants.REPOSITORYFRAMEWORK);
                return _repositoryFactory;
            }
        }
        internal ICrudRepository EntityCrudRepository
        {
            get
            {
                if (_entityCrudRepository == null)
                    _entityCrudRepository = RepositoryFactory.CreateEntityRepository<ICrudRepository>();
                return _entityCrudRepository;
            }
        }
        internal IQueryRepository QueryRepository
        {
            get
            {
                if (_queryRepository == null)
                    _queryRepository = RepositoryFactory.CreateEntityRepository<IQueryRepository>();
                return _queryRepository;
            }
        }
        internal IExceptionHandler ExceptionHandler
        {
            get
            {
                if (_exceptionHandler == null)
                    _exceptionHandler = Provider.GetInstance<IExceptionHandler>(CommonFrameworkConstants.EXCEPTIONHANDLER);
                return _exceptionHandler;
            }
        }
        #endregion

        #region Public Methods
        public ControlMapping GetControlMapping(int assessmentStandardId, string controlMappingName, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetValue<ControlMapping>(cm => cm.assessmentStandardID == assessmentStandardId && cm.controlMappingName == controlMappingName, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(ControlMapping);
        }

        public Question_x_ControlMapping GetQuestionControlMapping(int questionId, int controlMappingId, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetValue<Question_x_ControlMapping>(qucm => qucm.questionID == questionId && qucm.controlMappingID == controlMappingId, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(Question_x_ControlMapping);
        }

        public ControlMappingQuestionDetail GetControlMappingQuestionDetail(int questionId, int controlMappingId, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetValue<ControlMappingQuestionDetail>(cm => cm.controlMappingID == controlMappingId && cm.questionID == questionId, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(ControlMappingQuestionDetail);
        }

        public int PopulateControlMappingQuestionData(string xmlData, ProcessContext processContext)
        {
            try
            {
                const string commandText = "[Compliance].usp_InsertControlMappingQuestionData";
                IDictionary<string, object> param = new Dictionary<string, object>
                                                        {
                                                            {"@controlMappingQuestionDetailXml", xmlData}
                                                        };

                QueryRepository.ExecuteScalar(new RepositoryContext(), commandText, CommandType.StoredProcedure, param, processContext);

                return 1;
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return -1;
        }
        
        public int CreateControlMappingQuestionDetail(int questionId, int controlMappingId, string controlMappingReference, ProcessContext processContext)
        {
            try
            {
                var controlMappingQuestionDetail = new ControlMappingQuestionDetail()
                {
                    controlMappingID = controlMappingId,
                    questionID = questionId,
                    controlMappingQuestionReference = controlMappingReference,
                    createdDateTime = DateTime.Now,
                    lastModifiedDateTime = DateTime.Now
                };

                return EntityCrudRepository.Add<ControlMappingQuestionDetail>(controlMappingQuestionDetail, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    if (!(
                        exception.InnerException.Message.Contains("Violation of UNIQUE KEY constraint") &&
                        exception.InnerException.Message.Contains("Violation of PRIMARY KEY")
                        ))
                        throw;
            }
            return -1;
        }

        public int CreateQuestionControlMapping(int questionId, int controlMappingId, ProcessContext processContext)
        {
            try
            {
                var questionControlMapping = new Question_x_ControlMapping()
                {
                    questionID = questionId,
                    controlMappingID = controlMappingId,
                    createdDateTime = DateTime.Now,
                    lastModifiedDateTime = DateTime.Now
                };

                return EntityCrudRepository.Add<Question_x_ControlMapping>(questionControlMapping, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    if (!(
                        exception.InnerException.Message.Contains("Violation of UNIQUE KEY constraint") &&
                        exception.InnerException.Message.Contains("Violation of PRIMARY KEY")
                        ))
                        throw;
            }
            return -1;
        }

        public int CreateControlMapping(int assessmentStandardID, string controlMappingName, ProcessContext processContext)
        {
            try
            {
                var controlMapping = new ControlMapping()
                {
                    controlMappingName = controlMappingName,
                    assessmentStandardID = assessmentStandardID,
                    controlMappingStatusID = 1,
                    createdDateTime = DateTime.Now,
                    lastModifiedDateTime = DateTime.Now
                };

                return EntityCrudRepository.Add<ControlMapping>(controlMapping, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    if (!(
                        exception.InnerException.Message.Contains("Violation of UNIQUE KEY constraint") &&
                        exception.InnerException.Message.Contains("Violation of PRIMARY KEY")
                        ))
                        throw;
            }
            return -1;
        }
        #endregion
    }
}
