﻿#region ©eFortresses 2011, 2012.  All Rights Reserved.

/*------------------------------------------------------------------------------*
 *                                                                              *
 * the information contained herein is proprietary to eFortresses               *
 *                                                                              *
 * and shall not be reproduced, copied in whole or in part, adapted, modified,  * 
 *                                                                              *
 * or disseminated without the express written consent of eFortresses           *
 *                                                                              *
 *------------------------------------------------------------------------------*/
#endregion

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using EfortressService.ExceptionServiceReference;
using eFortresses.DataAccessLayer.EntityRepository.Entities;
using eFortresses.ProviderFramework;
using eFortresses.ProviderFramework.RepositoryFramework;
using ProcessContext = eFortresses.ProviderFramework.ProcessContext;
using System.IO;
using System.Timers;

namespace EfortressService.ImportDataProcessor
{
    public class ImportDataHandler
    {
        #region Private
        /// <summary>
        /// A reference to Exception service
        /// </summary>
        private ExceptionServiceReference.ExceptionServiceClient _exceptionServiceClient = new ExceptionServiceClient();
        private Guid _applicationId;
        private Guid _userAccountId;
        private IRepositoryFactory _repositoryFactory;
        private ICrudRepository _entityCrudRepository;
        //private Dictionary<string, string> mergedColumnNames = new Dictionary<string, string>();
        //private bool controlObjectiveNotMapped;
        //private bool checkDuplicate = false;
        private CommonHelper commonHelper = new CommonHelper();
        #endregion
        internal IRepositoryFactory RepositoryFactory
        {
            get
            {
                if (_repositoryFactory == null)
                    _repositoryFactory = Provider.GetInstance<IRepositoryFactory>(CommonFrameworkConstants.REPOSITORYFRAMEWORK);
                return _repositoryFactory;
            }
        }
        internal ICrudRepository EntityCrudRepository
        {
            get
            {
                if (_entityCrudRepository == null)
                    _entityCrudRepository = RepositoryFactory.CreateEntityRepository<ICrudRepository>();
                return _entityCrudRepository;
            }
        }
        public string ImportErrorMessage { get; set; }
        public string ImportUserErrorMessage { get; set; }
        public string ImportControlSectionName { get; set; }
        public string ImportControlMappingName { get; set; }
        public string ColumnMappingXmlString { get; set; }
        //Added by vel for appending controlId along with user error message.
        public string ImportControlId { get; set; }
        public IEnumerable<ControlsImportUserMapping> ControlsImportUserMappings { get; set; }

        #region Internal
        internal Guid ApplicationId
        {
            get
            {
                if (_applicationId == Guid.Empty)
                {
                    _applicationId = new Guid(ConfigurationManager.AppSettings[ImportDataProcessorResource.ApplicationId]);
                    return _applicationId;
                }
                return _applicationId;
            }
        }

        internal Guid UserAccountId
        {
            get
            {
                if (_userAccountId == Guid.Empty)
                {
                    _userAccountId = new Guid(ConfigurationManager.AppSettings[ImportDataProcessorResource.DefaultUserId]);

                    return _userAccountId;
                }
                return _userAccountId;
            }
        }
        #endregion

        ExceptionServiceReference.ProcessContext ExceptionProcessContext
        {
            get { return new ExceptionServiceReference.ProcessContext { UserId = UserAccountId, AppId = ApplicationId }; }
        }

        public void ImportDataCall()
        {
            System.Timers.Timer importDataTimer = new System.Timers.Timer();
            importDataTimer.Stop();
            ProcessImportData();
            importDataTimer.Elapsed += new ElapsedEventHandler(importDataTimer_Elapsed);
            importDataTimer.Interval = 10000;  //24 Hours
            importDataTimer.Start();
        }

        public void ProcessImportData()
        {
            ProcessContext processContext = new ProcessContext { UserId = UserAccountId, AppId = ApplicationId };
            // Get the  data to be processed
            var importDetails = EntityCrudRepository.GetValue<ImportProcessDetail>(import => import.importStatus == 0 && import.isActive == true, processContext);
            if (importDetails == null)
            {
                return;
            }
            ImportUserErrorMessage = string.Empty;
            ImportErrorMessage = string.Empty;
            try
            {
                if (importDetails.importCategory.Equals("Controls"))
                {
                    LoggerService("Controls Start");
                    InsertControlsData(importDetails);
                    LoggerService("Controls END");
                }
                else if (importDetails.importCategory.Equals("Knowledgebase"))
                {
                    LoggerService("Knowledgebase Start");
                    InsertKnowledgebaseData(importDetails);
                    LoggerService("Knowledgebase END");
                }
                LoggerService("ProcessImportData END");
            }
            catch (Exception exception)
            {
                LoggerService("EXP " + exception.Message);
                if (_exceptionServiceClient.AddException("CloudeAsssurance", "Import Data Processor", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, ExceptionProcessContext))
                {
                    var importStatus = new ImportStatus();
                    importStatus.importContent = importDetails.importCategory;
                    importStatus.errorMessage = exception.Message != null
                                                    ? exception.Message
                                                    : exception.InnerException != null
                                                          ? exception.InnerException.Message
                                                          : "";
                    importStatus.userErrorMessage = ImportUserErrorMessage;
                    importStatus.createdDatetime = DateTime.Now;
                    importStatus.importStatusID = Guid.NewGuid();
                    importStatus.isActive = true;
                    importStatus.importProcessDetailID = importDetails.importProcessDetailID;
                    EntityCrudRepository.Add(importStatus, processContext);
                    importDetails.importStatus = 3; // Status : Error
                    EntityCrudRepository.Update(importDetails, processContext);
                }
            }

        }

        private void importDataTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            ImportDataCall();
        }

        public void InsertKnowledgebaseData(ImportProcessDetail importDetails) //IEnumerable<KnowledgebaseImportData> knowledgebaseImportData, ProcessContext processContext)
        {
            try
            {
                LoggerService("InsertKnowledgebaseData Method Started");
                ProcessContext processContext = new ProcessContext { UserId = UserAccountId, AppId = ApplicationId };
                var importOutput = new int[2];
                var importStatus = new ImportStatus() { importContent = "Knowledge Base", errorMessage = string.Empty };
                importStatus.knowledgeBaseSuccess = 0;
                importStatus.failures = 0;
                var importData = EntityCrudRepository.GetValue<SessionAccount>(session => session.sessionOwnerID == importDetails.userAccountID && session.sessionName == importDetails.sessionName && session.sessionAccountID == importDetails.sessionID && session.isActive == true, processContext);

                if (importData != null)
                {

                    importDetails.importStatus = 1;     // Status - Processing
                    EntityCrudRepository.Update(importDetails, processContext);
                    SessionManager sessionManager = new SessionManager(processContext.UserId);
                    var serializedString = sessionManager.GetSession("KnowledgebaseImportData");
                    if (serializedString != null)
                    {
                        var serilizable = SerializeHelper<KnowledgebaseImportData>.FromString(serializedString);
                        var knowledgeBaseData = serilizable.ModelSerialize;

                        foreach (var data in knowledgeBaseData)
                        {
                            var breach = new Breach()
                            {
                                breachIndustryID = data.IndustryGroupId,
                                organizationLocation = data.OrganizationLocation,
                                breachType = data.BreachType,
                                registrationImpact = data.RegistrationImpact,
                                controls = data.Controls,
                                certificateDetails = data.CertificateDetails,
                                exposed = data.PIIExposed,
                                loss = data.Cost,
                                breachDate = data.BreachDate,
                                createdDateTime = DateTime.Now,
                                lastModifiedDateTime = DateTime.Now
                            };

                            var output = InsertKnowledgebase(breach, processContext);
                            if (output == 1)
                                importStatus.knowledgeBaseSuccess += 1;
                            else
                            {
                                importStatus.failures += 1;
                                importDetails.importStatus = 3;
                            }

                        }
                    }
                    // set the import status to be completed
                    if (importDetails.importStatus != 3) // if there were no errors
                    {
                        importDetails.importStatus = 2;    // Status : Successful
                    }
                    importDetails.isActive = false;
                    EntityCrudRepository.Update(importDetails, processContext);

                    // Add the import status
                    importStatus.importStatusID = Guid.NewGuid();
                    importStatus.importProcessDetailID = importDetails.importProcessDetailID;
                    importStatus.isActive = true;
                    importStatus.createdDatetime = DateTime.Now;
                    EntityCrudRepository.Add(importStatus, processContext);


                    // Delete the record from SessionAccount
                    EntityCrudRepository.Delete<SessionAccount>(importData, processContext);
                }
            }
            catch (Exception exception)
            {
                if (_exceptionServiceClient.AddException("CloudeAsssurance", "Import Data Processor", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, ExceptionProcessContext))
                {
                    ProcessContext processContext = new ProcessContext { UserId = UserAccountId, AppId = ApplicationId };
                    var importStatus = new ImportStatus();
                    importStatus.errorMessage = exception.Message != null
                                                    ? exception.Message
                                                    : exception.InnerException != null
                                                          ? exception.InnerException.Message
                                                          : "";
                    importStatus.createdDatetime = DateTime.Now;
                    importStatus.importStatusID = Guid.NewGuid();
                    importStatus.errorMessage = string.Empty;
                    importStatus.userErrorMessage = ImportUserErrorMessage;
                    importStatus.isActive = true;
                    importStatus.importProcessDetailID = importDetails.importProcessDetailID;
                    EntityCrudRepository.Add(importStatus, processContext);
                    importDetails.importStatus = 3; // Status : Error
                    EntityCrudRepository.Update(importDetails, processContext);
                }
            }
        }



        /// <summary>
        /// Inserts the Controls data into Database.
        /// </summary>
        /// <param name="importDetails">details of the data to be imported</param>
        /// <returns>Status of Import</returns>
        public void InsertControlsData(ImportProcessDetail importDetails)
        {
            LoggerService("InsertControlsData Method Started");
            ProcessContext processContext = new ProcessContext { UserId = UserAccountId, AppId = ApplicationId };
            var importOutput = new int[2];
            var importStatus = new ImportStatus() { importContent = "Controls", errorMessage = string.Empty };

            // Get the  data to be processed
            // var importDetails = EntityCrudRepository.GetValue<ImportProcessDetail>(import => import.importStatus == 0 && import.isActive == true, processContext);

            if (importDetails == null)
            {
                return;
            }
            processContext.UserId = importDetails.userAccountID;

            try
            {

                var importData =
                    EntityCrudRepository.GetValue<SessionAccount>(
                        session =>
                        session.sessionOwnerID == importDetails.userAccountID &&
                        session.sessionName == importDetails.sessionName && session.sessionAccountID == importDetails.sessionID && session.isActive == true, processContext);
                if (importData != null)
                {
                    importDetails.importStatus = 1;     // Status - Processing
                    EntityCrudRepository.Update(importDetails, processContext);
                    var assessmentStandardRepository = new AssessmentStandardRepository();
                    SessionManager sessionManager = new SessionManager(processContext.UserId);
                    var serializedString = sessionManager.GetSession("ControlsImportUserMappings");
                    if (serializedString != null)
                    {
                        var serilizable = SerializeHelper<ControlsImportUserMapping>.FromString(serializedString);
                        ControlsImportUserMappings = serilizable.ModelSerialize;

                        // ColumnMappingXmlString = sessionManager.GetSession("ColumnMappingXmlString");

                        DataTable controlsMappedData = commonHelper.GetDataTableFromXml(importData.sessionData);

                        // Check if New AssessmentStandard need to be created
                        int standardId = Convert.ToInt32(controlsMappedData.Rows[0][ImportDataProcessorResource.ImportCSColumnStandardId]);
                        if (standardId == -1)       // New Assessment Standard needs to be created
                        {
                            // Create New Assessment Standard
                            string standardAndVersion = Convert.ToString(controlsMappedData.Rows[0][ImportDataProcessorResource.ImportCSColumnNewStandardName]);
                            string standard = standardAndVersion.Substring(0, standardAndVersion.IndexOf("/-/"));
                            string version = standardAndVersion.Substring(standardAndVersion.IndexOf("/-/") + 3);

                            var output = assessmentStandardRepository.CreateAssessmentStandard(standard, version, processContext);

                            if (output == 1)
                            {
                                var assessmentStandard = assessmentStandardRepository.GetAssessmentStandard(standard, version, processContext);

                                if (assessmentStandard != null)
                                {
                                    importStatus.newStandardName = standardAndVersion;
                                    // Update the Id only in main table's First row, while accesssing always refer first row.
                                    controlsMappedData.Rows[0][ImportDataProcessorResource.ImportCSColumnStandardId] = assessmentStandard.assessmentStandardID;
                                }
                                controlsMappedData.AcceptChanges();
                            }
                            else if (output == -2)
                            {
                                // CASE OF DUPLICATE TRIGGERING OF THIS METHOD { DON'T KNOW THE REASON }
                                // TERMINATE THIS FLOW BY RETURNING EMPTY IMPORT-STATUS

                                //auditCode = AuditHandler.GetAuditActionCode(processContext).ToList();
                                //actionCode = auditCode.Where(auditField => auditField.actionCode == "Add").Select(p => p.actionCodeID).FirstOrDefault();
                                //auditDetail = new AuditDetail()
                                //{
                                //    auditDetailID = Guid.NewGuid(),
                                //    applicationEntityId = null,
                                //    auditServerTimeStamp = DateTime.Now,
                                //    userAccountId = processContext.UserId,
                                //    actionCodeID = actionCode,
                                //    oldData = null,
                                //    newData = string.Format("Duplicate Control Import Call for {0} - {1}.", standard, version),
                                //    applicationID = processContext.AppId,
                                //    createdDateTime = DateTime.Now,
                                //    lastModifiedDateTime = DateTime.Now
                                //};

                                //MetadataCrudRepository.Add(auditDetail, processContext);

                                importStatus.importStatusID = Guid.NewGuid();
                                importStatus.errorMessage = "DUPLICATE_CALL";
                                importStatus.userErrorMessage = ImportUserErrorMessage;
                                importStatus.failures = -1;             // THIS IS CHECKED IN 'ControlsMappedData.aspx'- AJAX'S SUCCESS
                                importStatus.createdDatetime = DateTime.Now;
                                importStatus.isActive = true;
                                importStatus.importProcessDetailID = importDetails.importProcessDetailID;
                                EntityCrudRepository.Add(importStatus, processContext);
                                importDetails.importStatus = 3;
                                importDetails.isActive = false;
                                importDetails.createdDatetime = DateTime.Now;
                                EntityCrudRepository.Update(importDetails, processContext);

                                // Delete the record from SessionAccount
                                EntityCrudRepository.Delete<SessionAccount>(importData, processContext);

                                return;
                                //return importStatus;
                            }
                        }
                        else
                        {
                            // Existing Assessment Standard is re-imported, so delete all its associated records
                            assessmentStandardRepository.DeleteAssessmentStandardDependencies(standardId, processContext);
                        }


                        // Imports ControlSections
                        DataTable controlSectionDataTable = commonHelper.GetControlSections(controlsMappedData);
                        importOutput = ImportControlSections(controlsMappedData, controlSectionDataTable, processContext);
                        importStatus.controlSectionSuccess = importOutput[0];
                        importStatus.questionSuccess = importOutput[2];

                        if (importOutput[1] == -1)
                        {
                            // CASE OF DUPLICATE TRIGGERING OF THIS METHOD { DON'T KNOW THE REASON }
                            // TERMINATE THIS FLOW BY RETURNING EMPTY IMPORT-STATUS

                            string standardAndVersion = Convert.ToString(controlsMappedData.Rows[0][ImportDataProcessorResource.ImportCSColumnNewStandardName]);
                            string standard = standardAndVersion.Substring(0, standardAndVersion.IndexOf("/-/"));
                            string version = standardAndVersion.Substring(standardAndVersion.IndexOf("/-/") + 3);

                            //auditCode = AuditHandler.GetAuditActionCode(processContext).ToList();
                            //actionCode = auditCode.Where(auditField => auditField.actionCode == "Add").Select(p => p.actionCodeID).FirstOrDefault();
                            //auditDetail = new AuditDetail()
                            //{
                            //    auditDetailID = Guid.NewGuid(),
                            //    applicationEntityId = null,
                            //    auditServerTimeStamp = DateTime.Now,
                            //    userAccountId = processContext.UserId,
                            //    actionCodeID = actionCode,
                            //    oldData = null,
                            //    newData = string.Format("Duplicate Control Re-Import Call for {0} - {1}.", standard, version),
                            //    applicationID = processContext.AppId,
                            //    createdDateTime = DateTime.Now,
                            //    lastModifiedDateTime = DateTime.Now
                            //};

                            //MetadataCrudRepository.Add(auditDetail, processContext);

                            importStatus.errorMessage = "DUPLICATE_CALL";
                            importStatus.userErrorMessage = ImportUserErrorMessage;
                            importStatus.failures = -1;             // THIS IS CHECKED IN 'ControlsMappedData.aspx'- AJAX'S SUCCESS
                            importDetails.importStatus = 3; // Status : Error
                        }
                        else if (importOutput[1] > 0)
                        {
                            importStatus.failures += importOutput[1];
                            importStatus.errorMessage = ImportErrorMessage;
                            //return importStatus;
                        }

                        //// Imports Questions
                        //importOutput = ImportQuestions(controlsMappedData, processContext);
                        //importStatus.questionSuccess = importOutput[0];
                        //if (importOutput[1] > 0)
                        //{
                        //    importStatus.failures += importOutput[1];
                        //    importStatus.errorMessage = ImportErrorMessage;
                        //    importDetails.importStatus = 3;
                        //}

                        // Imports Control Mappings
                        importOutput = ImportControlMappings(controlsMappedData, commonHelper.GetControlMappings(controlsMappedData), processContext);
                        importStatus.controlMappingSuccess = importOutput[0];
                        if (importOutput[1] > 0)
                        {
                            importStatus.failures += importOutput[1];
                            importStatus.errorMessage = ImportErrorMessage;
                            importStatus.userErrorMessage = ImportUserErrorMessage;
                            importDetails.importStatus = 3;
                        }

                        // set the import status to be completed
                        if (importDetails.importStatus != 3) // if there were no errors
                        {
                            importDetails.importStatus = 2;    // Status : Successful
                        }
                        importDetails.isActive = false;
                        EntityCrudRepository.Update(importDetails, processContext);

                        // Add the import status
                        importStatus.importStatusID = Guid.NewGuid();
                        importStatus.importProcessDetailID = importDetails.importProcessDetailID;
                        importStatus.isActive = true;
                        importStatus.createdDatetime = DateTime.Now;
                        EntityCrudRepository.Add(importStatus, processContext);



                    }
                    else
                    {
                        importDetails.importStatus = 3;
                        importDetails.isActive = false;
                        EntityCrudRepository.Update(importDetails, processContext);

                        importStatus.importStatusID = Guid.NewGuid();
                        importStatus.importProcessDetailID = importDetails.importProcessDetailID;
                        importStatus.errorMessage = "Controls Import Data Null";
                        importStatus.userErrorMessage = ImportUserErrorMessage;
                        importStatus.failures = 1;
                        importStatus.isActive = true;
                        importStatus.createdDatetime = DateTime.Now;
                        EntityCrudRepository.Add(importStatus, processContext);
                    }
                }
                else
                {
                    importDetails.importStatus = 3;
                    importDetails.isActive = false;
                    EntityCrudRepository.Update(importDetails, processContext);

                    importStatus.importStatusID = Guid.NewGuid();
                    importStatus.importProcessDetailID = importDetails.importProcessDetailID;
                    importStatus.errorMessage = "Controls Import Data Null";
                    importStatus.userErrorMessage = ImportUserErrorMessage;
                    importStatus.failures = 1;
                    importStatus.isActive = true;
                    importStatus.createdDatetime = DateTime.Now;
                    EntityCrudRepository.Add(importStatus, processContext);
                }

                // Delete the record from SessionAccount
                EntityCrudRepository.Delete<SessionAccount>(importData, processContext);
            }
            catch (Exception exception)
            {
                if (_exceptionServiceClient.AddException("CloudeAsssurance", "Import Data Processor", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, ExceptionProcessContext))
                {
                    importStatus.errorMessage = exception.Message != null
                                                    ? exception.Message
                                                    : exception.InnerException != null
                                                          ? exception.InnerException.Message
                                                          : "";
                    importStatus.userErrorMessage = ImportUserErrorMessage;
                    importStatus.createdDatetime = DateTime.Now;
                    importStatus.importStatusID = Guid.NewGuid();
                    importStatus.isActive = true;
                    importStatus.importProcessDetailID = importDetails.importProcessDetailID;
                    EntityCrudRepository.Add(importStatus, processContext);
                    importDetails.importStatus = 3; // Status : Error
                    EntityCrudRepository.Update(importDetails, processContext);
                }
            }
        }


        /// <summary>
        /// Imports Control sections into Database.
        /// </summary>
        /// <param name="controlsMappedData">Imported data in Datatable</param>
        /// <param name="controlSectionDataTable">Control Section details</param>
        /// <param name="processContext">Application details</param>
        /// <returns>Outcome of Import</returns>
        private int[] ImportControlSections(DataTable controlsMappedData, DataTable controlSectionDataTable, ProcessContext processContext)
        {
            int failureCount = 0;
            int successCount = 0;
            int questionSuccess = 0;
            try
            {
                int controlSectionIDinDB = 0;
                object controlSectionName;
                object controlObjective;
                object controlId;
                int displayNumber;

                // Add a column for ControlSectionID and other required extra columns at one shot
                controlsMappedData.Columns.Add("ControlSectionID", typeof(System.Int32));
                controlsMappedData.Columns.Add("QuestionID", typeof(System.Int32));
                controlsMappedData.Columns.Add("ControlMappingID", typeof(System.Int32));

                controlsMappedData.AcceptChanges();

                // Add a column for ControlSectionID in dtCS
                controlSectionDataTable.Columns.Add("ControlSectionID", typeof(System.Int32));
                controlSectionDataTable.AcceptChanges();

                int output = 1;
                int assessmentStandardId = Convert.ToInt32(controlsMappedData.Rows[0][ImportDataProcessorResource.ImportCSColumnStandardId]);   // All rows contain same AssessmentStandardId, so take first

                // Decide the QueryString which will update ControlSectionId in user Datatables
                string controlSectionIdUpdateQuery;
                string csIdColumnName = commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnCSId];
                string csColumnName = commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnControlSection];

                if (commonHelper.ControlObjectiveNotMapped)
                {
                    // {2} value is dummy here
                    controlSectionIdUpdateQuery = "[" + csIdColumnName + "]='{0}' AND [" + csColumnName + "] ='{1}'{2}";
                }
                else
                {
                    string csObjectiveColumnName = commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnControlObjetive];
                    controlSectionIdUpdateQuery = "[" + csIdColumnName + "]='{0}' AND [" + csColumnName + "] ='{1}' AND [" + csObjectiveColumnName + "] ='{2}'";
                }

                var controlSectionRepository = new ControlSectionRepository();
                for (int i = 0; i < controlSectionDataTable.Rows.Count; i++)
                {
                    controlId = controlSectionDataTable.Rows[i][commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnCSId]];
                    controlSectionName = controlSectionDataTable.Rows[i][commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnControlSection]];
                    if (commonHelper.ControlObjectiveNotMapped)
                        controlObjective = string.Empty;
                    else
                        controlObjective = controlSectionDataTable.Rows[i][commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnControlObjetive]];
                    ImportControlSectionName = Convert.ToString(controlSectionName);
                    ImportControlId = Convert.ToString(controlId);
                    //IList<ControlSection> existingControlSection = new List<ControlSection>();
                    //if (checkDuplicate)
                    //{
                    //    //Check if ControlSection already exists
                    //    existingControlSection = controlSectionRepository.GetControlSection(assessmentStandardId, Convert.ToString(controlId), Convert.ToString(controlSectionName), Convert.ToString(controlObjective), processContext);
                    //}

                    //if (existingControlSection.Count == 0)
                    //{
                    // No ControlSection present in database, so crearte one
                    var controlSection = new ControlSection()
                    {
                        controlID = Convert.ToString(controlId),
                        controlSectionName = Convert.ToString(controlSectionName),
                        controlSectionObjective = Convert.ToString(controlObjective),
                        assessmentStandardID = assessmentStandardId,
                        isActive = "Y",
                        createdDateTime = DateTime.Now,
                        lastModifiedDateTime = DateTime.Now
                    };

                    output = controlSectionRepository.CreateControlSection(controlSection, processContext);
                    if (output == 1)
                    {
                        successCount += 1;
                        // Get the newly created ControlSection's ID
                        var newControlSection = controlSectionRepository.GetControlSection(assessmentStandardId, Convert.ToString(controlId), Convert.ToString(controlSectionName), Convert.ToString(controlObjective), processContext);

                        // Check if the cross reference already exist
                        if (newControlSection.Count > 0)
                            controlSectionIDinDB = newControlSection[0].controlSectionID;
                    }
                    else if (output == -2)
                    {
                        // CASE OF DUPLICATE TRIGGERING OF THIS METHOD { DON'T KNOW THE REASON }
                        // TERMINATE THIS FLOW BY RETURNING EMPTY IMPORT-STATUS

                        ImportErrorMessage = "DUPLICATE_CALL";
                        return new int[] { successCount, -1, questionSuccess };
                    }
                    else
                    {
                        failureCount += 1;
                        ImportErrorMessage = ImportDataProcessorResource.ImportErrorMessageDataDuplicate;
                    }
                    //}
                    //else
                    //{
                    //    // ControlSection already exists, so update that value to dtAll
                    //    controlSectionIDinDB = existingControlSection[0].controlSectionID;
                    //}
                    failureCount += output != 1 ? 1 : 0;

                    if (controlSectionIDinDB > 0)
                    {
                        // Get the maximum Display number for this Control Section
                        displayNumber = 0;
                        var questions = new QuestionRepository().GetQuestions(controlSectionIDinDB, processContext);
                        if (questions.Count > 0)
                        {
                            displayNumber = (from ques in questions
                                             select ques.displayNumber).Max();
                        }

                        // Insert Questions of the current ControlSection
                        DataRow[] rows = controlsMappedData.Select(string.Format(controlSectionIdUpdateQuery,
                                                                                                controlId.ToString().Replace("'", "''"),
                                                                                                controlSectionName.ToString().Replace("'", "''"),
                                                                                                controlObjective.ToString().Replace("'", "''")));
                        for (int j = 0; j < rows.Count(); j++)
                        {
                            //rows[j]["ControlSectionID"] = controlSectionIDinDB;

                            var questionOutput = ImportQuestion(rows[j], displayNumber, assessmentStandardId, controlSectionIDinDB, processContext);
                            questionSuccess += questionOutput[0];
                            failureCount += questionOutput[1];

                            displayNumber += 1;
                        }
                    }

                    // Reset the ID
                    controlSectionIDinDB = 0;
                }
                controlsMappedData.AcceptChanges();
                return new int[] { successCount, failureCount, questionSuccess };
            }
            catch (Exception exception)
            {
                if (String.IsNullOrEmpty(ImportUserErrorMessage)) ImportUserErrorMessage = ImportDataProcessorResource.ImportControlSectionError + ControlSectionName() + ControlSectionId();
                if (_exceptionServiceClient.AddException("CloudeAsssurance", "Import Data Processor", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, ExceptionProcessContext))
                {
                    if (!(
                        exception.InnerException.Message.Contains("Violation of UNIQUE KEY constraint") &&
                        exception.InnerException.Message.Contains("Violation of PRIMARY KEY")
                        ))
                        throw;
                }
            }
            ImportErrorMessage = ImportDataProcessorResource.ImportErrorMessageDataDuplicate+ControlSectionName();
            if (String.IsNullOrEmpty(ImportUserErrorMessage)) ImportUserErrorMessage = ImportDataProcessorResource.ImportControlSectionDuplicateError + ControlSectionName() + ControlSectionId();
            return new int[] { successCount, failureCount + 1, questionSuccess }; ;
        }

        /// <summary>
        /// Imports a Question from the DataRow object
        /// </summary>
        /// <param name="dataRow"></param>
        /// <param name="displayNumber"></param>
        /// <param name="assessmentStandardId"></param>
        /// <param name="controlSectionId"></param>
        /// <param name="processContext"></param>
        /// <returns></returns>
        private int[] ImportQuestion(DataRow dataRow, int displayNumber, int assessmentStandardId, int controlSectionId, ProcessContext processContext)
        {
            int failureCount = 0;
            int successCount = 0;
            try
            {
                int questionIdInDB = 0;
                object questionText;
                object questionObjective = string.Empty;
                object reference = string.Empty;
                int weightage = 1;
                object recommendation = string.Empty;
                string hispiModule = ImportDataProcessorResource.HispiDefaultUrl;

                var questionRepository = new QuestionRepository();
                questionText = dataRow[commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnQuestion]];

                // No Question present in database, so crearte one
                if (commonHelper.MergedColumnNames.Any(clm => clm.Key == ImportDataProcessorResource.ImportCSColumnQuestionReference))
                    if (dataRow.Table.Columns.Contains(commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnQuestionReference]))
                        reference = Convert.ToString(dataRow[commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnQuestionReference]]);

                if (commonHelper.MergedColumnNames.Any(clm => clm.Key == ImportDataProcessorResource.ImportCSColumnQuestionObjective))
                    if (dataRow.Table.Columns.Contains(commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnQuestionObjective]))
                        questionObjective = Convert.ToString(dataRow[commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnQuestionObjective]]).Trim();

                if (commonHelper.MergedColumnNames.Any(clm => clm.Key == ImportDataProcessorResource.ImportCSColumnHISPIModule))
                    if (dataRow.Table.Columns.Contains(commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnHISPIModule]))
                        hispiModule = Convert.ToString(dataRow[commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnHISPIModule]]).Trim();

                if (commonHelper.MergedColumnNames.Any(clm => clm.Key == ImportDataProcessorResource.ImportCSColumnTop20Rating))
                    if (dataRow.Table.Columns.Contains(commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnTop20Rating]))
                        weightage = Convert.ToInt32(dataRow[commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnTop20Rating]]);

                if (commonHelper.MergedColumnNames.Any(clm => clm.Key == ImportDataProcessorResource.ImportCSColumnRecommendation))
                    if (dataRow.Table.Columns.Contains(commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnRecommendation]))
                        recommendation = Convert.ToString(dataRow[commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnRecommendation]]);

                var question = new Question()
                {
                    controlSectionID = controlSectionId,
                    assessmentStandardID = assessmentStandardId,
                    questionText = Convert.ToString(questionText),
                    objective = Convert.ToString(questionObjective),
                    reference = Convert.ToString(reference),
                    hispModule = hispiModule,
                    displayNumber = displayNumber + 1,
                    weightage = weightage,
                    createdDateTime = DateTime.Now,
                    lastModifiedDateTime = DateTime.Now
                };

                int output = questionRepository.CreateQuestion(question, processContext);
                if (output == 1)
                {
                    // Get the newly created Question's ID
                    var newQuestion = questionRepository.GetQuestion(assessmentStandardId, controlSectionId, Convert.ToString(questionText), processContext);
                    if (newQuestion != null)
                    {
                        questionIdInDB = newQuestion.questionID;
                        // Create new record in Recommendation Table
                        try
                        {
                            output = new RecommendationRepository().CreateRecommendation(questionIdInDB, Convert.ToString(recommendation), processContext);
                        }
                        catch (Exception ex)
                        {
                            ImportUserErrorMessage = ImportDataProcessorResource.ImportRecommendationError;
                            throw ex;
                        }
                    }
                }

                if (output != 1)
                    ImportErrorMessage = ImportDataProcessorResource.ImportErrorMessageDataDuplicate;

                failureCount += output != 1 ? 1 : 0;
                successCount += output == 1 ? 1 : 0;

                if (questionIdInDB > 0)
                {
                    dataRow["QuestionID"] = questionIdInDB;
                }

                dataRow.AcceptChanges();
                return new int[] { successCount, failureCount };
            }
            catch (Exception exception)
            {
                if (string.IsNullOrEmpty(ImportUserErrorMessage)) ImportUserErrorMessage = ImportDataProcessorResource.ImportQuestionError + ControlSectionName() + ControlSectionId();
                if (_exceptionServiceClient.AddException("CloudeAsssurance", "Import Data Processor", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, ExceptionProcessContext))
                    if (!(
                        exception.InnerException.Message.Contains("Violation of UNIQUE KEY constraint") &&
                        exception.InnerException.Message.Contains("Violation of PRIMARY KEY")
                        ))
                        throw;
            }
            ImportErrorMessage = ImportDataProcessorResource.ImportErrorMessageDataDuplicate + ControlSectionName();
            if (string.IsNullOrEmpty(ImportUserErrorMessage)) ImportUserErrorMessage = ImportDataProcessorResource.ImportQuestionDuplicateError + ControlSectionName() + ControlSectionId();
            return new int[] { successCount, failureCount + 1 };
        }

        /// <summary>
        /// Import Questions into Database.
        /// </summary>
        /// <param name="controlsMappedData">Imported data in Datatable</param>
        /// <param name="processContext">Application details</param>
        /// <returns>Outcome of Import</returns>
        private int[] ImportQuestions(DataTable controlsMappedData, ProcessContext processContext)
        {
            int failureCount = 0;
            int successCount = 0;
            try
            {
                int questionIdInDB = 0;
                int controlSectionId = 0;
                int displayNumber = 0;
                int previousControlSectionId = 0;
                object questionText;
                object questionObjective = string.Empty;
                object reference = string.Empty;
                int weightage = 1;
                object recommendation = string.Empty;
                string hispiModule = ImportDataProcessorResource.HispiDefaultUrl;
                int assessmentStandardId = Convert.ToInt32(controlsMappedData.Rows[0][ImportDataProcessorResource.ImportCSColumnStandardId]);   // All rows contain same AssessmentStandardId, so take first

                var questionRepository = new QuestionRepository();
                for (int i = 0; i < controlsMappedData.Rows.Count; i++)
                {
                    controlSectionId = Convert.ToInt32(controlsMappedData.Rows[i]["ControlSectionID"]);
                    questionText = controlsMappedData.Rows[i][commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnQuestion]];

                    //Question existingQuestion = null;
                    //if (checkDuplicate)
                    //{
                    //    // Check if Question already exists in database
                    //    existingQuestion = questionRepository.GetQuestion(assessmentStandardId, controlSectionId, Convert.ToString(questionText), processContext);
                    //}

                    //if (existingQuestion == null)
                    //{
                    // No Question present in database, so crearte one
                    if (commonHelper.MergedColumnNames.Any(clm => clm.Key == ImportDataProcessorResource.ImportCSColumnQuestionReference))
                        if (controlsMappedData.Columns.Contains(commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnQuestionReference]))
                            reference = Convert.ToString(controlsMappedData.Rows[i][commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnQuestionReference]]);

                    if (commonHelper.MergedColumnNames.Any(clm => clm.Key == ImportDataProcessorResource.ImportCSColumnQuestionObjective))
                        if (controlsMappedData.Columns.Contains(commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnQuestionObjective]))
                            questionObjective = Convert.ToString(controlsMappedData.Rows[i][commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnQuestionObjective]]).Trim();

                    if (commonHelper.MergedColumnNames.Any(clm => clm.Key == ImportDataProcessorResource.ImportCSColumnHISPIModule))
                        if (controlsMappedData.Columns.Contains(commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnHISPIModule]))
                            hispiModule = Convert.ToString(controlsMappedData.Rows[i][commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnHISPIModule]]).Trim();

                    if (commonHelper.MergedColumnNames.Any(clm => clm.Key == ImportDataProcessorResource.ImportCSColumnTop20Rating))
                        if (controlsMappedData.Columns.Contains(commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnTop20Rating]))
                            weightage = Convert.ToInt32(controlsMappedData.Rows[i][commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnTop20Rating]]);

                    if (commonHelper.MergedColumnNames.Any(clm => clm.Key == ImportDataProcessorResource.ImportCSColumnRecommendation))
                        if (controlsMappedData.Columns.Contains(commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnRecommendation]))
                            recommendation = Convert.ToString(controlsMappedData.Rows[i][commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnRecommendation]]);

                    // Get the maximum Display number for this Control Section
                    if (previousControlSectionId != controlSectionId)         // Get it only for the first time of the Control Section
                    {
                        previousControlSectionId = controlSectionId;
                        displayNumber = 0;
                        var questions = questionRepository.GetQuestions(controlSectionId, processContext);
                        if (questions.Count > 0)
                        {
                            displayNumber = (from ques in questions
                                             select ques.displayNumber).Max();
                        }
                    }
                    var question = new Question()
                    {
                        controlSectionID = controlSectionId,
                        assessmentStandardID = assessmentStandardId,
                        questionText = Convert.ToString(questionText),
                        objective = Convert.ToString(questionObjective),
                        reference = Convert.ToString(reference),
                        hispModule = hispiModule,
                        displayNumber = displayNumber + 1,
                        weightage = weightage,
                        createdDateTime = DateTime.Now,
                        lastModifiedDateTime = DateTime.Now
                    };

                    int output = questionRepository.CreateQuestion(question, processContext);

                    if (output == 1)
                    {
                        displayNumber += 1;     // Increment by 1

                        // Get the newly created Question's ID
                        var newQuestion = questionRepository.GetQuestion(assessmentStandardId, controlSectionId, Convert.ToString(questionText), processContext);

                        if (newQuestion != null)
                        {
                            questionIdInDB = newQuestion.questionID;

                            // Create new record in Recommendation Table
                            output = new RecommendationRepository().CreateRecommendation(questionIdInDB, Convert.ToString(recommendation), processContext);
                        }
                    }

                    if (output != 1)
                        ImportErrorMessage = ImportDataProcessorResource.ImportErrorMessageDataDuplicate;

                    failureCount += output != 1 ? 1 : 0;
                    successCount += output == 1 ? 1 : 0;
                    //}
                    //else
                    //{
                    //    // Question already exists, so update that value to dtAll
                    //    questionIdInDB = existingQuestion.questionID;
                    //}

                    if (questionIdInDB > 0)
                    {
                        // Update QuestionID in dtAll for matching current record
                        DataRow[] rows = controlsMappedData.Select("ControlSectionID =" + controlSectionId + " AND [" + commonHelper.MergedColumnNames[ImportDataProcessorResource.ImportCSColumnQuestion] + "] ='" + questionText.ToString().Replace("'", "''") + "'");

                        for (int j = 0; j < rows.Count(); j++)
                        {
                            rows[j]["QuestionID"] = questionIdInDB;
                        }
                    }

                    // Reset values
                    controlSectionId = 0;
                    questionText = string.Empty;
                }
                controlsMappedData.AcceptChanges();
                return new int[] { successCount, failureCount };
            }
            catch (Exception exception)
            {
                if (_exceptionServiceClient.AddException("CloudeAsssurance", "Import Data Processor", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, ExceptionProcessContext))
                    if (!(
                        exception.InnerException.Message.Contains("Violation of UNIQUE KEY constraint") &&
                        exception.InnerException.Message.Contains("Violation of PRIMARY KEY")
                        ))
                        throw;
            }
            ImportErrorMessage = ImportDataProcessorResource.ImportErrorMessageDataDuplicate;
            return new int[] { successCount, failureCount + 1 };
        }



        /// <summary>
        /// Import ControlMapping related details into Database.
        /// </summary>
        /// <param name="controlsMappedData">Imported data in Datatable</param>
        /// <param name="controlMappingList">List of ControlMappings</param>
        /// <param name="processContext">Application details</param>
        /// <returns>Outcome of Import</returns>
        private int[] ImportControlMappings(DataTable controlsMappedData, Dictionary<string, int> controlMappingList, ProcessContext processContext)
        {
            int failureCount = 0;
            int successCount = 0;
            //int[] outputSummary;
            string[] outputXmls;

            try
            {
                int controlMappingIdInDB = 0;
                string controlMappingName;
                int assessmentStandardId = Convert.ToInt32(controlsMappedData.Rows[0][ImportDataProcessorResource.ImportCSColumnStandardId]);   // All rows contain same AssessmentStandardId, so take first

                string controlMappingQuestionDetails = "<ControlMappingQuestionData>{0}</ControlMappingQuestionData>";
                string controlMappingQuestionDetailXml = string.Empty;

                int output = 1;
                var controlMappingRepository = new ControlMappingRepository();
                for (int i = 0; i < controlMappingList.Count; i++)
                {
                    controlMappingName = controlMappingList.ElementAt(i).Key;
                    ImportControlMappingName = controlMappingName;
                    //ControlMapping existingControlMapping = null;
                    //if (checkDuplicate)
                    //{
                    //    // Check if ControlMapping already exists in database
                    //    existingControlMapping = controlMappingRepository.GetControlMapping(assessmentStandardId, controlMappingName, processContext);
                    //}

                    //if (existingControlMapping == null)
                    //{
                    // No ControlMapping present in database, so crearte one
                    output = controlMappingRepository.CreateControlMapping(assessmentStandardId, controlMappingName, processContext);
                    if (output == 1)
                    {
                        successCount += 1;
                        var newControlMapping = controlMappingRepository.GetControlMapping(assessmentStandardId, controlMappingName, processContext);
                        if (newControlMapping != null)
                        {
                            // Get the newly created ControlMapping's ID
                            controlMappingIdInDB = newControlMapping.controlMappingID;
                            controlMappingList[controlMappingName] = newControlMapping.controlMappingID;

                            // Process ControlMapping details
                            outputXmls = ProcessControlMappings(controlsMappedData, controlMappingName, controlMappingIdInDB, processContext);
                            controlMappingQuestionDetailXml += outputXmls[0];
                        }
                    }
                    //failureCount += output != 1 ? 1 : 0;
                    else
                    {
                        failureCount += 1;
                        ImportErrorMessage = ImportDataProcessorResource.ImportErrorMessageDataDuplicate;
                    }
                    //}
                    //else
                    //{
                    //    // ControlMapping already exists, so update that value
                    //    controlMappingIdInDB = existingControlMapping.controlMappingID;
                    //    controlMappingList[controlMappingName] = existingControlMapping.controlMappingID;

                    //    // Process ControlMapping details
                    //    outputSummary = ProcessControlMappings(controlsMappedData, controlMappingName, controlMappingIdInDB, processContext);

                    //    successCount += outputSummary[0];
                    //    failureCount += outputSummary[1];
                    //}
                }

                controlMappingQuestionDetailXml = controlMappingQuestionDetailXml.Replace("&", " and ");
                controlMappingQuestionDetails = string.Format(controlMappingQuestionDetails, controlMappingQuestionDetailXml);

                new ControlMappingRepository().PopulateControlMappingQuestionData(controlMappingQuestionDetails, processContext);

                return new int[] { successCount, failureCount };
            }
            catch (Exception exception)
            {
                if (string.IsNullOrEmpty(ImportUserErrorMessage)) ImportUserErrorMessage = ImportDataProcessorResource.ImportControlMappingError + ControlMappingName();
                if (_exceptionServiceClient.AddException("CloudeAsssurance", "Import Data Processor", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, ExceptionProcessContext))
                    if (!(
                        exception.InnerException.Message.Contains("Violation of UNIQUE KEY constraint") &&
                        exception.InnerException.Message.Contains("Violation of PRIMARY KEY")
                        ))
                        throw;
            }
            ImportErrorMessage = ImportDataProcessorResource.ImportErrorMessageDataDuplicate + ControlMappingName();
            if (string.IsNullOrEmpty(ImportUserErrorMessage)) ImportUserErrorMessage = ImportDataProcessorResource.ImportControlMappingDuplicateError + ControlMappingName();
            return new int[] { successCount, failureCount + 1 };
        }


        /// <summary>
        /// Import Control's controlMapping mapping details into Database.
        /// </summary>
        /// <param name="controlsMappedData">Imported data in Datatable</param>
        /// <param name="controlMappingName">ControlMapping Name</param>
        /// <param name="controlMappingId">ControlMapping Id</param>
        /// <param name="processContext">Application details</param>
        /// <returns>Outcome of Import</returns>
        private string[] ProcessControlMappings(DataTable controlsMappedData, string controlMappingName, int controlMappingId, ProcessContext processContext)
        {
            try
            {
                var controlMappingRepository = new ControlMappingRepository();
                int assessmentStandardId = Convert.ToInt32(controlsMappedData.Rows[0][ImportDataProcessorResource.ImportCSColumnStandardId]);   // All rows contain same AssessmentStandardId, so take first

                string controlMappingQuestionNode = "<CQ><QID>{0}</QID><CMID>{1}</CMID><Ref>{2}</Ref></CQ>";
                string controlMappingQuestionXml = string.Empty;

                // Process ControlMapping details
                for (int j = 0; j < controlsMappedData.Rows.Count; j++)
                {
                    int questionId = Convert.ToInt32(controlsMappedData.Rows[j]["QuestionID"]);
                    string controlMappingReference = Convert.ToString(controlsMappedData.Rows[j][controlMappingName + "(" + ImportDataProcessorResource.ImportCSColumnControlMapping + ")"]).Trim();

                    // Check if the column has a value, i.e. mapped to controlMapping
                    if (controlMappingReference.Length > 0)
                    {
                        //Question_x_ControlMapping questionControlMapping = null;
                        //if (checkDuplicate)
                        //{
                        //    // Check if Question_x_ControlMapping already exists in database
                        //    questionControlMapping = controlMappingRepository.GetQuestionControlMapping(questionId, controlMappingId, processContext);
                        //}
                        //if (questionControlMapping == null)
                        //{
                        //// Create record in Question_x_ControlMapping for each controlSection
                        //output = controlMappingRepository.CreateQuestionControlMapping(questionId, controlMappingId, processContext);
                        //failureCount += output != 1 ? 1 : 0;
                        //successCount = output == 1 ? 1 : 0;
                        //}

                        //ControlMappingQuestionDetail controlMappingQuestionDetail = null;
                        //if (checkDuplicate)
                        //{
                        //    // Check if ControlMappingQuestionDetail already exists in database
                        //    controlMappingQuestionDetail = controlMappingRepository.GetControlMappingQuestionDetail(questionId, controlMappingId, processContext);
                        //}
                        //if (controlMappingQuestionDetail == null)
                        //{
                        //// Create record in ControlMappingQuestionDetail for each controlSection
                        //output = controlMappingRepository.CreateControlMappingQuestionDetail(questionId, controlMappingId, controlMappingReference, processContext);
                        //failureCount += output != 1 ? 1 : 0;
                        //successCount = output == 1 ? 1 : 0;

                        controlMappingQuestionXml += string.Format(controlMappingQuestionNode, questionId, controlMappingId, controlMappingReference);

                        //}
                    }
                }

                //return new int[] { successCount, failureCount };
                return new string[] { controlMappingQuestionXml };
            }
            catch (Exception exception)
            {
                if (string.IsNullOrEmpty(ImportUserErrorMessage)) ImportUserErrorMessage = ImportDataProcessorResource.ImportControlMappingError + ControlMappingName();
                if (_exceptionServiceClient.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, ExceptionProcessContext))
                    throw;
            }
            //return new int[] { successCount, failureCount + 1 };
            return new string[] { string.Empty, string.Empty };
        }

        /// <summary>
        /// Creates an entry in Breach table
        /// </summary>
        /// <param name="breach">Breach details</param>
        /// <param name="processContext">Application details</param>
        /// <returns>On successful creation returns 1</returns>
        public int InsertKnowledgebase(Breach breach, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.Add<Breach>(breach, processContext);
            }
            catch (Exception exception)
            {
                ImportUserErrorMessage = ImportDataProcessorResource.ImportBreachError;
                if (_exceptionServiceClient.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, ExceptionProcessContext))
                    throw;
            }
            return -1;
        }

        private string ControlSectionId()
        {
            return (string.IsNullOrEmpty(ImportControlId) ? string.Empty : string.Format(ImportDataProcessorResource.ControlId, ImportControlId));
        }

        private string ControlSectionName()
        {
            return (string.IsNullOrEmpty(ImportControlSectionName) ? string.Empty : string.Format(ImportDataProcessorResource.ControlSectionName,ImportControlSectionName));
        }

        private string ControlMappingName()
        {
            return (string.IsNullOrEmpty(ImportControlMappingName) ? string.Empty : string.Format(ImportDataProcessorResource.ControlMappingName, ImportControlMappingName));
        }

        private void LoggerService(string stringdata)
        {
            //string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            //message += Environment.NewLine;
            //message += "-----------------------------------------------------------";
            //message += Environment.NewLine;
            //message += string.Format("Message: {0}", stringdata);
            //message += Environment.NewLine;
            //message += "-----------------------------------------------------------";
            //FileStream fs = new FileStream(@"C:\Log.txt", FileMode.OpenOrCreate, FileAccess.Write);
            //StreamWriter sw = new StreamWriter(fs);
            //sw.BaseStream.Seek(0, SeekOrigin.End);
            //sw.WriteLine(message);
            //sw.Flush();
            //sw.Close();
        }  
    }
}
