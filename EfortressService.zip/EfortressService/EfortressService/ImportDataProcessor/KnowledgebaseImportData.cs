﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EfortressService.ImportDataProcessor
{
    public class KnowledgebaseImportData
    {
        public int IndustryGroupId { get; set; }
        public string BreachDate { get; set; }
        public string OrganizationLocation { get; set; }
        public string BreachType { get; set; }
        public string RegistrationImpact { get; set; }
        public string Controls { get; set; }
        public string CertificateDetails { get; set; }
        public string PIIExposed { get; set; }
        public string Cost { get; set; }
    }
}
