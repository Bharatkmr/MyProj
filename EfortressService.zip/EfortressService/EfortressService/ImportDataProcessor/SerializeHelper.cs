﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace EfortressService.ImportDataProcessor
{
    public class SerializeHelper<T>
    {
        public IList<T> ModelSerialize { get; set; }

        // Serialize
        public override string ToString()
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            string result = serializer.Serialize(this);
            return result;
        }

        // Deserialize         
        public static SerializeHelper<T> FromString(string text)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Deserialize<SerializeHelper<T>>(text);
        }
    }
}
