﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EfortressService.ImportDataProcessor
{
    public class WeightageSum
    {
        public int TotalWeightage { get; set; }
        public int NaWeightage { get; set; }
        public int YesWeightage { get; set; }
    }
}
