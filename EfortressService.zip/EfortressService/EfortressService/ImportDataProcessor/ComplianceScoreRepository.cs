﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using eFortresses.DataAccessLayer.EntityRepository.Entities;
using eFortresses.ProviderFramework;
using eFortresses.ProviderFramework.ExceptionHandling;
using eFortresses.ProviderFramework.RepositoryFramework;

namespace EfortressService.ImportDataProcessor
{
    public class ComplianceScoreRepository
    {

        #region Private Properties
        private IRepositoryFactory _repositoryFactory;
        private ICrudRepository _entityCrudRepository;
        private IExceptionHandler _exceptionHandler;
        private IQueryRepository _queryRepository;
        #endregion

        #region Internal Properties
        internal IRepositoryFactory RepositoryFactory
        {
            get
            {
                if (_repositoryFactory == null)
                    _repositoryFactory = Provider.GetInstance<IRepositoryFactory>(CommonFrameworkConstants.REPOSITORYFRAMEWORK);
                return _repositoryFactory;
            }
        }
        internal ICrudRepository EntityCrudRepository
        {
            get
            {
                if (_entityCrudRepository == null)
                    _entityCrudRepository = RepositoryFactory.CreateEntityRepository<ICrudRepository>();
                return _entityCrudRepository;
            }
        }
        internal IQueryRepository QueryRepository
        {
            get
            {
                if (_queryRepository == null)
                    _queryRepository = RepositoryFactory.CreateEntityRepository<IQueryRepository>();
                return _queryRepository;
            }
        }
        internal IExceptionHandler ExceptionHandler
        {
            get
            {
                if (_exceptionHandler == null)
                    _exceptionHandler = Provider.GetInstance<IExceptionHandler>(CommonFrameworkConstants.EXCEPTIONHANDLER);
                return _exceptionHandler;
            }
        }
        #endregion

        #region P U B L I C  M E T H O D S
        public IEnumerable<ComplianceScore> GetAllControlSectionScores(int assessmentDetailId, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<ComplianceScore>(score => score.assessmentDetailID == assessmentDetailId
                        && score.isActive == true && score.controlSectionID != null, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IEnumerable<ComplianceScore>);
        }

        public ComplianceScore GetActiveComplianceScore(int assessmentDetailId, int controlSectionID, int controlMappingID, ProcessContext processContext)
        {
            try
            {
                if (controlSectionID > 0)
                {
                    return EntityCrudRepository.GetValue<ComplianceScore>(score => score.assessmentDetailID == assessmentDetailId
                                         && score.controlSectionID == controlSectionID
                                         && score.isActive == true, processContext);
                }
                else if (controlMappingID > 0)
                {
                    return EntityCrudRepository.GetValue<ComplianceScore>(score => score.assessmentDetailID == assessmentDetailId
                                        && score.controlMappingID == controlMappingID
                                        && score.isActive == true, processContext);
                }
                else// Top Breaches Controls
                {
                    return EntityCrudRepository.GetValue<ComplianceScore>(score => score.assessmentDetailID == assessmentDetailId
                                        && score.controlMappingID == null && score.controlSectionID == null
                                        && score.isActive == true, processContext);
                }
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(ComplianceScore);
        }


        public int UpdateComplianceScoresInactive(int assessmentDetailId, int controlSectionId, bool excludeTopBreaches, ProcessContext processContext)
        {
            try
            {
                const string commandText = "[Compliance].usp_UpdateComplianceScoresInactive";
                IDictionary<string, object> param = new Dictionary<string, object>
                                                        {
                                                            {"@assessmentDetailId", assessmentDetailId},
                                                            {"@controlSectionId", controlSectionId},
                                                            {"@excludeTopBreaches", excludeTopBreaches? 1 :0}
                                                        };

                QueryRepository.ExecuteScalar(new RepositoryContext(), commandText, CommandType.StoredProcedure, param, processContext);

                return 1;
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return -1;
        }

        public int UpdateComplianceScore(ComplianceScore complianceScore, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.Update<ComplianceScore>(complianceScore, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return -1;
        }

        public int AddComplianceScore(ComplianceScore complianceScore, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.Add<ComplianceScore>(complianceScore, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return -1;
        }
        #endregion
    }
}
