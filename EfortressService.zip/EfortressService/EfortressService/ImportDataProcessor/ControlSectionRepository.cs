﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using eFortresses.DataAccessLayer.EntityRepository.Entities;
using eFortresses.ProviderFramework;
using eFortresses.ProviderFramework.ExceptionHandling;
using eFortresses.ProviderFramework.RepositoryFramework;

namespace EfortressService.ImportDataProcessor
{
    public class ControlSectionRepository
    {

        #region Private Properties
        private IRepositoryFactory _repositoryFactory;
        private ICrudRepository _entityCrudRepository;
        private IExceptionHandler _exceptionHandler;
        #endregion

        #region Internal Properties
        internal IRepositoryFactory RepositoryFactory
        {
            get
            {
                if (_repositoryFactory == null)
                    _repositoryFactory = Provider.GetInstance<IRepositoryFactory>(CommonFrameworkConstants.REPOSITORYFRAMEWORK);
                return _repositoryFactory;
            }
        }
        internal ICrudRepository EntityCrudRepository
        {
            get
            {
                if (_entityCrudRepository == null)
                    _entityCrudRepository = RepositoryFactory.CreateEntityRepository<ICrudRepository>();
                return _entityCrudRepository;
            }
        }
        internal IExceptionHandler ExceptionHandler
        {
            get
            {
                if (_exceptionHandler == null)
                    _exceptionHandler = Provider.GetInstance<IExceptionHandler>(CommonFrameworkConstants.EXCEPTIONHANDLER);
                return _exceptionHandler;
            }
        }
        #endregion

        public int CreateControlSection(ControlSection controlSection, ProcessContext processContext)   // string controlId, string controlSectionName, string controlSectionObjective
        {
            try
            {
                return EntityCrudRepository.Add<ControlSection>(controlSection, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    if (!(
                        exception.InnerException.Message.Contains("Violation of UNIQUE KEY constraint") &&
                        exception.InnerException.Message.Contains("Violation of PRIMARY KEY")
                        ))
                        throw;
            }
            return -1;
        }

        public IList<ControlSection> GetControlSection(int assessmentStandardId, string controlId, string controlSectionName, string controlSectionObjective, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<ControlSection>(cs => cs.assessmentStandardID == assessmentStandardId && cs.controlID == controlId
                && cs.controlSectionName == controlSectionName && cs.controlSectionObjective == controlSectionObjective, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<ControlSection>);
        }

        public IList<ControlSection> GetAllControlSections(ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<ControlSection>(controlSection => controlSection.isActive == "Y", null, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<ControlSection>);
        }

        // USE CONTROL SECTION DIRECTLY
        //public IList<AssessmentStandard_x_ControlSection> GetControlSectionDetails(int assessmentStandardId, ProcessContext processContext)
        //{
        //    try
        //    {
        //        var includes = new string[1][];
        //        includes[0] = new string[1];
        //        includes[0][0] = "ControlSection";

        //        return EntityCrudRepository.GetAllValues<AssessmentStandard_x_ControlSection>(aStdContSec => aStdContSec.assessmentStandardID == assessmentStandardId && aStdContSec.ControlSection.isActive == "Y", includes, processContext);
        //    }
        //    catch (Exception exception)
        //    {
        //        if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
        //            throw;
        //    }
        //    return default(IList<AssessmentStandard_x_ControlSection>);
        //}
        public IList<ControlSection> GetControlSectionDetails(int assessmentStandardId, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<ControlSection>(cs => cs.assessmentStandardID == assessmentStandardId && cs.isActive == "Y", processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<ControlSection>);
        }

        // USE CONTROL SECTION DIRECTLY
        //public IList<AssessmentStandard_x_ControlSection> GetControlSectionDetails(int assessmentStandardId,  int currentPage, string sortField, int pageSize, ProcessContext processContext)
        //{
        //    try
        //    {
        //        var includes = new string[1][];
        //        includes[0] = new string[1];
        //        includes[0][0] = "ControlSection";

        //        var orderField = new OrderBy { FieldName = sortField, Order = SortOrder.Ascending };
        //        IList<OrderBy> orderList = new List<OrderBy> { orderField };

        //        return EntityCrudRepository.GetAllValues<AssessmentStandard_x_ControlSection>(aStdContSec => aStdContSec.assessmentStandardID == assessmentStandardId && aStdContSec.ControlSection.isActive == "Y", includes, processContext, orderList,currentPage, pageSize);
        //    }
        //    catch (Exception exception)
        //    {
        //        if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
        //            throw;
        //    }
        //    return default(IList<AssessmentStandard_x_ControlSection>);
        //}
        public IList<ControlSection> GetControlSectionDetails(int assessmentStandardId, int currentPage, string sortField, int pageSize, ProcessContext processContext)
        {
            try
            {
                var orderField = new OrderBy { FieldName = sortField, Order = SortOrder.Ascending };
                IList<OrderBy> orderList = new List<OrderBy> { orderField };

                return EntityCrudRepository.GetAllValues<ControlSection>(cs => cs.assessmentStandardID == assessmentStandardId && cs.isActive == "Y", processContext, orderList, currentPage, pageSize);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IList<ControlSection>);
        }

        public int GetTopBreachesControlsRating(int assessmentDetailId, ProcessContext processContext)
        {
            try
            {
                //var topBreachesRating = new ComplianceScoreRepository().GetActiveComplianceScore(assessmentDetailId, 0, Convert.ToInt32(Resources.eFortress.TopBreachesRegulationId) , processContext);
                var topBreachesRating = new ComplianceScoreRepository().GetActiveComplianceScore(assessmentDetailId, 0, 0, processContext);
                if (topBreachesRating != null)
                {
                    return (int)Math.Round(topBreachesRating.complianceScore1);
                }
                // No record found in ComplianceScore table, So handle in Model
                return -100;
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return -1;
        }

        public int GetOverallNonComplianceRating(int assessmentDetailId, ProcessContext processContext)
        {
            try
            {
                var controlSectionRating = new ComplianceScoreRepository().GetAllControlSectionScores(assessmentDetailId, processContext);

                IEnumerable<WeightageSum> weightageSum = from rating in controlSectionRating
                                                         group rating by new { rating.assessmentDetailID } into grp
                                                         select new WeightageSum()
                                                         {
                                                             TotalWeightage = (int)grp.Sum(rt => rt.complianceScore1)
                                                         };
                if (weightageSum.Count() > 0)
                {
                    return weightageSum.ToList()[0].TotalWeightage / controlSectionRating.Count();
                }
                else
                {
                    // No record found in ComplianceScore table, So handle in Model
                    return -100;
                }
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return -1;
        }

        public IEnumerable<TopBreachesControlsView> GetTopBreachesControlsWeights(int assessmentDetailId, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<TopBreachesControlsView>(tb => tb.assessmentDetailID == assessmentDetailId, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IEnumerable<TopBreachesControlsView>);
        }

        public IEnumerable<ControlSectionWeightageView> GetAllControlSectionWeights(int assessmentDetailId, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<ControlSectionWeightageView>(cs => cs.assessmentDetailID == assessmentDetailId, processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IEnumerable<ControlSectionWeightageView>);
        }

        public IEnumerable<ControlSectionWeightageView> GetControlSectionWeights(int assessmentDetailId, int controlSectionId, ProcessContext processContext)
        {
            try
            {
                return EntityCrudRepository.GetAllValues<ControlSectionWeightageView>(
                        cs => cs.assessmentDetailID == assessmentDetailId && cs.controlSectionID == controlSectionId,
                        processContext);
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Repository", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return default(IEnumerable<ControlSectionWeightageView>);
        }

        public int GetControlSectionNonComplianceRating(int assessmentId, int controlSectionId, ProcessContext processContext)
        {
            try
            {
                //var controlSectionRating = EntityCrudRepository.GetValue<ComplianceScore>(score => score.assessmentDetailID == assessmentId && score.isActive == true && score.controlSectionID == controlSectionId, processContext);
                var controlSectionRating = new ComplianceScoreRepository().GetActiveComplianceScore(assessmentId, controlSectionId, 0, processContext);

                if (controlSectionRating != null)
                {
                    return (int)Math.Round(controlSectionRating.complianceScore1);
                }
                else
                {
                    // No record found in ComplianceScore table, So handle in Model
                    return -100;
                }
            }
            catch (Exception exception)
            {
                if (ExceptionHandler.AddException("CloudeAsssurance", "Model", exception.Message, exception.InnerException == null ? exception.Message : exception.InnerException.Message, exception.StackTrace, processContext))
                    throw;
            }
            return -1;
        }

    }

}
