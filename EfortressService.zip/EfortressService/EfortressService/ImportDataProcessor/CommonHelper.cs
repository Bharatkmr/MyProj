﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace EfortressService.ImportDataProcessor
{
    public class CommonHelper
    {
        
        //private Dictionary<string, string> mergedColumnNames = new Dictionary<string, string>();

        public bool ControlObjectiveNotMapped { get; set; }
        public Dictionary<string ,string> MergedColumnNames { get; set; }
        /// <summary>
        /// Gets the Control Section details from the given imported data.
        /// </summary>
        /// <param name="controlsMappedData">Imported data in Datatable</param>
        /// <returns>Control Section details</returns>
        public DataTable GetControlSections(DataTable controlsMappedData)
        {
            try
            {
                Dictionary<string, string> mergedColumns = new Dictionary<string, string>();
                string[] allColumns = (from column in controlsMappedData.Columns.Cast<DataColumn>() select column.ColumnName).ToArray();
                // As named in controlFieldsInEntity. All are required.
                string[] columns;

                string controlObjectiveColumn = Array.Find(allColumns, clm => clm.Contains("(" + ImportDataProcessorResource.ImportCSColumnControlObjetive + ")"));
                if (controlObjectiveColumn != null)
                {
                    columns = new string[3];
                    columns[2] = controlObjectiveColumn;
                    mergedColumns.Add(ImportDataProcessorResource.ImportCSColumnControlObjetive, columns[2]);
                }
                else
                {
                    // Control Objective column is not present, so ignore that
                    ControlObjectiveNotMapped = true;
                    columns = new string[2];
                }

                columns[0] = Array.Find(allColumns, clm => clm.Contains("(" + ImportDataProcessorResource.ImportCSColumnCSId + ")"));
                if (columns[0].Length > 0)
                    mergedColumns.Add(ImportDataProcessorResource.ImportCSColumnCSId, columns[0]);

                columns[1] = Array.Find(allColumns, clm => clm.Contains("(" + ImportDataProcessorResource.ImportCSColumnControlSection + ")"));
                if (columns[1].Length > 0)
                    mergedColumns.Add(ImportDataProcessorResource.ImportCSColumnControlSection, columns[1]);

                string otherColumnName = Array.Find(allColumns, clm => clm.Contains(ImportDataProcessorResource.ImportCSColumnStandardId));
                if (otherColumnName != null)
                    mergedColumns.Add(ImportDataProcessorResource.ImportCSColumnStandardId, otherColumnName);

                otherColumnName = Array.Find(allColumns, clm => clm.Contains(ImportDataProcessorResource.ImportCSColumnNewStandardName));
                if (otherColumnName != null)
                    mergedColumns.Add(ImportDataProcessorResource.ImportCSColumnNewStandardName, otherColumnName);

                // Add other columns(not related to ContorlSection) only to mergedColumns
                otherColumnName = Array.Find(allColumns, clm => clm.Contains("(" + ImportDataProcessorResource.ImportCSColumnQuestion + ")"));
                if (otherColumnName != null)
                    mergedColumns.Add(ImportDataProcessorResource.ImportCSColumnQuestion, otherColumnName);

                otherColumnName = Array.Find(allColumns, clm => clm.Contains("(" + ImportDataProcessorResource.ImportCSColumnQuestionReference + ")"));
                if (otherColumnName != null)
                    mergedColumns.Add(ImportDataProcessorResource.ImportCSColumnQuestionReference, otherColumnName);

                otherColumnName = Array.Find(allColumns, clm => clm.Contains("(" + ImportDataProcessorResource.ImportCSColumnQuestionObjective + ")"));
                if (otherColumnName != null)
                    mergedColumns.Add(ImportDataProcessorResource.ImportCSColumnQuestionObjective, otherColumnName);

                otherColumnName = Array.Find(allColumns, clm => clm.Contains("(" + ImportDataProcessorResource.ImportCSColumnHISPIModule + ")"));
                if (otherColumnName != null)
                    mergedColumns.Add(ImportDataProcessorResource.ImportCSColumnHISPIModule, otherColumnName);

                otherColumnName = Array.Find(allColumns, clm => clm.Contains("(" + ImportDataProcessorResource.ImportCSColumnTop20Rating + ")"));
                if (otherColumnName != null)
                    mergedColumns.Add(ImportDataProcessorResource.ImportCSColumnTop20Rating, otherColumnName);

                otherColumnName = Array.Find(allColumns, clm => clm.Contains("(" + ImportDataProcessorResource.ImportCSColumnRecommendation + ")"));
                if (otherColumnName != null)
                    mergedColumns.Add(ImportDataProcessorResource.ImportCSColumnRecommendation, otherColumnName);

                // Update model's property
                MergedColumnNames = mergedColumns;

                DataView allColumnsDataView = controlsMappedData.DefaultView;
                DataTable controlSectionDataTable = allColumnsDataView.ToTable("ControlSection", true, columns);

                // Update Assessment Standard Id and name (if new) after inculding it
                controlSectionDataTable.Columns.Add(ImportDataProcessorResource.ImportCSColumnStandardId, typeof(Int32));
                controlSectionDataTable.Columns.Add(ImportDataProcessorResource.ImportCSColumnNewStandardName, typeof(string));

                // Update the Id only in main table's First row, while accesssing always refer first row.
                controlSectionDataTable.Rows[0][ImportDataProcessorResource.ImportCSColumnStandardId] = controlsMappedData.Rows[0][ImportDataProcessorResource.ImportCSColumnStandardId];
                controlSectionDataTable.Rows[0][ImportDataProcessorResource.ImportCSColumnNewStandardName] = controlsMappedData.Rows[0][ImportDataProcessorResource.ImportCSColumnNewStandardName];

                controlSectionDataTable.AcceptChanges();

                return controlSectionDataTable;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DataTable GetDataTableFromXml(string xmlString)
        {
            byte[] byteArray = UTF8Encoding.UTF8.GetBytes(xmlString);       // Encoding.ASCII.
            MemoryStream stream = new MemoryStream(byteArray);

            DataSet dataset = new DataSet();
            dataset.ReadXml(stream, XmlReadMode.InferSchema);
            return dataset.Tables[0];
        }

        /// <summary>
        /// Gets the Control's controlMapping mapping details.
        /// </summary>
        /// <param name="controlsMappedData">Imported data in Datatable</param>
        /// <returns>Control's controlMapping mapping details</returns>
        public Dictionary<string, int> GetControlMappings(DataTable controlsMappedData)
        {
            // <ControlMappingName, ControlMappingId>
            Dictionary<string, int> controlMappingList = new Dictionary<string, int>();
            foreach (DataColumn column in controlsMappedData.Columns)
            {
                if (column.ColumnName.Contains("Control Mapping")) //Resources.eFortress.ImportCSColumnControlMapping))
                {
                    string mappingName = column.ColumnName.Replace("(Control Mapping)", "").Trim();         // " + Resources.eFortress.ImportCSColumnControlMapping + "
                    controlMappingList.Add(mappingName, 0); // Keep ControlMappingId as 0 by default and then update later.
                }
            }
            return controlMappingList;
        }

    }
}
