﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using EfortressService.ImportDataProcessor;
using System.Threading;
using System.IO;

namespace EfortressService
{
    partial class ImportWorkerService : ServiceBase
    {
        Thread _importWorkerThread = null;
        public ImportWorkerService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            // TODO: Add code here to start your service.
            LoggerService("Import Data Service Started");
            ImportDataHandler importData = new ImportDataHandler();
            ThreadStart threadstart = new ThreadStart(importData.ProcessImportData);
            _importWorkerThread = new Thread(threadstart);
            _importWorkerThread.Start();
            LoggerService("Thread Started");
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
        }

        private void LoggerService(string stringdata)
        {
            //string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            //message += Environment.NewLine;
            //message += "-----------------------------------------------------------";
            //message += Environment.NewLine;
            //message += string.Format("Message: {0}", stringdata);
            //message += Environment.NewLine;
            //message += "-----------------------------------------------------------";
            //FileStream fs = new FileStream(@"C:\EFTEST\Log.txt", FileMode.OpenOrCreate, FileAccess.Write);
            //StreamWriter sw = new StreamWriter(fs);
            //sw.BaseStream.Seek(0, SeekOrigin.End);
            //sw.WriteLine(message);
            //sw.Flush();
            //sw.Close();
        }  
    }
}
