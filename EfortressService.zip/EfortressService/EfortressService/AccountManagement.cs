﻿#region ©eFortresses 2011, 2012.  All Rights Reserved.

/*------------------------------------------------------------------------------*
 *                                                                              *
 * the information contained herein is proprietary to eFortresses               *
 *                                                                              *
 * and shall not be reproduced, copied in whole or in part, adapted, modified,  * 
 *                                                                              *
 * or disseminated without the express written consent of eFortresses           *
 *                                                                              *
 *------------------------------------------------------------------------------*/
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using EfortressService.NotificationServiceReference;
using EfortressService.ExceptionServiceReference;
using EfortressService.AccountManagementServiceReference;
using System.Configuration;
using NotificationGroup = EfortressService.NotificationServiceReference.NotificationGroup;
using Notification = EfortressService.NotificationServiceReference.Notification;
using eFortresses;
using System.Diagnostics;
using System.IO;
using System.Timers;


namespace EfortressService.AccountManager
{
    public class AccountManagement
    {
        private readonly Object ObjLock = new Object();
        // the thread that will do Notification processing
        private Thread _workerThread;
        /// <summary>
        /// A reference to Notification service
        /// </summary>
        private EfortressService.NotificationServiceReference.NotificationServiceClient _notificationService = new NotificationServiceClient();

        /// <summary>
        /// A reference to Exception service
        /// </summary>
        private EfortressService.ExceptionServiceReference.ExceptionServiceClient _exceptionServiceClient = new ExceptionServiceClient();

        /// <summary>
        /// A reference to Account Management service
        /// </summary>
        private EfortressService.AccountManagementServiceReference.AccountManagementServiceClient _accountManagementServiceClient = new AccountManagementServiceClient();

        private Guid _applicationId;
        private Guid _userAccountId;
        private EfortressService.ExceptionServiceReference.ProcessContext _exceptionProcessContext = null;
        private EfortressService.AccountManagementServiceReference.ProcessContext _accountProcessContext = null;
        private EfortressService.NotificationServiceReference.ProcessContext _notificationProcessContext = null;


        #region Internal Properties

        public Guid ApplicationId
        {
            get
            {
                if (_applicationId == Guid.Empty)
                {
                    var searchQuery = String.Format("app => app.applicationName == \"{0}\"", ConfigurationManager.AppSettings[AccountManagementResource.ApplicationName]);

                    _applicationId =
                        _accountManagementServiceClient.GetApplicationId(searchQuery);
                    return _applicationId;
                }
                return _applicationId;
            }
        }

        public Guid UserAccountId
        {
            get
            {
                if (_userAccountId == Guid.Empty)
                {
                    _userAccountId = new Guid(ConfigurationManager.AppSettings[AccountManagementResource.DefaultUserAccountID]);

                    return _userAccountId;
                }
                return _userAccountId;
            }
        }



        public EfortressService.ExceptionServiceReference.ProcessContext ExceptionProcessContext
        {
            get
            {
                if (_exceptionProcessContext == null)
                {
                    _exceptionProcessContext = new EfortressService.ExceptionServiceReference.ProcessContext { UserId = UserAccountId, AppId = ApplicationId };
                    return _exceptionProcessContext;
                }
                return _exceptionProcessContext;
            }
        }
        public EfortressService.AccountManagementServiceReference.ProcessContext AccountProcessContext
        {
            get
            {
                if (_accountProcessContext == null)
                {
                    _accountProcessContext = new EfortressService.AccountManagementServiceReference.ProcessContext { UserId = UserAccountId, AppId = ApplicationId };
                    return _accountProcessContext;
                }
                return _accountProcessContext;
            }
        }
        public EfortressService.NotificationServiceReference.ProcessContext NotificationProcessContext
        {
            get
            {
                if (_notificationProcessContext == null)
                {
                    _notificationProcessContext = new EfortressService.NotificationServiceReference.ProcessContext { UserId = UserAccountId, AppId = ApplicationId };
                    return _notificationProcessContext;
                }
                return _notificationProcessContext;
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Gets invoked at regular interval for processing notifications
        /// </summary>
        /// <param name="state"></param>
        //public void ScheduledAccountManagement(Object state)
        public void ScheduledAccountManagement()
        {
            var threadStart = new ThreadStart(ProcessAccount);
            _workerThread = new Thread(threadStart);
            _workerThread.Start();
        }

        public void ProcessAccount()
        {
            System.Timers.Timer accountTimer = new System.Timers.Timer();

            //int waitTime = 30;
            //lock (ObjLock)
            {
                try
                {
                    LoggerService("Inside ProcessAccount...");
                    ////Logger.LogAudit("Inside ProcessAccount");
                    //Thread.Sleep(waitTime); // 24 hours

                    accountTimer.Stop();

                    NotifyAccountExpiry();
                    DeactivateExpiredAccount();
                    Trace.WriteLine("Working", "Information");
                    LoggerService("Account Complted...");
                    ////waitTime = 86400000;
                    //waitTime = 60000; //Changed as 1 minute
                    accountTimer.Elapsed += new ElapsedEventHandler(accountTimer_Elapsed);
                    accountTimer.Interval = 86400000;  //24 Hours
                    accountTimer.Start();
                }
                catch (Exception exception)
                {
                    //this.LogError(exception);
                    _exceptionServiceClient.AddException("SaaS Framework", "Account Management Worker Role",
                                                         exception.Message,
                                                         exception.InnerException == null
                                                             ? exception.Message
                                                             : exception.InnerException.Message, exception.StackTrace,
                                                         ExceptionProcessContext);
                }
                finally
                {
                    //waitTime = 86400000;
                }
            }
            // end the thread
            //if (_workerThread != null)
            //{
            //    _workerThread.Abort();
            //}

        }

        private void accountTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            ProcessAccount();
        }

        private void LoggerService(string stringdata)
        {
            string writeLog = ConfigurationManager.AppSettings[AccountManagementResource.WriteLog];
            if (writeLog == "ON")
            {
                //string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
                //message += Environment.NewLine;
                //message += "-----------------------------------------------------------";
                //message += Environment.NewLine;
                //message += string.Format("Message: {0}", stringdata);
                //message += Environment.NewLine;
                //message += "-----------------------------------------------------------";
                //FileStream fs = new FileStream(ConfigurationManager.AppSettings[AccountManagementResource.AccountMgmtLoggerPath], FileMode.OpenOrCreate, FileAccess.Write);
                //StreamWriter sw = new StreamWriter(fs);
                //sw.BaseStream.Seek(0, SeekOrigin.End);
                //sw.WriteLine(message);
                //sw.Flush();
                //sw.Close();
            }
        }  
        #endregion

        #region Private Methods


        /// <summary>
        /// 
        /// </summary>
        private void DeactivateExpiredAccount()
        {
            try
            {
                LoggerService("Inside DeactivateExpiredAccount...");
                //Logger.LogAudit("Inside DeactivateExpiredAccount");
                var expiryDate = DateTime.Now.Date;

                // Get the active notification status
                const string activeStatusQuery = "statusCodes => statusCodes.statusCodeName == \"NotificationStatus\" && statusCodes.codeValue == \"Active\" && statusCodes.isActive == true";
                var activeStatus = _notificationService.GetStatusCode(activeStatusQuery, NotificationProcessContext).FirstOrDefault();

                // Get id for one time notification
                const string onetimeNotificationFrequencyQuery = "notificationFrequency => notificationFrequency.frequencyName == \"One Time\" && notificationFrequency.isActive == true";
                var onetimeNotificationFrequency =
                    _notificationService.GetAllNotificationFrequency(onetimeNotificationFrequencyQuery,
                                                                     NotificationProcessContext).FirstOrDefault();

                var expiryNotificationGroup = GetNotificationGroupContent("AccountExpiredNotification", UserAccountId);
                var priorExpiryMessageTemplate = expiryNotificationGroup.content;

                const string successfulSubscriptionStatusQuery = "statusCodes => statusCodes.statusCodeName == \"SubscriptionStatus\" && statusCodes.codeValue == \"Successful\" && statusCodes.isActive == true";
                var successfulSubscriptionStatus = _notificationService.GetStatusCode(successfulSubscriptionStatusQuery, NotificationProcessContext).FirstOrDefault();

                var productName = GetApplicationCustomConfigurationSetting("ProductName", UserAccountId) ?? "CloudeAssurance";
                var companyName = GetApplicationCustomConfigurationSetting("CompanyName", UserAccountId) ?? "eFortresses";
                var applicationUrl = GetApplicationConfigurationSetting("ApplicationUrl", UserAccountId) ?? "https://azure.cloudeassurance.com";
                var emailFromAddress = GetApplicationConfigurationSetting("EmailServerFrom", UserAccountId) ?? "products@eFortresses.com";

                var searchQuery = String.Format("userdetail => userdetail.subscriptionStatus == new Guid(\"{0}\") && userdetail.expiryDate <= {1} && userdetail.isActive == true", successfulSubscriptionStatus.statusCodeID, expiryDate.Year + "/" + expiryDate.Month + "/" + expiryDate.Day + " 00:00:00");
                var expiredAccounts = _accountManagementServiceClient.GetUserSubscriptionDetail(searchQuery, AccountProcessContext);
                var notificationGroups = new List<NotificationGroup>();
                foreach (var expiredAccount in expiredAccounts)
                {
                    string accountSearch = String.Format("userdetail => userdetail.userAccountID == new Guid(\"{0}\")", expiredAccount.userAccountID);
                    var user = _accountManagementServiceClient.GetAllCustomers(accountSearch, AccountProcessContext, null, 0, 0).FirstOrDefault();
                    var status = _accountManagementServiceClient.SetUserAccountInActive(expiredAccount.userAccountID, AccountProcessContext);
                    if (status == "Expired")
                    {
                        //Added for task# 462
                        Guid customizationUserAccountId = Guid.Empty;
                        if (user.roleName == "TenantAdministrator")
                            customizationUserAccountId = user.userAccountID;
                        else if (user.roleName == "ProcessOwner" || user.roleName == "TenantUser")
                            customizationUserAccountId = (Guid)user.createdUserID;
                        if (customizationUserAccountId != Guid.Empty)
                        {
                            var customizationSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.userAccountID == new Guid(\"{1}\")", NotificationProcessContext.AppId, customizationUserAccountId);
                            var customizations = _notificationService.GetCustomConfiguration(customizationSearch, NotificationProcessContext);
                            if (customizations != null && customizations.Count() > 0)
                            {
                                priorExpiryMessageTemplate = GetNotificationGroupContent("AccountExpiredNotification", customizationUserAccountId).content;
                                productName = GetApplicationCustomConfigurationSetting("ProductName", customizationUserAccountId) ?? "CloudeAssurance";
                                companyName = GetApplicationCustomConfigurationSetting("CompanyName", customizationUserAccountId) ?? "eFortresses";
                                emailFromAddress = GetApplicationConfigurationSetting("EmailServerFrom", customizationUserAccountId) ?? "products@eFortresses.com";
                            }
                        }
                        //end

                        var priorExpiryMessage = string.Format(priorExpiryMessageTemplate, user.firstName + " " + user.lastName, productName, companyName, applicationUrl,user.companyName,user.email);

                        var notificationExpiry = new Notification()
                        {
                            notificationID = Guid.NewGuid(),
                            author = emailFromAddress,
                            subjectLine = "Account Expiry Notification",
                            message = priorExpiryMessage,
                            notificationStatusID = activeStatus.statusCodeID,
                            notificationFrequencyID =
                                onetimeNotificationFrequency.notificationFrequencyID,
                            displayDuration = 0,
                            isEmailRequired = true,
                            startDateTime = DateTime.Now,
                            expirationDateTime = DateTime.Now.AddDays(7),
                            createdDateTime = DateTime.Now,
                            createdUserID = user.userAccountID,
                            lastModifiedDateTime = DateTime.Now,
                            lastModifiedUserID = user.userAccountID,
                            isActive = true,
                            changeReason = null,
                            changeCount = 0,
                            applicationID = ApplicationId
                        };

                        var notificationGroup = new NotificationGroup()
                        {
                            notificationGroupID = Guid.NewGuid(),
                            notificationID = notificationExpiry.notificationID,
                            groupID = user.userAccountID,
                            notificationGroupTypeId = expiryNotificationGroup.notificationGroupTypeID,
                            isActive = true,
                            createdDatetime = DateTime.Now,
                            createdUserID = user.userAccountID,
                            lastModifiedDateTime = DateTime.Now,
                            lastModifiedUserID = user.userAccountID,
                            changeReason = null,
                            changeCount = 0,
                            applicationID = ApplicationId
                        };

                        notificationGroups.Add(notificationGroup);
                        _notificationService.CreateNotification(notificationExpiry, notificationGroups.ToArray(), NotificationProcessContext);
                        notificationGroups.Clear();
                    }
                }
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("SaaS Framework", "Account Management Worker Role",
                                                     exception.Message,
                                                     exception.InnerException == null
                                                         ? exception.Message
                                                         : exception.InnerException.Message, exception.StackTrace,
                                                     ExceptionProcessContext);
            }
        }

        private void NotifyAccountExpiry()
        {
            try
            {
                LoggerService("Inside NotifyAccountExpiry...");
                //Logger.LogAudit("Inside NotifyAccountExpiry");
                //Added for task# 462
                Guid cutomizationUserAccountId = Guid.Empty;
                string accountSearch = String.Format("userdetail => userdetail.isActive == true && userdetail.roleName==\"{0}\"", "TenantAdministrator");
                
                LoggerService("accountSearch" + accountSearch);

                var tenantAdminUsers = _accountManagementServiceClient.GetAllCustomers(accountSearch, AccountProcessContext, null, 0, 0);
                foreach (var tenantAdmin in tenantAdminUsers)
                {
                    LoggerService("Inside foreach tenent users...");

                    var customizationSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.userAccountID == new Guid(\"{1}\")", NotificationProcessContext.AppId, tenantAdmin.userAccountID);
                    var customizations = _notificationService.GetCustomConfiguration(customizationSearch, NotificationProcessContext);
                    if (customizations != null && customizations.Count() > 0)
                        cutomizationUserAccountId = tenantAdmin.userAccountID;
                    else
                        cutomizationUserAccountId = UserAccountId;
                    //cutomizationUserAccountId = customizations.Count() > 0 ? tenantAdmin.userAccountID : UserAccountId;

                    var fourthNotificationSettingValue = GetApplicationConfigurationSetting(AccountManagementResource.NotifyFourthAccountExpiry, cutomizationUserAccountId);
                    // Fourth alert of assessment deadline
                    EmailNotifyAccountExpiry(int.Parse(fourthNotificationSettingValue), "FOURTH", tenantAdmin.userAccountID);

                    var thirdNotificationSettingValue = GetApplicationConfigurationSetting(AccountManagementResource.NotifyThirdAccountExpiry, cutomizationUserAccountId);
                    // Third alert of assessment deadline
                    EmailNotifyAccountExpiry(int.Parse(thirdNotificationSettingValue), "THIRD", tenantAdmin.userAccountID);

                    var secondNotificationSettingValue = GetApplicationConfigurationSetting(AccountManagementResource.NotifySeconAccountExpiry, cutomizationUserAccountId);
                    // Second alert of account expiry
                    EmailNotifyAccountExpiry(int.Parse(secondNotificationSettingValue), "SECOND", tenantAdmin.userAccountID);

                    var firstNotificationSettingValue = GetApplicationConfigurationSetting(AccountManagementResource.NotifyFirstAccountExpiry, cutomizationUserAccountId);
                    // First alert of account expiry
                    EmailNotifyAccountExpiry(int.Parse(firstNotificationSettingValue), "FIRST", tenantAdmin.userAccountID);
                }

                LoggerService("No tenent users...");

                string accountProcessOwnerSearch = String.Format("userdetail => userdetail.isActive == true && userdetail.roleName==\"{0}\"", "ProcessOwner");
                var processOwnerUsers = _accountManagementServiceClient.GetAllCustomers(accountProcessOwnerSearch, AccountProcessContext, null, 0, 0);
                foreach (var processUser in processOwnerUsers)
                {
                    var customizationPOSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.userAccountID == new Guid(\"{1}\")", NotificationProcessContext.AppId, processUser.createdUserID);
                    var customizationsPO = _notificationService.GetCustomConfiguration(customizationPOSearch, NotificationProcessContext);
                    if (customizationsPO != null && customizationsPO.Count() > 0)
                        cutomizationUserAccountId = (Guid)processUser.createdUserID;
                    else
                        cutomizationUserAccountId = UserAccountId;
                    //cutomizationUserAccountId = (customizationsPO != null && customizationsPO.Count() > 0) ? (Guid)processUser.createdUserID : UserAccountId;

                    var fourthNotificationSettingValue = GetApplicationConfigurationSetting(AccountManagementResource.NotifyFourthAccountExpiry, cutomizationUserAccountId);
                    // Fourth alert of assessment deadline
                    EmailNotifyAccountExpiry(int.Parse(fourthNotificationSettingValue), "FOURTH", processUser.userAccountID);

                    var thirdNotificationSettingValue = GetApplicationConfigurationSetting(AccountManagementResource.NotifyThirdAccountExpiry, cutomizationUserAccountId);
                    // Third alert of assessment deadline
                    EmailNotifyAccountExpiry(int.Parse(thirdNotificationSettingValue), "THIRD", processUser.userAccountID);

                    var secondNotificationSettingValue = GetApplicationConfigurationSetting(AccountManagementResource.NotifySeconAccountExpiry, cutomizationUserAccountId);
                    // Second alert of account expiry
                    EmailNotifyAccountExpiry(int.Parse(secondNotificationSettingValue), "SECOND", processUser.userAccountID);

                    var firstNotificationSettingValue = GetApplicationConfigurationSetting(AccountManagementResource.NotifyFirstAccountExpiry, cutomizationUserAccountId);
                    // First alert of account expiry
                    EmailNotifyAccountExpiry(int.Parse(firstNotificationSettingValue), "FIRST", processUser.userAccountID);
                }
                LoggerService("No process owners...");

                string accountTenantUserSearch = String.Format("userdetail => userdetail.isActive == true && userdetail.roleName==\"{0}\"", "TenantUser");
                var tenantUsers = _accountManagementServiceClient.GetAllCustomers(accountTenantUserSearch, AccountProcessContext, null, 0, 0);
                foreach (var tenant in tenantUsers)
                {
                    var customizationTUSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.userAccountID == new Guid(\"{1}\")", NotificationProcessContext.AppId, tenant.createdUserID);
                    var customizationsTU = _notificationService.GetCustomConfiguration(customizationTUSearch, NotificationProcessContext);
                    //cutomizationUserAccountId = (customizationsTU != null && customizationsTU.Count() > 0) ? (Guid)tenant.createdUserID : UserAccountId;
                    if (customizationsTU != null && customizationsTU.Count() > 0)
                        cutomizationUserAccountId = (Guid)tenant.createdUserID;
                    else
                        cutomizationUserAccountId = UserAccountId;

                    var fourthNotificationSettingValue = GetApplicationConfigurationSetting(AccountManagementResource.NotifyFourthAccountExpiry, cutomizationUserAccountId);
                    // Fourth alert of assessment deadline
                    EmailNotifyAccountExpiry(int.Parse(fourthNotificationSettingValue), "FOURTH", tenant.userAccountID);

                    var thirdNotificationSettingValue = GetApplicationConfigurationSetting(AccountManagementResource.NotifyThirdAccountExpiry, cutomizationUserAccountId);
                    // Third alert of assessment deadline
                    EmailNotifyAccountExpiry(int.Parse(thirdNotificationSettingValue), "THIRD", tenant.userAccountID);

                    var secondNotificationSettingValue = GetApplicationConfigurationSetting(AccountManagementResource.NotifySeconAccountExpiry, cutomizationUserAccountId);
                    // Second alert of account expiry
                    EmailNotifyAccountExpiry(int.Parse(secondNotificationSettingValue), "SECOND", tenant.userAccountID);

                    var firstNotificationSettingValue = GetApplicationConfigurationSetting(AccountManagementResource.NotifyFirstAccountExpiry, cutomizationUserAccountId);
                    // First alert of account expiry
                    EmailNotifyAccountExpiry(int.Parse(firstNotificationSettingValue), "FIRST", tenant.userAccountID);
                }
                LoggerService("No tenant Users...");
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("SaaS Framework", "Account Management Worker Role",
                                                     exception.Message,
                                                     exception.InnerException == null
                                                         ? exception.Message
                                                         : exception.InnerException.Message, exception.StackTrace,
                                                     ExceptionProcessContext);
            }
        }

        private void EmailNotifyAccountExpiry(int days, string frequency,Guid currentUserAccountId)
        {
            try
            {
                LoggerService("Inside EmailNotifyAccountExpiry");
                LoggerService("frequency" + frequency);

                var expiryAfterDays =
                    DateTime.Now.AddDays(days).Date;

                // Get the active notification status
                var activeStatusQuery =
                    "statusCodes => statusCodes.statusCodeName == \"NotificationStatus\" && statusCodes.codeValue == \"Active\" && statusCodes.isActive == true";
                var activeStatus = _notificationService.GetStatusCode(activeStatusQuery, NotificationProcessContext).FirstOrDefault();

                // Get id for one time notification
                var onetimeNotificationFrequencyQuery =
                    "notificationFrequency => notificationFrequency.frequencyName == \"One Time\" && notificationFrequency.isActive == true";
                var onetimeNotificationFrequency =
                    _notificationService.GetAllNotificationFrequency(onetimeNotificationFrequencyQuery,
                                                                     NotificationProcessContext).FirstOrDefault();

                var expiryNotificationGroup = GetNotificationGroupContent(frequency, UserAccountId);
                var priorExpiryMessageTemplate = expiryNotificationGroup.content;

                var productName = GetApplicationCustomConfigurationSetting("ProductName", UserAccountId) ?? "CloudeAssurance";
                var applicationUrl = GetApplicationConfigurationSetting("ApplicationUrl", UserAccountId) ?? "https://azure.cloudeassurance.com";
                var emailFromAddress = GetApplicationConfigurationSetting("EmailServerFrom", UserAccountId) ?? "products@eFortresses.com";

                LoggerService("applicationUrl" + applicationUrl.ToString());
                LoggerService("emailFromAddress" + emailFromAddress.ToString());

                var searchQuery = String.Format("userdetail => userdetail.expiryDate <= {0} && userdetail.isActive == true && userdetail.userAccountID == new Guid(\"{1}\")", expiryAfterDays.Year + "/" + expiryAfterDays.Month + "/" + expiryAfterDays.Day + " 23:59:59", currentUserAccountId);
                var expiredAccounts = _accountManagementServiceClient.GetUserSubscriptionDetail(searchQuery, AccountProcessContext);
                var notificationGroups = new List<NotificationGroup>();
                foreach (var expiredAccount in expiredAccounts)
                {
                    LoggerService("Inside foreach expired acc...");

                    if (IsEmailRequired(expiredAccount.userAccountID, expiryNotificationGroup.notificationGroupTypeID, expiredAccount.expiryDate, days))
                    {
                        string accountSearch = String.Format("userdetail => userdetail.userAccountID == new Guid(\"{0}\")", expiredAccount.userAccountID);
                        var user = _accountManagementServiceClient.GetAllCustomers(accountSearch, AccountProcessContext, null, 0, 0).FirstOrDefault();

                        //Added for task# 462
                        Guid customizationUserAccountId = Guid.Empty;
                        if (user.roleName == "TenantAdministrator")
                            customizationUserAccountId = user.userAccountID;
                        else if (user.roleName == "ProcessOwner" || user.roleName == "TenantUser")
                            customizationUserAccountId = (Guid)user.createdUserID;
                        if (customizationUserAccountId != Guid.Empty)
                        {
                            var customizationSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.userAccountID == new Guid(\"{1}\")", NotificationProcessContext.AppId, customizationUserAccountId);
                            var customizations = _notificationService.GetCustomConfiguration(customizationSearch, NotificationProcessContext);
                            if (customizations != null && customizations.Count() > 0)
                            {
                                priorExpiryMessageTemplate = GetNotificationGroupContent(frequency, customizationUserAccountId).content;
                                productName = GetApplicationCustomConfigurationSetting("ProductName", customizationUserAccountId) ?? "CloudeAssurance";
                                emailFromAddress = GetApplicationConfigurationSetting("EmailServerFrom", customizationUserAccountId) ?? "products@eFortresses.com";
                            }
                        }
                        //end

                        var priorExpiryMessage = string.Format(priorExpiryMessageTemplate, user.firstName + " " + user.lastName,
                                                           productName, days, days == 1 ? "Day" : "Days", applicationUrl);

                        var notificationExpiry = new Notification()
                        {
                            notificationID = Guid.NewGuid(),
                            author = emailFromAddress,
                            subjectLine = "Account Expiry Notification",
                            message = priorExpiryMessage,
                            notificationStatusID = activeStatus.statusCodeID,
                            notificationFrequencyID =
                                onetimeNotificationFrequency.notificationFrequencyID,
                            displayDuration = 0,
                            isEmailRequired = true,
                            startDateTime = DateTime.Now,
                            expirationDateTime = DateTime.Now.AddDays(7),
                            createdDateTime = DateTime.Now,
                            createdUserID = user.userAccountID,
                            lastModifiedDateTime = DateTime.Now,
                            lastModifiedUserID = user.userAccountID,
                            isActive = true,
                            changeReason = null,
                            changeCount = 0,
                            applicationID = ApplicationId
                        };

                        var notificationGroup = new NotificationGroup()
                        {
                            notificationGroupID = Guid.NewGuid(),
                            notificationID = notificationExpiry.notificationID,
                            groupID = user.userAccountID,
                            notificationGroupTypeId = expiryNotificationGroup.notificationGroupTypeID,
                            isActive = true,
                            createdDatetime = DateTime.Now,
                            createdUserID = user.userAccountID,
                            lastModifiedDateTime = DateTime.Now,
                            lastModifiedUserID = user.userAccountID,
                            changeReason = null,
                            changeCount = 0,
                            applicationID = ApplicationId
                        };

                        notificationGroups.Add(notificationGroup);
                        _notificationService.CreateNotification(notificationExpiry, notificationGroups.ToArray(), NotificationProcessContext);
                        notificationGroups.Clear();

                    }
                }
                LoggerService("Outside Expired acc..");
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("SaaS Framework", "Account Management Worker Role",
                                                     exception.Message,
                                                     exception.InnerException == null
                                                         ? exception.Message
                                                         : exception.InnerException.Message, exception.StackTrace,
                                                     ExceptionProcessContext);
            }

        }

        /// <summary>
        /// Get the notification group content based in useraccountid
        /// </summary>
        /// <param name="frequency">frequency</param>
        /// <param name="customizationUserAccountId">customization User AccountId</param>
        /// <returns>Notification group type</returns>
        private EfortressService.NotificationServiceReference.NotificationGroupType GetNotificationGroupContent(string frequencyOrGroupName, Guid customizationUserAccountId)
        {
            string notificationQuery = string.Empty;
            switch (frequencyOrGroupName)
            {
                case "FIRST":
                    notificationQuery = string.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"FirstAccountExpiryNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
                case "SECOND":
                    notificationQuery = string.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"SecondAccountExpiryNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
                case "THIRD":
                    notificationQuery = string.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"ThirdAccountExpiryNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
                case "FOURTH":
                    notificationQuery = string.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"FourthAccountExpiryNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
                case "AccountExpiredNotification":
                    notificationQuery = string.Format("notificationGroupTypes => notificationGroupTypes.groupName == \"AccountExpiredNotification\" && notificationGroupTypes.isActive == true && notificationGroupTypes.userAccountID== new Guid(\"{0}\")", customizationUserAccountId);
                    break;
            }
            var expiryNotificationGroup = _notificationService.GetAllNotificationGroupType(
                    notificationQuery, NotificationProcessContext).FirstOrDefault();
            return expiryNotificationGroup;
        }

        /// <summary>
        /// Get the setting value based in setting name and useraccountid
        /// </summary>
        /// <param name="settingName">settingName</param>
        /// <param name="customizationUserAccountId">customization User AccountId</param>
        /// <returns>Setting Value</returns>
        private string GetApplicationConfigurationSetting(string settingName, Guid customizationUserAccountId)
        {
            var configurationSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.settingName == \"{1}\" && setting.userAccountID == new Guid(\"{2}\")", NotificationProcessContext.AppId, settingName, customizationUserAccountId);
            var configurations = _notificationService.GetConfigurationSetting(configurationSearch, NotificationProcessContext).FirstOrDefault();
            return !string.IsNullOrEmpty(Convert.ToString(configurations.settingValue)) ? configurations.settingValue : null;
        }


        /// <summary>
        /// Get the configuration value based in configuration name and useraccountid
        /// </summary>
        /// <param name="configurationName">configurationName</param>
        /// <param name="customizationUserAccountId">customization User AccountId</param>
        /// <returns>Configuration Value</returns>
        private string GetApplicationCustomConfigurationSetting(string configurationName, Guid customizationUserAccountId)
        {
            var customizationSearch = String.Format("setting => setting.applicationID == new Guid(\"{0}\") && setting.isActive == true && setting.configurationName == \"{1}\"  && setting.userAccountID == new Guid(\"{2}\")", NotificationProcessContext.AppId, configurationName, customizationUserAccountId);
            var customizations = _notificationService.GetCustomConfiguration(customizationSearch, NotificationProcessContext).FirstOrDefault();
            return !string.IsNullOrEmpty(Convert.ToString(customizations.configurationValue)) ? customizations.configurationValue : null;
        }


        /// <summary>
        /// Verifys whether email is required
        /// </summary>
        /// <param name="userAccountId">user account id</param>
        /// <param name="notificationGroupTypeId">notification type</param>
        /// <param name="expiryDate">account expiry date</param>
        /// <param name="daysBeforeExpiry">notification days before account expiry</param>
        private bool IsEmailRequired(Guid userAccountId, Guid notificationGroupTypeId, DateTime expiryDate, int daysBeforeExpiry)
        {
            try
            {
                DateTime firstNotificationDate = expiryDate.AddDays(-daysBeforeExpiry);
                var notificationQuery =
                    string.Format(
                        "notification => notification.groupID == new Guid(\"{0}\") && notification.notificationGroupTypeId == new Guid(\"{1}\") && notification.createdDatetime <={2} && notification.createdDatetime >= {3}",
                        userAccountId, notificationGroupTypeId, DateTime.Now.Year + "/" + DateTime.Now.Month +"/" + DateTime.Now.Day + " 23:59:59", firstNotificationDate.Year + "/" + firstNotificationDate.Month + "/" + firstNotificationDate.Day + " 23:59:59");
                if (firstNotificationDate.Year == DateTime.Now.Year && firstNotificationDate.Month == DateTime.Now.Month && firstNotificationDate.Day == DateTime.Now.Day)
                {
                    var notificationEntries = _notificationService.GetAllNotificationGroup(notificationQuery, NotificationProcessContext);
                    if (notificationEntries != null && notificationEntries.Count() > 0)
                    {
                        return false;
                    }
                    return true;
                }
                return false;
            }
            catch (Exception exception)
            {
                _exceptionServiceClient.AddException("SaaS Framework", "Account Management Worker Role",
                                                     exception.Message,
                                                     exception.InnerException == null
                                                         ? exception.Message
                                                         : exception.InnerException.Message, exception.StackTrace,
                                                     ExceptionProcessContext);
            }
            return default(bool);
        }

        #endregion

        //public void LogError(Exception ex)
        //{
        //    string writeLog = ConfigurationManager.AppSettings[AccountManagementResource.WriteLog];
        //    if (writeLog == "ON")
        //    {
        //        string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
        //        message += Environment.NewLine;
        //        message += "-----------------------------------------------------------";
        //        message += Environment.NewLine;
        //        message += "Inside Service Class";
        //        message += Environment.NewLine;
        //        message += string.Format("Message: {0}", ex.Message);
        //        message += Environment.NewLine;
        //        message += string.Format("StackTrace: {0}", ex.StackTrace);
        //        message += Environment.NewLine;
        //        message += string.Format("Source: {0}", ex.Source);
        //        message += Environment.NewLine;
        //        message += string.Format("TargetSite: {0}", ex.TargetSite.ToString());
        //        message += Environment.NewLine;
        //        message += "-----------------------------------------------------------";
        //        message += Environment.NewLine;
        //        string path = ConfigurationManager.AppSettings[AccountManagementResource.AccountMgmtLoggerPath];
        //        using (StreamWriter writer = new StreamWriter(path, true))
        //        {
        //            writer.WriteLine(message);
        //            writer.Close();
        //        }
        //    }
        //}

    }
}
